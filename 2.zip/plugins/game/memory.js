// قائمة الأحجام المسموحة
const BOARD_SIZES = {
    '4x4': { rows: 4, cols: 4, total: 16, pairs: 8 },
    '6x6': { rows: 6, cols: 6, total: 36, pairs: 18 },
    '8x8': { rows: 8, cols: 8, total: 64, pairs: 32 }
};

const EMOJIS = [
    '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮',
    '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🐴', '🐺', '🐝', '🐛', '🦋', '🐌',
    '🐞', '🐜', '🕷️', '🦂', '🐢', '🐍', '🦎', '🐙', '🦑', '🦀', '🐡', '🐠',
    '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍒', '🍑', '🥭'
];

if (!global.memoryGames) global.memoryGames = {};

// توليد اللوحة الداخلية (أزواج من الإيموجي)
function generateBoard(rows, cols, pairs) {
    const shuffledEmojis = [...EMOJIS];
    for (let i = shuffledEmojis.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffledEmojis[i], shuffledEmojis[j]] = [shuffledEmojis[j], shuffledEmojis[i]];
    }
    const selectedEmojis = shuffledEmojis.slice(0, pairs);
    let cards = [...selectedEmojis, ...selectedEmojis];
    for (let i = cards.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [cards[i], cards[j]] = [cards[j], cards[i]];
    }
    return cards;
}

// دالة رسم اللوحة تمامًا مثل XO: إيموجي أرقام للخانات المغلقة، وإيموجي للخانات المكشوفة
function drawBoard(board, revealed, rows, cols) {
    let lines = [];
    for (let r = 0; r < rows; r++) {
        let row = [];
        for (let c = 0; c < cols; c++) {
            const idx = r * cols + c;
            if (revealed[idx]) {
                row.push(board[idx]);          // الإيموجي الحقيقي
            } else {
                row.push(`${idx + 1}️⃣`);     // إيموجي الرقم (1️⃣, 2️⃣, ...)
            }
        }
        lines.push(row.join(' │ '));
        if (r < rows - 1) {
            // خطوط أفقية متوافقة مع عدد الأعمدة
            const separator = '───┼───┼───┼───┼───┼───┼───┼───┼───'.slice(0, cols * 4 - 1);
            lines.push(separator);
        }
    }
    return lines.join('\n');
}

function isGameFinished(revealed) {
    return revealed.every(v => v === true);
}

async function awardWinner(conn, chatId, winnerJid, playerScore, opponentScore) {
    if (winnerJid) {
        if (global.db?.users[winnerJid]) {
            global.db.users[winnerJid].xp = (global.db.users[winnerJid].xp || 0) + 100;
            global.db.users[winnerJid].cookies = (global.db.users[winnerJid].cookies || 0) + 10;
        }
        await conn.sendMessage(chatId, {
            text: `🏆 *الفائز:* @${winnerJid.split('@')[0]}\n🎉 حصل على +100 XP و 🍪 +10 كوكيز.\nالنتيجة النهائية: ${playerScore} - ${opponentScore}`,
            mentions: [winnerJid]
        });
    } else {
        await conn.sendMessage(chatId, { text: `🤝 *تعادل!* النتيجة: ${playerScore} - ${opponentScore}` });
    }
}

async function deleteAfterDelay(conn, chatId, msg, delay = 3000) {
    setTimeout(async () => {
        try { await conn.sendMessage(chatId, { delete: msg.key }); } catch (e) {}
    }, delay);
}

async function askBoardSize(conn, chatId, mode, initiator) {
    const sections = [{
        title: "📏 اختر حجم اللوحة",
        rows: Object.keys(BOARD_SIZES).map(size => ({
            title: size,
            description: `${BOARD_SIZES[size].rows}x${BOARD_SIZES[size].cols} (${BOARD_SIZES[size].pairs} زوج)`,
            id: `.ذاكرة ${mode}|${initiator}|${size}`
        }))
    }];
    await conn.sendButtonNormal(chatId, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: "🧠 *لعبة الذاكرة*\nاختر حجم اللوحة:",
        buttons: [{ name: "single_select", params: { title: "📏 اختر الحجم", sections: sections } }],
        mentions: [initiator]
    }, global.reply_status);
}

// ---------- وضع ضد الروبوت (مع حذف رسائل الأخطاء فقط) ----------
async function createBotGame(m, conn, chatId, player, sizeKey) {
    const size = BOARD_SIZES[sizeKey];
    const board = generateBoard(size.rows, size.cols, size.pairs);
    const revealed = Array(size.total).fill(false);
    const game = {
        mode: 'bot',
        rows: size.rows,
        cols: size.cols,
        total: size.total,
        board, revealed,
        playerScore: 0,
        botScore: 0,
        turn: 'player',
        gameOver: false,
        timeout: setTimeout(() => {
            if (global.memoryGames[chatId]) delete global.memoryGames[chatId];
        }, 120000)
    };
    global.memoryGames[chatId] = game;
    await conn.sendMessage(chatId, { text: `🤖 *لعبة الذاكرة (ضد الروبوت)* - لوحة ${size.rows}x${size.cols}\n${drawBoard(board, revealed, size.rows, size.cols)}\n\nدورك! أرسل رقمين (مثال: 5 12) باستخدام إيموجي الرقم أو الرقم العادي.` });
}

async function botMove(conn, chatId, game) {
    if (game.gameOver) return;
    const available = [];
    for (let i = 0; i < game.total; i++) if (!game.revealed[i]) available.push(i);
    if (available.length < 2) return;
    let idx1 = available[Math.floor(Math.random() * available.length)];
    let idx2 = available[Math.floor(Math.random() * available.length)];
    while (idx2 === idx1) idx2 = available[Math.floor(Math.random() * available.length)];
    
    game.revealed[idx1] = true;
    game.revealed[idx2] = true;
    let boardTxt = drawBoard(game.board, game.revealed, game.rows, game.cols);
    const msg = await conn.sendMessage(chatId, { text: `🤖 *دور الروبوت:* اختار ${idx1+1} و ${idx2+1}\n${boardTxt}` });
    
    if (game.board[idx1] === game.board[idx2]) {
        game.botScore++;
        const scoreMsg = await conn.sendMessage(chatId, { text: `✅ الروبوت حصل على زوج! (+1)\nالنتيجة: أنت ${game.playerScore} - ${game.botScore} الروبوت` });
        if (isGameFinished(game.revealed)) {
            clearTimeout(game.timeout);
            delete global.memoryGames[chatId];
            const winner = game.playerScore > game.botScore ? 'player' : (game.botScore > game.playerScore ? 'bot' : 'tie');
            if (winner === 'player') await awardWinner(conn, chatId, m.sender, game.playerScore, game.botScore);
            else if (winner === 'bot') await conn.sendMessage(chatId, { text: `💔 خسرت! ${game.playerScore} - ${game.botScore}` });
            else await conn.sendMessage(chatId, { text: `🤝 تعادل! ${game.playerScore} - ${game.botScore}` });
            return;
        }
        setTimeout(() => botMove(conn, chatId, game), 1500);
    } else {
        const errorMsg = await conn.sendMessage(chatId, { text: `❌ الروبوت أخطأ! ستعاد إغلاق البطاقتين بعد ثانية.` });
        deleteAfterDelay(conn, chatId, errorMsg, 2000);
        setTimeout(async () => {
            if (global.memoryGames[chatId] === game) {
                game.revealed[idx1] = false;
                game.revealed[idx2] = false;
                boardTxt = drawBoard(game.board, game.revealed, game.rows, game.cols);
                await conn.sendMessage(chatId, { text: `🔒 تم إعادة إغلاقهما.\n${boardTxt}\nدورك الآن!` });
                game.turn = 'player';
            }
        }, 1500);
        deleteAfterDelay(conn, chatId, msg, 2000);
    }
}

async function handleBotPlayerMove(m, conn, chatId, sender, idx1, idx2, game) {
    if (game.turn !== 'player') { await m.reply("❌ دور الروبوت!"); return true; }
    if (game.gameOver) return true;
    if (game.revealed[idx1] || game.revealed[idx2]) { await m.reply("❌ مكشوفة!"); return true; }
    try { await conn.sendMessage(chatId, { delete: m.key }); } catch(e) {}
    
    game.revealed[idx1] = true;
    game.revealed[idx2] = true;
    let boardTxt = drawBoard(game.board, game.revealed, game.rows, game.cols);
    const resultMsg = await conn.sendMessage(chatId, { text: `🔍 *اختيارك:*\n${boardTxt}` });
    if (game.board[idx1] === game.board[idx2]) {
        game.playerScore++;
        const scoreMsg = await m.reply(`✅ تطابق! (+1)\nالنتيجة: أنت ${game.playerScore} - ${game.botScore} الروبوت`);
        if (isGameFinished(game.revealed)) {
            clearTimeout(game.timeout);
            delete global.memoryGames[chatId];
            const winner = game.playerScore > game.botScore ? 'player' : (game.botScore > game.playerScore ? 'bot' : 'tie');
            if (winner === 'player') await awardWinner(conn, chatId, sender, game.playerScore, game.botScore);
            else if (winner === 'bot') await conn.sendMessage(chatId, { text: `💔 خسرت! ${game.playerScore} - ${game.botScore}` });
            else await conn.sendMessage(chatId, { text: `🤝 تعادل! ${game.playerScore} - ${game.botScore}` });
            return true;
        }
        game.turn = 'player';
        await conn.sendMessage(chatId, { text: `🎮 دورك مرة أخرى!` });
    } else {
        const errorMsg = await m.reply(`❌ لا تطابق!`);
        deleteAfterDelay(conn, chatId, errorMsg, 2000);
        setTimeout(async () => {
            if (global.memoryGames[chatId] === game) {
                game.revealed[idx1] = false;
                game.revealed[idx2] = false;
                boardTxt = drawBoard(game.board, game.revealed, game.rows, game.cols);
                await conn.sendMessage(chatId, { text: `🔒 تم إعادة إغلاقهما.\n${boardTxt}` });
                game.turn = 'bot';
                await botMove(conn, chatId, game);
            }
        }, 1500);
        deleteAfterDelay(conn, chatId, resultMsg, 2000);
    }
    return true;
}

// ---------- وضع لاعب ضد لاعب (PVP) - مع نفس شكل اللوحة ----------
async function createPvPGame(m, conn, chatId, player1, sizeKey) {
    const size = BOARD_SIZES[sizeKey];
    const board = generateBoard(size.rows, size.cols, size.pairs);
    const revealed = Array(size.total).fill(false);
    const game = {
        mode: 'pvp',
        rows: size.rows,
        cols: size.cols,
        total: size.total,
        board, revealed,
        player1: player1,
        player2: null,
        scores: { [player1]: 0 },
        turn: player1,
        gameOver: false,
        status: 'waiting',
        timeout: setTimeout(() => {
            if (global.memoryGames[chatId] && global.memoryGames[chatId].status === 'waiting') {
                delete global.memoryGames[chatId];
                conn.sendMessage(chatId, { text: "⌛ انتهى وقت انتظار الخصم." });
            }
        }, 30000)
    };
    global.memoryGames[chatId] = game;
    await conn.sendMessage(chatId, {
        text: `🎮 *لعبة الذاكرة (لاعب ضد لاعب)* - لوحة ${size.rows}x${size.cols}\n@${player1.split('@')[0]} ينتظر خصماً.\n\nالخصم يكتب: \`.ذاكرة انضم\` (لديه 30 ثانية)`,
        mentions: [player1]
    });
}

async function joinPvPGame(m, conn, chatId, player2) {
    const game = global.memoryGames[chatId];
    if (!game || game.mode !== 'pvp' || game.status !== 'waiting') {
        return m.reply("❌ لا توجد لعبة PVP نشطة للانضمام. ابدأ بـ `.ذاكرة pvp`.");
    }
    if (game.player2 !== null) return m.reply("❌ اللعبة ممتلئة!");
    if (game.player1 === player2) return m.reply("❌ لا يمكنك لعب ضد نفسك!");
    game.player2 = player2;
    game.status = 'playing';
    game.scores[player2] = 0;
    clearTimeout(game.timeout);
    game.timeout = setTimeout(() => {
        if (global.memoryGames[chatId]) delete global.memoryGames[chatId];
    }, 120000);
    await conn.sendMessage(chatId, {
        text: `🎮 *بدأت اللعبة!*\n${drawBoard(game.board, game.revealed, game.rows, game.cols)}\n\n@${game.player1.split('@')[0]} (❌) يبدأ أولاً.\nأرسل رقمين (مثال: 5 12) باستخدام إيموجي الرقم أو الرقم العادي.`,
        mentions: [game.player1, game.player2]
    });
}

async function handlePvPMove(m, conn, chatId, sender, idx1, idx2, game) {
    if (game.turn !== sender) { await m.reply("❌ ليس دورك!"); return true; }
    if (game.gameOver) return true;
    if (game.revealed[idx1] || game.revealed[idx2]) { await m.reply("❌ إحدى البطاقتين مكشوفة بالفعل!"); return true; }
    try { await conn.sendMessage(chatId, { delete: m.key }); } catch(e) {}
    
    game.revealed[idx1] = true;
    game.revealed[idx2] = true;
    let boardTxt = drawBoard(game.board, game.revealed, game.rows, game.cols);
    await conn.sendMessage(chatId, { text: `🔍 *اختار ${sender === game.player1 ? 'اللاعب الأول' : 'اللاعب الثاني'}*\n${boardTxt}` });
    if (game.board[idx1] === game.board[idx2]) {
        game.scores[sender]++;
        await conn.sendMessage(chatId, { text: `✅ تطابق! (+1 نقطة)\nالنتيجة: ${game.scores[game.player1]} - ${game.scores[game.player2]}` });
        if (isGameFinished(game.revealed)) {
            clearTimeout(game.timeout);
            delete global.memoryGames[chatId];
            const p1Score = game.scores[game.player1];
            const p2Score = game.scores[game.player2];
            let winnerJid = null;
            if (p1Score > p2Score) winnerJid = game.player1;
            else if (p2Score > p1Score) winnerJid = game.player2;
            if (winnerJid) await awardWinner(conn, chatId, winnerJid, p1Score, p2Score);
            else await conn.sendMessage(chatId, { text: `🤝 تعادل! ${p1Score} - ${p2Score}` });
            return true;
        }
        game.turn = sender;
        await conn.sendMessage(chatId, { text: `🎮 دورك مرة أخرى!` });
    } else {
        await conn.sendMessage(chatId, { text: `❌ لا تطابق!` });
        setTimeout(async () => {
            if (global.memoryGames[chatId] === game) {
                game.revealed[idx1] = false;
                game.revealed[idx2] = false;
                boardTxt = drawBoard(game.board, game.revealed, game.rows, game.cols);
                await conn.sendMessage(chatId, { text: `🔒 تم إعادة إغلاقهما.\n${boardTxt}` });
                game.turn = (game.turn === game.player1) ? game.player2 : game.player1;
                await conn.sendMessage(chatId, { text: `🎮 دور ${game.turn === game.player1 ? 'اللاعب الأول' : 'اللاعب الثاني'} الآن!` });
            }
        }, 1500);
    }
    return true;
}

// ---------- الأمر الرئيسي ----------
const handler = async (m, { conn, command, text }) => {
    const chatId = m.chat;
    const args = text.trim();

    if (args === 'حذف' || args === 'delete') {
        if (global.memoryGames[chatId]) {
            clearTimeout(global.memoryGames[chatId].timeout);
            delete global.memoryGames[chatId];
            await m.reply("🗑️ تم إلغاء اللعبة.");
        } else {
            await m.reply("❌ لا توجد لعبة نشطة.");
        }
        return;
    }

    if (args === 'انضم' || args === 'join') {
        const game = global.memoryGames[chatId];
        if (game && game.mode === 'pvp' && game.status === 'waiting') {
            await joinPvPGame(m, conn, chatId, m.sender);
        } else {
            await m.reply("❌ لا توجد لعبة PVP نشطة للانضمام. ابدأ بـ `.ذاكرة pvp`.");
        }
        return;
    }

    if (args.includes('|')) {
        const parts = args.split('|');
        if (parts.length === 3) {
            const [mode, initiator, size] = parts;
            if (initiator !== m.sender) {
                await m.reply("❌ هذا الاختيار ليس لك.");
                return;
            }
            if (size && BOARD_SIZES[size]) {
                if (mode === 'bot') {
                    await createBotGame(m, conn, chatId, m.sender, size);
                } else if (mode === 'pvp') {
                    await createPvPGame(m, conn, chatId, m.sender, size);
                }
                return;
            }
        }
    }

    if (args === 'bot' || args === 'ضد_الروبوت') {
        await askBoardSize(conn, chatId, 'bot', m.sender);
        return;
    }

    if (args === 'pvp' || args === 'لاعب') {
        await askBoardSize(conn, chatId, 'pvp', m.sender);
        return;
    }

    if (!args) {
        const sections = [{
            title: "🎮 اختر وضع اللعب",
            rows: [
                { title: "ضد الروبوت", description: "العب ضد الذكاء الاصطناعي", id: ".ذاكرة bot" },
                { title: "لاعب ضد لاعب", description: "تحدى صديقاً", id: ".ذاكرة pvp" }
            ]
        }];
        await conn.sendButtonNormal(chatId, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: "🧠 *لعبة الذاكرة*\nاختر الوضع:",
            buttons: [{ name: "single_select", params: { title: "⚙️ اختر", sections: sections } }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }

    m.reply(`🎮 *لعبة الذاكرة*\nالاستخدام:\n.ذاكرة - قائمة\n.ذاكرة bot - ضد الروبوت\n.ذاكرة pvp - لاعب ضد لاعب\n.ذاكرة انضم - انضمام لـ PVP\n.ذاكرة حذف - إلغاء`);
};

// معالج الحركات (يدعم الأرقام العادية وإيموجي الأرقام)
handler.before = async (m, { conn }) => {
    if (!m.text) return false;
    const game = global.memoryGames[m.chat];
    if (!game) return false;

    // استخراج رقمين من النص (إما أرقام عادية أو إيموجي أرقام)
    const extractNumber = (t) => {
        const match = t.match(/(\d+)️?/);
        if (match) return parseInt(match[1]);
        return null;
    };
    const parts = m.text.trim().split(/\s+/);
    let numbers = [];
    for (const part of parts) {
        let num = parseInt(part);
        if (isNaN(num)) num = extractNumber(part);
        if (!isNaN(num) && num >= 1 && num <= game.total) numbers.push(num);
    }
    if (numbers.length !== 2) return false;
    let idx1 = numbers[0] - 1;
    let idx2 = numbers[1] - 1;
    if (idx1 === idx2) {
        await m.reply("❌ لا تختار نفس الرقم مرتين!");
        return true;
    }

    if (game.mode === 'bot') return await handleBotPlayerMove(m, conn, m.chat, m.sender, idx1, idx2, game);
    if (game.mode === 'pvp' && game.status === 'playing') return await handlePvPMove(m, conn, m.chat, m.sender, idx1, idx2, game);
    return false;
};

handler.usage = ["ذاكرة"];
handler.category = "games";
handler.command = ["ذاكرة", "memory"];

export default handler;
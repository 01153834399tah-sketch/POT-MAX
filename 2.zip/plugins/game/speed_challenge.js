// plugins/games/speed_challenge.js
// لعبة تحدي السرعة (تنافسية) - الأوامر: .سرعة

if (!global.speedGames) global.speedGames = {};

// دوال مساعدة
function getRandomQuestion() {
    const operations = [
        { text: '×', func: (a,b) => a * b },
        { text: '+', func: (a,b) => a + b },
        { text: '-', func: (a,b) => a - b }
    ];
    const op = operations[Math.floor(Math.random() * operations.length)];
    let a, b, answer;
    if (op.text === '×') {
        a = Math.floor(Math.random() * 10) + 1;
        b = Math.floor(Math.random() * 10) + 1;
        answer = a * b;
    } else if (op.text === '+') {
        a = Math.floor(Math.random() * 50) + 1;
        b = Math.floor(Math.random() * 50) + 1;
        answer = a + b;
    } else {
        a = Math.floor(Math.random() * 50) + 1;
        b = Math.floor(Math.random() * a) + 1;
        answer = a - b;
    }
    return {
        text: `${a} ${op.text} ${b}`,
        answer: answer
    };
}

const handler = async (m, { conn, command }) => {
    const chatId = m.chat;
    
    // إذا كانت هناك لعبة نشطة، نمنع بدء أخرى
    if (global.speedGames[chatId] && global.speedGames[chatId].active) {
        return m.reply("⏳ هناك جولة نشطة بالفعل! انتظر الإجابة على السؤال الحالي.");
    }
    
    // توليد سؤال عشوائي
    const question = getRandomQuestion();
    const startTime = Date.now();
    
    // إرسال السؤال
    const msg = await conn.sendMessage(chatId, {
        text: `⚡ *تحدي السرعة (للجميع)*\n\nالسؤال: ${question.text} = ؟\n\nأول من يجيب إجابة صحيحة يفوز!\nلديك 15 ثانية للإجابة. أرسل الرقم فقط.`
    });
    
    // تخزين حالة اللعبة
    global.speedGames[chatId] = {
        active: true,
        question: question,
        startTime: startTime,
        messageId: msg.key.id,
        winner: null,
        timeout: setTimeout(async () => {
            if (global.speedGames[chatId] && global.speedGames[chatId].active) {
                delete global.speedGames[chatId];
                await conn.sendMessage(chatId, { text: "⌛ انتهى الوقت! لم يجب أحد. أرسل `.سرعة` لبدء جولة جديدة." });
            }
        }, 15000) // 15 ثانية
    };
};

// معالج الإجابات (أول من يجيب يفوز)
handler.before = async (m, { conn }) => {
    const chatId = m.chat;
    const game = global.speedGames[chatId];
    if (!game || !game.active) return false;
    
    // التحقق من أن الرسالة تحتوي على رقم فقط (وليس أمراً)
    const answer = parseInt(m.text.trim());
    if (isNaN(answer)) return false;
    
    // إذا كان هناك فائز بالفعل، نرفض باقي الإجابات
    if (game.winner !== null) return false;
    
    // التحقق من صحة الإجابة
    if (answer !== game.question.answer) return false;
    
    // إلغاء المؤقت وحذف اللعبة (لمنع إجابات أخرى)
    clearTimeout(game.timeout);
    game.active = false;
    game.winner = m.sender;
    
    const endTime = Date.now();
    const responseTime = (endTime - game.startTime) / 1000; // الوقت بالثواني
    
    let rewardXp = 0, rewardCookies = 0;
    let resultText = '';
    
    if (responseTime <= 3) {
        rewardXp = 40;
        rewardCookies = 5;
        resultText = `🎉 *الفائز: @${m.sender.split('@')[0]}* ⚡\nالإجابة الصحيحة: ${game.question.answer}\nالوقت: ${responseTime.toFixed(2)} ثانية\n🏆 +${rewardXp} XP و 🍪 +${rewardCookies} كوكيز.`;
    } else {
        rewardXp = 20;
        rewardCookies = 2;
        resultText = `🎉 *الفائز: @${m.sender.split('@')[0]}*\nالإجابة الصحيحة: ${game.question.answer}\nالوقت: ${responseTime.toFixed(2)} ثانية\n🎁 +${rewardXp} XP و 🍪 +${rewardCookies} كوكيز.`;
    }
    
    // منح المكافأة
    if (global.db?.users[m.sender]) {
        global.db.users[m.sender].xp = (global.db.users[m.sender].xp || 0) + rewardXp;
        global.db.users[m.sender].cookies = (global.db.users[m.sender].cookies || 0) + rewardCookies;
    }
    
    await conn.sendMessage(chatId, { text: resultText, mentions: [m.sender] });
    
    // حذف اللعبة من الذاكرة
    delete global.speedGames[chatId];
    return true;
};

handler.command = ['سرعة', 'speed'];
handler.category = 'games';
handler.usage = ['سرعة'];

export default handler;
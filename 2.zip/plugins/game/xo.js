const MODES = {
    PVP: 'pvp',
    BOT: 'bot'
};

if (!global.xoGames) global.xoGames = {};

// دالة رسم اللوحة الأصلية (بإيموجي الأرقام)
const drawBoard = (b) => [0, 3, 6].map(i =>
    b.slice(i, i + 3).map((c, idx) =>
        c ? (c === 'X' ? '❌' : '⭕') : `${i + idx + 1}️⃣`
    ).join(' | ')
).join('\n');

function checkWinner(board) {
    const lines = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];
    for (const [a, b, c] of lines) {
        if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
    }
    return null;
}

function isDraw(board) {
    return board.every(cell => cell !== null);
}

async function awardWinner(conn, chatId, winnerJid) {
    if (global.db?.users[winnerJid]) {
        global.db.users[winnerJid].xp = (global.db.users[winnerJid].xp || 0) + 500;
        global.db.users[winnerJid].cookies = (global.db.users[winnerJid].cookies || 0) + 10;
    }
    await conn.sendMessage(chatId, {
        text: `🏆 *الفائز:* @${winnerJid.split('@')[0]}\n🎉 حصل على +500 XP و 🍪 +10 كوكيز.`,
        mentions: [winnerJid]
    });
}

// ---------- وضع لاعب ضد لاعب (الكود الأصلي، مع دعم الانضمام عبر .xo) ----------
async function createPvPGame(m, conn, chatId, player1) {
    if (global.xoGames[chatId]) return m.reply("❌ توجد لعبة نشطة بالفعل!");
    const game = {
        mode: MODES.PVP,
        player1: player1,
        player2: null,
        board: Array(9).fill(null),
        turn: 'X',
        status: 'waiting',
        timeout: setTimeout(() => {
            if (global.xoGames[chatId]?.status === 'waiting') {
                delete global.xoGames[chatId];
                conn.sendMessage(chatId, { text: "⌛ انتهى وقت انتظار الخصم." });
            }
        }, 30000)
    };
    global.xoGames[chatId] = game;
    await conn.sendMessage(chatId, {
        text: `🎮 *لعبة XO (لاعب ضد لاعب)*\n@${player1.split('@')[0]} ينتظر خصماً.\n\nللدخول، اكتب:\n\`.xo\`\n(الخصم لديه 30 ثانية)`,
        mentions: [player1]
    });
}

async function joinPvPGame(m, conn, chatId, player2) {
    const game = global.xoGames[chatId];
    if (!game || game.mode !== MODES.PVP || game.status !== 'waiting') {
        await m.reply("❌ لا توجد لعبة PVP نشطة للانضمام.");
        return false;
    }
    if (game.player2 !== null) { await m.reply("❌ اللعبة ممتلئة!"); return false; }
    if (game.player1 === player2) { await m.reply("❌ لا يمكنك لعب ضد نفسك!"); return false; }
    game.player2 = player2;
    game.status = 'playing';
    clearTimeout(game.timeout);
    await conn.sendMessage(chatId, {
        text: `🎮 *بدأت اللعبة!*\n${drawBoard(game.board)}\n\n@${game.player1.split('@')[0]} (❌) ضد @${game.player2.split('@')[0]} (⭕)\n\n@${game.player1.split('@')[0]} يبدأ! أرسل رقم 1-9`,
        mentions: [game.player1, game.player2]
    });
    return true;
}

// ---------- وضع ضد الروبوت ----------
async function createBotGame(m, conn, chatId, player) {
    if (global.xoGames[chatId]) return m.reply("❌ توجد لعبة نشطة بالفعل!");
    const board = Array(9).fill(null);
    const game = {
        mode: MODES.BOT,
        player: player,
        board: board,
        turn: 'X',
        status: 'playing',
        timeout: null
    };
    global.xoGames[chatId] = game;
    await conn.sendMessage(chatId, {
        text: `🤖 *لعبة XO ضد الروبوت*\n${drawBoard(board)}\n\n@${player.split('@')[0]} يبدأ! أرسل رقم 1-9.\n(30 ثانية لكل نقلة)`,
        mentions: [player]
    });
    game.timeout = setTimeout(() => {
        if (global.xoGames[chatId]?.mode === MODES.BOT) {
            delete global.xoGames[chatId];
            conn.sendMessage(chatId, { text: "⌛ انتهى الوقت!" });
        }
    }, 30000);
}

async function botMove(conn, chatId, game) {
    const empty = game.board.reduce((arr, cell, idx) => cell === null ? [...arr, idx] : arr, []);
    if (empty.length === 0) return;
    const idx = empty[Math.floor(Math.random() * empty.length)];
    game.board[idx] = 'O';
    const winner = checkWinner(game.board);
    if (winner) {
        clearTimeout(game.timeout);
        delete global.xoGames[chatId];
        await conn.sendMessage(chatId, { text: `💔 *خسرت!*\n${drawBoard(game.board)}\nالروبوت فاز!` });
        return;
    }
    if (isDraw(game.board)) {
        clearTimeout(game.timeout);
        delete global.xoGames[chatId];
        await conn.sendMessage(chatId, { text: `🤝 *تعادل!*\n${drawBoard(game.board)}` });
        return;
    }
    game.turn = 'X';
    clearTimeout(game.timeout);
    game.timeout = setTimeout(() => {
        if (global.xoGames[chatId]?.mode === MODES.BOT) {
            delete global.xoGames[chatId];
            conn.sendMessage(chatId, { text: "⌛ انتهى الوقت!" });
        }
    }, 30000);
    await conn.sendMessage(chatId, {
        text: `🤖 *دورك الآن*\n${drawBoard(game.board)}\nأرسل رقم 1-9`,
        mentions: [game.player]
    });
}

async function handleBotPlayerMove(m, conn, chatId, sender, move) {
    const game = global.xoGames[chatId];
    if (!game || game.mode !== MODES.BOT) return false;
    if (sender !== game.player) { await m.reply("❌ ليست لعبتك!"); return true; }
    if (game.turn !== 'X') { await m.reply("❌ ليس دورك!"); return true; }
    const index = move - 1;
    if (index < 0 || index > 8 || isNaN(index)) { await m.reply("❌ أرسل رقم 1-9"); return true; }
    if (game.board[index] !== null) { await m.reply("❌ هذه الخانة مشغولة!"); return true; }
    clearTimeout(game.timeout);
    game.board[index] = 'X';
    const winner = checkWinner(game.board);
    if (winner) {
        delete global.xoGames[chatId];
        if (winner === 'X') {
            await awardWinner(conn, chatId, sender);
            await conn.sendMessage(chatId, { text: `🎉 *فزت!*\n${drawBoard(game.board)}` });
        }
        return true;
    }
    if (isDraw(game.board)) {
        delete global.xoGames[chatId];
        await conn.sendMessage(chatId, { text: `🤝 *تعادل!*\n${drawBoard(game.board)}` });
        return true;
    }
    game.turn = 'O';
    await botMove(conn, chatId, game);
    return true;
}

// ---------- الأمر الرئيسي ----------
const handler = async (m, { conn, command, text }) => {
    const chatId = m.chat;
    const args = text.trim().toLowerCase();

    // إلغاء المباراة
    if (args === 'end' || args === 'cancel' || args === 'حذف' || args === 'الغاء') {
        if (global.xoGames[chatId]) {
            clearTimeout(global.xoGames[chatId].timeout);
            delete global.xoGames[chatId];
            await m.reply("🗑️ تم إلغاء المباراة الحالية.");
        } else {
            await m.reply("❌ لا توجد مباراة نشطة للإلغاء.");
        }
        return;
    }

    const activeGame = global.xoGames[chatId];
    // إذا كانت هناك لعبة PVP في وضع الانتظار، أي شخص يكتب `.xo` (بدون وسائط) يحاول الانضمام
    if (activeGame && activeGame.mode === MODES.PVP && activeGame.status === 'waiting' && !args) {
        await joinPvPGame(m, conn, chatId, m.sender);
        return;
    }

    // إذا كانت هناك لعبة نشطة بأي وضع، نمنع بدء أخرى
    if (activeGame) {
        return m.reply("❌ توجد لعبة نشطة حالياً! أنهِها بـ `.xo حذف` أولاً.");
    }

    // عرض قائمة الأوضاع إذا لم يكتب وسائط
    if (!args) {
        const sections = [{
            title: "🎮 اختر وضع اللعب",
            rows: [
                { title: "ضد الروبوت", description: "العب ضد الذكاء الاصطناعي", id: ".xo bot" },
                { title: "لاعب ضد لاعب", description: "تحدى صديقاً", id: ".xo pvp" }
            ]
        }];
        await conn.sendButtonNormal(chatId, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: "❌⭕ *لعبة XO (Tic-Tac-Toe)*\nاختر الوضع المناسب:",
            buttons: [{
                name: "single_select",
                params: { title: "⚙️ اختر الوضع", sections: sections }
            }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }

    if (args === 'bot' || args === 'روبوت') {
        await createBotGame(m, conn, chatId, m.sender);
    } else if (args === 'pvp' || args === 'لاعب') {
        await createPvPGame(m, conn, chatId, m.sender);
    } else {
        m.reply(`الاستخدام:\n.xo - قائمة\n.xo bot - ضد الروبوت\n.xo pvp - لاعب ضد لاعب\n.xo حذف - إلغاء المباراة`);
    }
};

// معالج الحركات (يدعم الأرقام العادية)
handler.before = async (m, { conn }) => {
    if (!m.text) return false;
    const game = global.xoGames[m.chat];
    if (!game) return false;

    const move = parseInt(m.text.trim());
    if (isNaN(move) || move < 1 || move > 9) return false;

    if (game.mode === MODES.PVP && game.status === 'playing') {
        const currentPlayer = game.turn === 'X' ? game.player1 : game.player2;
        if (m.sender !== currentPlayer) { await m.reply("❌ ليس دورك!"); return true; }
        const idx = move - 1;
        if (game.board[idx] !== null) { await m.reply("❌ هذه الخانة مشغولة!"); return true; }
        game.board[idx] = game.turn;
        const winner = checkWinner(game.board);
        if (winner) {
            const winnerJid = winner === 'X' ? game.player1 : game.player2;
            await awardWinner(conn, m.chat, winnerJid);
            await conn.sendMessage(m.chat, { text: `🎉 *فاز @${winnerJid.split('@')[0]}!*\n${drawBoard(game.board)}`, mentions: [winnerJid] });
            delete global.xoGames[m.chat];
            return true;
        }
        if (isDraw(game.board)) {
            await conn.sendMessage(m.chat, { text: `🤝 *تعادل!*\n${drawBoard(game.board)}` });
            delete global.xoGames[m.chat];
            return true;
        }
        game.turn = game.turn === 'X' ? 'O' : 'X';
        const nextPlayer = game.turn === 'X' ? game.player1 : game.player2;
        await conn.sendMessage(m.chat, {
            text: `${drawBoard(game.board)}\n\n@${nextPlayer.split('@')[0]} دورك! أرسل رقم 1-9`,
            mentions: [nextPlayer]
        });
        return true;
    }

    if (game.mode === MODES.BOT && game.status === 'playing') {
        await handleBotPlayerMove(m, conn, m.chat, m.sender, move);
        return true;
    }
    return false;
};

handler.usage = ["xo"];
handler.category = "games";
handler.command = ["xo", "اكس"];

export default handler;
// plugins/games/caine.js
// لعبة Caine - مغامرات يومية مع تحديات وألغاز

// 📚 قاعدة بيانات اللعبة
const SCENARIOS = [
    {
        prompt: '🎪 *لقوا المفتاح في خيمة الرعب خلال 5 دقايق قبل ما الأضواء تطفي!* 🔦\n\n📌 الإشارة: "المفتاح تحت السجادة الحمرا"',
        solution: 'السجادة الحمرا',
        timeLimit: 5, // دقائق
        type: 'find_key'
    },
    {
        prompt: '🌀 *فكوا لغز المرايا خلال 3 دقايق قبل ما ينعكس الواقع!* 🪞\n\n📌 الإشارة: "المرايا بتقول كلمة السر: انعكاس"',
        solution: 'انعكاس',
        timeLimit: 3,
        type: 'mirror_puzzle'
    },
    {
        prompt: '🕰️ *اهربوا من غرفة الساعات قبل ما العقارب توقف!* ⏳\n\n📌 الإشارة: "الرقم السحري هو 7"',
        solution: '7',
        timeLimit: 4,
        type: 'clock_room'
    },
    {
        prompt: '🎭 *اكتشفوا هوية المهرج خلال 6 دقايق قبل ما يختفي!* 🤡\n\n📌 الإشارة: "المهرج اسمه بوبو"',
        solution: 'بوبو',
        timeLimit: 6,
        type: 'clown_identity'
    },
    {
        prompt: '💡 *شغلوا الأضواء في مدينة الألعاب خلال 5 دقايق قبل ما تتحجر!* 🎠\n\n📌 الإشارة: "الكلمة المفتاحية: ضوء"',
        solution: 'ضوء',
        timeLimit: 5,
        type: 'light_city'
    }
];

// 🧠 دالة لجلب مغامرة عشوائية
function getRandomScenario() {
    return SCENARIOS[Math.floor(Math.random() * SCENARIOS.length)];
}

// ⏱️ دالة لتنسيق الوقت المتبقي
function formatTime(minutes) {
    if (minutes < 1) return `${Math.floor(minutes * 60)} ثانية`;
    return `${Math.floor(minutes)} دقيقة و ${Math.floor((minutes % 1) * 60)} ثانية`;
}

// ========== الأمر الرئيسي ==========
const handler = async (m, { conn, text, command }) => {
    const chatId = m.chat;
    const userId = m.sender;

    // تهيئة قاعدة البيانات
    if (!global.db) global.db = {};
    if (!global.db.caine_games) global.db.caine_games = {};
    if (!global.db.caine_players) global.db.caine_players = {};

    // ✅ التحقق من وجود لعبة نشطة
    if (global.db.caine_games[chatId]?.active) {
        return m.reply('⚠️ *في مغامرة جارية بالفعل!*\nحلوا اللغز الأول قبل ما نبدأ مغامرة جديدة.');
    }

    // ✅ بدء مغامرة جديدة
    const scenario = getRandomScenario();
    const startTime = Date.now();
    const deadline = startTime + (scenario.timeLimit * 60 * 1000);

    // تخزين حالة اللعبة
    global.db.caine_games[chatId] = {
        active: true,
        scenario: scenario,
        startTime: startTime,
        deadline: deadline,
        participants: [],
        solved: false,
        solvedBy: null
    };

    // إضافة المشاركين (المستخدمين الحاليين في الشات)
    const metadata = await conn.groupMetadata(chatId).catch(() => null);
    if (metadata) {
        global.db.caine_games[chatId].participants = metadata.participants.map(p => p.id);
    } else {
        global.db.caine_games[chatId].participants = [userId];
    }

    // 📢 إعلان المغامرة
    const announcement = `
╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ *🕹️ كـايـن يـقـدم لـكـم مـغـامـرة جـديـدة!* 🎭
╰─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╯

${scenario.prompt}

⏱️ *الوقت المتبقي:* ${scenario.timeLimit} دقائق
👥 *المشاركون:* كل من في المجموعة

💡 *أرسل الإجابة الصحيحة في الشات لحل اللغز!*
    `.trim();

    await conn.sendMessage(m.chat, {
        image: { url: 'https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg' },
        caption: announcement,
        mentions: [m.sender]
    });

    // ⏱️ ضبط المؤقت لانتهاء الوقت
    setTimeout(async () => {
        const game = global.db.caine_games[chatId];
        if (!game || !game.active) return;
        if (game.solved) return;

        // ❌ فشل التحدي
        game.active = false;
        const failedMessage = `
╭─┈─┈─┈─⟞💀⟝─┈─┈─┈─╮
┃ *😱 انتهى الوقت! لم يتم حل اللغز!* 💀
╰─┈─┈─┈─⟞💀⟝─┈─┈─┈─╯

🔮 *الجميع يتحولون إلى NPCs في الجولة القادمة!* 🧟

💡 *اللغز كان:* "${game.scenario.solution}"
🔄 *اللعبة ستعيد تشغيلها لاحقاً...*
        `.trim();

        await conn.sendMessage(chatId, { text: failedMessage });
        delete global.db.caine_games[chatId];

        // تحويل المشاركين إلى NPCs
        for (const participant of game.participants) {
            if (!global.db.caine_players[participant]) {
                global.db.caine_players[participant] = { escapePoints: 0, isNPC: false };
            }
            global.db.caine_players[participant].isNPC = true;
        }

    }, scenario.timeLimit * 60 * 1000);
};

// ========== معالج الرسائل (لحل اللغز) ==========
handler.before = async (m, { conn }) => {
    const chatId = m.chat;
    const userId = m.sender;
    const text = m.text?.trim();

    if (!text) return false;
    if (!global.db?.caine_games?.[chatId]?.active) return false;

    const game = global.db.caine_games[chatId];
    if (game.solved) return false;

    // 🎯 التحقق من الإجابة
    const solution = game.scenario.solution.toLowerCase();
    const userAnswer = text.toLowerCase();

    // التحقق إذا كانت الإجابة صحيحة (أو تحتوي على الكلمة المفتاحية)
    if (userAnswer.includes(solution) || solution.includes(userAnswer) || userAnswer === solution) {
        game.solved = true;
        game.solvedBy = userId;

        // ✅ إضافة نقاط هروب للمشاركين
        const participants = game.participants;
        const escapePoints = 10;

        for (const participant of participants) {
            if (!global.db.caine_players[participant]) {
                global.db.caine_players[participant] = { escapePoints: 0, isNPC: false };
            }
            if (!global.db.caine_players[participant].isNPC) {
                global.db.caine_players[participant].escapePoints += escapePoints;
            }
        }

        // إعلان الفوز
        const winnerMessage = `
╭─┈─┈─┈─⟞🎉⟝─┈─┈─┈─╮
┃ *✅ تـم حـل الـلـغـز!* 🎉
╰─┈─┈─┈─⟞🎉⟝─┈─┈─┈─╯

🏆 *اللاعب:* @${userId.split('@')[0]}
💡 *الإجابة:* "${text}"
🕒 *الوقت المستغرق:* ${((Date.now() - game.startTime) / 1000).toFixed(1)} ثانية

🎁 *المكافأة:* ${escapePoints} نقطة هروب لكل مشارك!

💬 *تهانينا! استعدوا للمغامرة القادمة.* 🎪
        `.trim();

        await conn.sendMessage(chatId, {
            text: winnerMessage,
            mentions: [userId, ...participants]
        });

        delete global.db.caine_games[chatId];
        return true;
    }

    return false;
};

// ========== أمر عرض النقاط ==========
handler.points = async (m, { conn }) => {
    const userId = m.sender;
    const player = global.db?.caine_players?.[userId];
    if (!player) {
        return m.reply('📊 *ليس لديك نقاط هروب بعد!*\nشارك في المغامرات لكسب النقاط.');
    }

    const status = player.isNPC ? '🧟 NPC' : '🕹️ لاعب';
    const msg = `
╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ *📊 نقـاط الـهـروب*
╰─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╯

👤 @${userId.split('@')[0]}
⭐ النقاط: *${player.escapePoints}*
🏷️ الحالة: ${status}

💬 *استمر في المشاركة لتحصل على نقاط أكثر!* 🚀
    `.trim();

    return m.reply(msg);
};

// ========== تصدير الأوامر ==========
handler.command = ['كاين', 'caine', 'مغامرة'];
handler.category = 'games';
handler.usage = ['كاين'];

export default handler;
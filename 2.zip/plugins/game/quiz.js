const TIMEOUT_SECONDS = 45; // المهلة 45 ثانية
const QUIZ_API_URL = 'https://opentdb.com/api.php';

// الفئات المسموحة (ممتعة وسهلة)
const ALLOWED_CATEGORIES = {
    'كرة القدم (رياضة)': 21,
    'حيوانات': 27,
    'ألعاب إلكترونية': 15,
    'طبيعة': 17
};

// دالة الترجمة باستخدام MyMemory API (مجاني)
async function translateText(text, targetLang = 'ar') {
    if (!text || text.trim() === '') return text;
    try {
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${targetLang}`;
        const res = await fetch(url);
        const data = await res.json();
        return data.responseData.translatedText || text;
    } catch (err) {
        console.error('Translation error:', err);
        return text;
    }
}

// جلب سؤال سهل من فئة عشوائية من القائمة، ثم ترجمته
async function fetchAndTranslateQuestion() {
    try {
        // اختيار فئة عشوائية
        const categoryNames = Object.keys(ALLOWED_CATEGORIES);
        const randomCategoryName = categoryNames[Math.floor(Math.random() * categoryNames.length)];
        const categoryId = ALLOWED_CATEGORIES[randomCategoryName];
        
        // طلب سؤال سهل (difficulty=easy)
        const url = `${QUIZ_API_URL}?amount=1&type=multiple&category=${categoryId}&difficulty=easy`;
        const res = await fetch(url);
        const data = await res.json();
        if (data.response_code !== 0 || !data.results || !data.results.length) {
            throw new Error('No questions available for this category');
        }
        const q = data.results[0];
        const translatedQuestion = await translateText(q.question);
        let allOptions = [q.correct_answer, ...q.incorrect_answers];
        let translatedOptions = await Promise.all(allOptions.map(opt => translateText(opt)));
        // خلط الإجابات
        for (let i = translatedOptions.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [translatedOptions[i], translatedOptions[j]] = [translatedOptions[j], translatedOptions[i]];
        }
        const correctAnswerTranslated = await translateText(q.correct_answer);
        const correctIndex = translatedOptions.indexOf(correctAnswerTranslated);
        const explanation = `الفئة: ${randomCategoryName} | الصعوبة: سهلة`;
        return {
            question: translatedQuestion,
            options: translatedOptions,
            correct: correctIndex,
            explanation: await translateText(explanation)
        };
    } catch (err) {
        console.error('Error:', err);
        return null;
    }
}

if (!global.quizGames) global.quizGames = {};

const handler = async (m, { conn, command }) => {
    const chatId = m.chat;
    if (global.quizGames[chatId]?.active) {
        return m.reply("❌ هناك لعبة نشطة بالفعل! انتظر حتى تنتهي.");
    }

    const q = await fetchAndTranslateQuestion();
    if (!q) return m.reply("❌ حدث خطأ في جلب السؤال أو ترجمته. حاول مرة أخرى.");

    const sections = [{
        title: "🎓 اختر الإجابة الصحيحة",
        rows: q.options.map((opt, idx) => ({
            title: opt,
            description: `اختر: ${opt}`,
            id: `.quiz_answer ${chatId}|${q.correct}|${idx}|${q.explanation}|${q.question}|${JSON.stringify(q.options)}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: `🧠 *سؤال وجواب (ممتع وسهل)*\n\n${q.question}\n\nاختر الإجابة الصحيحة:`,
        buttons: [{
            name: "single_select",
            params: {
                title: "📋 اختر الإجابة",
                sections: sections
            }
        }],
        mentions: [m.sender],
        newsletter: {
            name: 'Pomni AI ~ Channel 🕷️',
            jid: '120363427163691139@newsletter'
        }
    }, global.reply_status);

    const timeoutObj = setTimeout(() => {
        if (global.quizGames[chatId]?.active) {
            delete global.quizGames[chatId];
            conn.sendMessage(chatId, { text: "⌛ انتهى وقت الإجابة! أرسل `.سؤال` لبدء جولة جديدة." });
        }
    }, TIMEOUT_SECONDS * 1000);

    global.quizGames[chatId] = {
        active: true,
        question: q.question,
        correctIndex: q.correct,
        explanation: q.explanation,
        options: q.options,
        timeoutObj: timeoutObj
    };
};

handler.before = async (m, { conn }) => {
    if (!m.text || !m.text.startsWith('.quiz_answer')) return false;

    const parts = m.text.split(' ');
    if (parts.length < 2) return false;
    const payload = parts[1];
    const [chatId, correctIdx, chosenIdx, explanation, question, optionsJson] = payload.split('|');
    if (!chatId || correctIdx === undefined || chosenIdx === undefined) return false;
    if (chatId !== m.chat) return false;

    const game = global.quizGames[chatId];
    if (!game?.active) {
        await m.reply("❌ لا توجد لعبة نشطة. ابدأ واحدة بـ `.سؤال`");
        return true;
    }

    const isCorrect = (parseInt(chosenIdx) === parseInt(correctIdx));
    if (isCorrect) {
        clearTimeout(game.timeoutObj);
        delete global.quizGames[chatId];
        const xpGain = 50, cookieGain = 5;
        if (global.db?.users[m.sender]) {
            global.db.users[m.sender].xp = (global.db.users[m.sender].xp || 0) + xpGain;
            global.db.users[m.sender].cookies = (global.db.users[m.sender].cookies || 0) + cookieGain;
        }
        await conn.sendMessage(chatId, {
            text: `✅ *إجابة صحيحة!*\n🎉 @${m.sender.split('@')[0]} ربحت ${xpGain} XP و 🍪 ${cookieGain} كوكيز.\n📝 ${explanation}`,
            mentions: [m.sender]
        });
    } else {
        await conn.sendMessage(chatId, {
            text: `❌ *إجابة خاطئة!*\n😢 حاول مرة أخرى. لديك ${TIMEOUT_SECONDS} ثانية إضافية.\n📝 ${explanation}`,
            mentions: [m.sender]
        });
        clearTimeout(game.timeoutObj);
        const newTimeout = setTimeout(() => {
            if (global.quizGames[chatId]?.active) {
                delete global.quizGames[chatId];
                conn.sendMessage(chatId, { text: "⌛ انتهى وقت الإجابة! أرسل `.سؤال` لبدء جولة جديدة." });
            }
        }, TIMEOUT_SECONDS * 1000);
        game.timeoutObj = newTimeout;
    }
    return true;
};

handler.usage = ["سؤال"];
handler.category = "games";
handler.command = ["سؤال", "quiz"];

export default handler;
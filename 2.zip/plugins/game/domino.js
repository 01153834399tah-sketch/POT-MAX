// plugins/games/domino.js
// لعبة دومينو مع نظام نقاط تراكمي حتى 100
// الأوامر: .دومينو , .دومينو حذف

if (!global.dominoGames) global.dominoGames = {};

// ----------------------------------- إعدادات -----------------------------------
const ALL_TILES = [];
const tileValues = [
    [0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],
    [1,1],[1,2],[1,3],[1,4],[1,5],[1,6],
    [2,2],[2,3],[2,4],[2,5],[2,6],
    [3,3],[3,4],[3,5],[3,6],
    [4,4],[4,5],[4,6],
    [5,5],[5,6],
    [6,6]
];
for (let [a, b] of tileValues) ALL_TILES.push({ a, b, id: `${a}-${b}` });

const TILES_PER_PLAYER = { 2: 7, 3: 5, 4: 4 };
const WINNING_SCORE = 100; // النقاط المطلوبة للفوز بالمباراة

function getDominoSymbol(a, b) {
    return `[${a}|${b}]`;
}

function shuffleArray(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

function formatBoard(board) {
    return board.map(tile => getDominoSymbol(tile.a, tile.b)).join('  ');
}

function getPhoneNumber(jid) {
    if (!jid) return '';
    return jid.split(':')[0].split('@')[0];
}

// حساب نقاط القطع في اليد
function calculateHandPoints(hand) {
    return hand.reduce((sum, tile) => sum + tile.a + tile.b, 0);
}

// نهاية الجولة: حساب النقاط وإعلان الفائز بالجولة، ثم تحضير الجولة التالية أو إنهاء المباراة
async function endRound(conn, chatId, game, winnerJid) {
    if (game.roundEnded) return; // منع التكرار
    game.roundEnded = true;
    
    // حساب نقاط الخاسرين
    let totalPoints = 0;
    for (let player of game.players) {
        if (player !== winnerJid) {
            totalPoints += calculateHandPoints(game.hands[player]);
        }
    }
    
    // إضافة النقاط للفائز
    game.scores[winnerJid] = (game.scores[winnerJid] || 0) + totalPoints;
    
    // إعلان نتائج الجولة
    let msg = `🎯 *نتيجة الجولة*\n🏆 الفائز: @${getPhoneNumber(winnerJid)}\n📊 النقاط المكتسبة: +${totalPoints}\n📈 الرصيد الحالي: ${game.scores[winnerJid]} نقطة\n\n`;
    for (let player of game.players) {
        if (player !== winnerJid) {
            msg += `👤 @${getPhoneNumber(player)}: ${calculateHandPoints(game.hands[player])} نقطة متبقية\n`;
        }
    }
    await conn.sendMessage(chatId, { text: msg, mentions: game.players });
    
    // التحقق من الفوز بالمباراة
    if (game.scores[winnerJid] >= WINNING_SCORE) {
        await awardWinner(conn, chatId, winnerJid);
        await endGame(conn, chatId, game);
        return;
    }
    
    // بدء جولة جديدة (إعادة توزيع القطع مع الاحتفاظ بالنقاط)
    await startNewRound(conn, chatId, game);
}

// بدء جولة جديدة
async function startNewRound(conn, chatId, game) {
    // إعادة تعيين اللوحة والأيدي والمخزون
    let shuffled = shuffleArray([...ALL_TILES]);
    const tilesPerPlayer = TILES_PER_PLAYER[game.playerCount];
    for (let i = 0; i < game.players.length; i++) {
        game.hands[game.players[i]] = shuffled.slice(i * tilesPerPlayer, (i+1) * tilesPerPlayer);
    }
    game.boneyard = shuffled.slice(game.players.length * tilesPerPlayer);
    game.board = [];
    game.roundEnded = false;
    
    // تحديد من يبدأ الجولة (صاحب أعلى قطعة مزدوجة)
    let bestValue = -1;
    let bestPlayer = null;
    for (let player of game.players) {
        for (let tile of game.hands[player]) {
            if (tile.a === tile.b && tile.a > bestValue) {
                bestValue = tile.a;
                bestPlayer = player;
            }
        }
    }
    if (!bestPlayer) {
        // إذا لم توجد قطع مزدوجة، يبدأ عشوائي
        bestPlayer = game.players[Math.floor(Math.random() * game.players.length)];
    }
    game.turnIndex = game.players.indexOf(bestPlayer);
    
    // إرسال القطع لكل لاعب
    for (let player of game.players) {
        const handStr = game.hands[player].map(t => getDominoSymbol(t.a, t.b)).join('  ');
        await conn.sendMessage(player, { text: `🎴 *قطعك في الجولة الجديدة (${game.hands[player].length} قطعة):*\n${handStr}` });
    }
    
    const startPlayer = game.players[game.turnIndex];
    await conn.sendMessage(chatId, {
        text: `🔄 *جولة جديدة!*\nالنتيجة الحالية:\n${game.players.map(p => `@${getPhoneNumber(p)}: ${game.scores[p] || 0} نقطة`).join('\n')}\n\n@${getPhoneNumber(startPlayer)} يبدأ الجولة! سيتم إرسال الأزرار لك في الخاص.`,
        mentions: game.players
    });
    await sendChoiceButtons(conn, startPlayer, chatId, game.hands[startPlayer], game);
}

async function awardWinner(conn, chatId, winnerJid) {
    if (global.db?.users[winnerJid]) {
        global.db.users[winnerJid].xp = (global.db.users[winnerJid].xp || 0) + 200;
        global.db.users[winnerJid].cookies = (global.db.users[winnerJid].cookies || 0) + 20;
    }
    await conn.sendMessage(chatId, {
        text: `🏆 *الفائز بالمباراة:* @${getPhoneNumber(winnerJid)}\n🎉 حصل على +200 XP و 🍪 +20 كوكيز.\n🏅 النقاط النهائية: ${global.dominoGames[chatId]?.scores[winnerJid] || 0}`,
        mentions: [winnerJid]
    });
}

async function endGame(conn, chatId, game) {
    if (game.turnTimeout) clearTimeout(game.turnTimeout);
    delete global.dominoGames[chatId];
    await conn.sendMessage(chatId, { text: "⌛ انتهت اللعبة." });
}

// إرسال أزرار للاعب
async function sendChoiceButtons(conn, playerJid, chatId, hand, game) {
    if (hand.length === 0) {
        // اللاعب أنهى كل قطعه -> يفوز بالجولة فوراً
        await endRound(conn, chatId, game, playerJid);
        return;
    }
    const board = game.board;
    const buttons = [];

    if (board.length === 0) {
        const sections = [{
            title: "🎴 اختر قطعة لبدء الجولة",
            rows: hand.map((tile, i) => ({
                title: getDominoSymbol(tile.a, tile.b),
                description: `اختر هذه القطعة`,
                id: `.domino_first|${chatId}|${playerJid}|${i}`
            }))
        }];
        await conn.sendButtonNormal(playerJid, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: `🎮 دورك الآن!\nاللوحة فارغة. اختر قطعة لتبدأ بها الجولة:`,
            buttons: [{
                name: "single_select",
                params: {
                    title: "🎴 اختر قطعة",
                    sections: sections
                }
            }],
            mentions: [playerJid]
        }, global.reply_status);
        return;
    }

    const leftVal = board[0].a;
    const rightVal = board[board.length-1].b;
    const leftOptions = [];
    const rightOptions = [];
    for (let i = 0; i < hand.length; i++) {
        const tile = hand[i];
        const symbol = getDominoSymbol(tile.a, tile.b);
        if (tile.a === leftVal || tile.b === leftVal) {
            leftOptions.push({
                title: symbol,
                description: `ضع على اليسار`,
                id: `.domino_move|${chatId}|${playerJid}|${i}|left`
            });
        }
        if (tile.a === rightVal || tile.b === rightVal) {
            rightOptions.push({
                title: symbol,
                description: `ضع على اليمين`,
                id: `.domino_move|${chatId}|${playerJid}|${i}|right`
            });
        }
    }

    const sections = [];
    if (leftOptions.length) sections.push({ title: "⬅️ وضع على اليسار", rows: leftOptions });
    if (rightOptions.length) sections.push({ title: "➡️ وضع على اليمين", rows: rightOptions });
    if (game.boneyard.length > 0) {
        sections.push({
            title: "🃏 سحب قطعة",
            rows: [{
                title: "سحب قطعة من المخزون",
                description: `${game.boneyard.length} قطعة متبقية`,
                id: `.domino_draw|${chatId}|${playerJid}`
            }]
        });
    }

    if (sections.length === 0) {
        // لا توجد حركات ولا قطع للسحب: تنتهي الجولة، والفائز من لديه أقل نقاط في يده
        let lowestPoints = Infinity;
        let winner = null;
        for (let player of game.players) {
            const pts = calculateHandPoints(game.hands[player]);
            if (pts < lowestPoints) {
                lowestPoints = pts;
                winner = player;
            }
        }
        await endRound(conn, chatId, game, winner);
        return;
    }

    await conn.sendButtonNormal(playerJid, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: `🎮 دورك الآن!\nاللوحة:\n${formatBoard(board)}\nاختر حركة:`,
        buttons: [{
            name: "single_select",
            params: {
                title: "🎮 اختر حركة",
                sections: sections
            }
        }],
        mentions: [playerJid]
    }, global.reply_status);
}
// ----------------------------------- حركة الروبوت الذكية -----------------------------------
async function botMove(conn, chatId, game) {
    const bot = game.botPlayer;
    const hand = game.hands[bot];
    const board = game.board;

    if (board.length === 0) {
        let bestIdx = 0;
        for (let i = 0; i < hand.length; i++) {
            if (hand[i].a === hand[i].b && hand[i].a > hand[bestIdx].a) bestIdx = i;
        }
        const tile = hand[bestIdx];
        hand.splice(bestIdx, 1);
        game.board = [tile];
        await conn.sendMessage(chatId, {
            text: `🤖 *الروبوت* بدأ الجولة بقطعة: ${getDominoSymbol(tile.a, tile.b)}.\nاللوحة:\n${formatBoard(game.board)}`
        });
        if (hand.length === 0) {
            await endRound(conn, chatId, game, bot);
            return;
        }
        game.turnIndex = 0;
        const nextPlayer = game.players[0];
        await sendChoiceButtons(conn, nextPlayer, chatId, game.hands[nextPlayer], game);
        return;
    }

    const leftVal = board[0].a;
    const rightVal = board[board.length-1].b;
    let chosenIdx = -1;
    let chosenSide = null;
    for (let i = 0; i < hand.length; i++) {
        const tile = hand[i];
        if (tile.a === leftVal || tile.b === leftVal) {
            chosenIdx = i;
            chosenSide = 'left';
            break;
        }
        if (tile.a === rightVal || tile.b === rightVal) {
            chosenIdx = i;
            chosenSide = 'right';
            break;
        }
    }
    if (chosenIdx !== -1) {
        let tile = hand[chosenIdx];
        hand.splice(chosenIdx, 1);
        if (chosenSide === 'left') {
            if (tile.a !== leftVal && tile.b === leftVal) tile = { a: tile.b, b: tile.a };
            game.board.unshift(tile);
        } else {
            if (tile.a !== rightVal && tile.b === rightVal) tile = { a: tile.b, b: tile.a };
            game.board.push(tile);
        }
        await conn.sendMessage(chatId, {
            text: `🤖 *الروبوت* وضع ${getDominoSymbol(tile.a, tile.b)} على ال${chosenSide === 'left' ? 'يسار' : 'يمين'}.\nاللوحة:\n${formatBoard(game.board)}`
        });
        if (hand.length === 0) {
            await endRound(conn, chatId, game, bot);
            return;
        }
        game.turnIndex = (game.turnIndex + 1) % game.players.length;
        const nextPlayer = game.players[game.turnIndex];
        await sendChoiceButtons(conn, nextPlayer, chatId, game.hands[nextPlayer], game);
        return;
    }
    if (game.boneyard.length > 0) {
        const drawn = game.boneyard.pop();
        hand.push(drawn);
        await conn.sendMessage(chatId, { text: `🤖 *الروبوت* سحب قطعة: ${getDominoSymbol(drawn.a, drawn.b)}.` });
        await botMove(conn, chatId, game);
    } else {
        // لا حركة ولا مخزون -> انتهاء الجولة، الفائز من لديه أقل نقاط
        let lowestPoints = Infinity;
        let winner = null;
        for (let player of game.players) {
            const pts = calculateHandPoints(game.hands[player]);
            if (pts < lowestPoints) {
                lowestPoints = pts;
                winner = player;
            }
        }
        await endRound(conn, chatId, game, winner);
    }
}

// ----------------------------------- أوامر اللعبة -----------------------------------
const handler = async (m, { conn, command, text, bot }) => {
    const chatId = m.chat;
    const isOwner = bot.config?.owners?.some(o => getPhoneNumber(o.jid) === getPhoneNumber(m.sender));
    if (!isOwner) return m.reply("❌ هذا الأمر للمطورين الرئيسيين فقط.");
    
    const args = text.trim().toLowerCase().split(/\s+/);
    
    if (args[0] === 'حذف' || args[0] === 'delete' || args[0] === 'الغاء') {
        if (global.dominoGames[chatId]) {
            clearTimeout(global.dominoGames[chatId].turnTimeout);
            delete global.dominoGames[chatId];
            await m.reply("🗑️ تم حذف المباراة.");
        } else {
            await m.reply("❌ لا توجد مباراة نشطة.");
        }
        return;
    }
    
    if (command === 'دومينو' && !text) {
        const sections = [{
            title: "🎮 اختر وضع اللعب",
            rows: [
                { title: "ضد الروبوت", description: "العب ضد الذكاء الاصطناعي", id: ".دومينو وضع_روبوت" },
                { title: "لاعب ضد لاعب", description: "تحدى أصدقائك (2-4 لاعبين)", id: ".دومينو وضع_متعدد" }
            ]
        }];
        await conn.sendButtonNormal(chatId, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: "🎲 *لعبة الدومينو (نظام النقاط حتى 100)*\nاختر وضع اللعب:",
            buttons: [{ name: "single_select", params: { title: "🎮 اختر", sections: sections } }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }
    
    if (command === 'دومينو' && text === 'وضع_روبوت') {
        if (global.dominoGames[chatId]) return m.reply("❌ توجد لعبة نشطة بالفعل!");
        const game = {
            mode: 'bot',
            playerCount: 2,
            players: [m.sender, 'BOT'],
            botPlayer: 'BOT',
            board: [],
            hands: {},
            scores: { [m.sender]: 0, BOT: 0 },
            turnIndex: 0,
            status: 'playing',
            boneyard: [],
            turnTimeout: null,
            roundEnded: false
        };
        let shuffled = shuffleArray([...ALL_TILES]);
        game.hands[m.sender] = shuffled.slice(0, 7);
        game.hands['BOT'] = shuffled.slice(7, 14);
        game.boneyard = shuffled.slice(14);
        let bestHuman = -1, bestBot = -1;
        for (let tile of game.hands[m.sender]) if (tile.a === tile.b && tile.a > bestHuman) bestHuman = tile.a;
        for (let tile of game.hands['BOT']) if (tile.a === tile.b && tile.a > bestBot) bestBot = tile.a;
        game.turnIndex = (bestHuman >= bestBot) ? 0 : 1;
        global.dominoGames[chatId] = game;
        const handStr = game.hands[m.sender].map(t => getDominoSymbol(t.a, t.b)).join('  ');
        await conn.sendMessage(m.sender, { text: `🎴 *قطعك في الجولة الأولى (ضد الروبوت):*\n${handStr}` });
        await conn.sendMessage(chatId, {
            text: `🤖 *بدء مباراة دومينو ضد الروبوت (الهدف ${WINNING_SCORE} نقطة)*\n@${getPhoneNumber(m.sender)} يبدأ!${game.turnIndex === 1 ? ' (الروبوت يبدأ)' : ''}`,
            mentions: [m.sender]
        });
        if (game.turnIndex === 0) {
            await sendChoiceButtons(conn, m.sender, chatId, game.hands[m.sender], game);
            game.turnTimeout = setTimeout(() => {
                if (global.dominoGames[chatId] && global.dominoGames[chatId].status === 'playing') {
                    conn.sendMessage(chatId, { text: `⌛ انتهى وقتك. يتم تمرير الدور للروبوت.` });
                    game.turnIndex = 1;
                    botMove(conn, chatId, game);
                }
            }, 60000);
        } else {
            await botMove(conn, chatId, game);
        }
        return;
    }
    
    if (command === 'دومينو' && text === 'وضع_متعدد') {
        const sections = [{
            title: "🎮 اختر عدد اللاعبين",
            rows: [
                { title: "2 لاعبين", description: "كل لاعب 7 قطع", id: ".دومينو 2" },
                { title: "3 لاعبين", description: "كل لاعب 5 قطع", id: ".دومينو 3" },
                { title: "4 لاعبين", description: "كل لاعب 4 قطع", id: ".دومينو 4" }
            ]
        }];
        await conn.sendButtonNormal(chatId, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: "🎲 *لعبة الدومينو (لاعب ضد لاعب)*\nاختر عدد اللاعبين:",
            buttons: [{ name: "single_select", params: { title: "🎮 اختر", sections: sections } }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }
    
    if (command === 'دومينو' && ['2','3','4'].includes(text)) {
        const playerCount = parseInt(text);
        if (global.dominoGames[chatId]) return m.reply("❌ توجد لعبة نشطة بالفعل!");
        const players = [m.sender];
        const scores = {};
        scores[m.sender] = 0;
        for (let i = 1; i < playerCount; i++) {
            scores[`P${i+1}`] = 0;
        }
        global.dominoGames[chatId] = {
            mode: 'multi',
            playerCount: playerCount,
            players: players,
            scores: scores,
            board: [],
            hands: {},
            turnIndex: 0,
            status: 'waiting',
            boneyard: [],
            turnTimeout: null,
            roundEnded: false
        };
        await conn.sendMessage(chatId, {
            text: `🎮 *مباراة دومينو لـ ${playerCount} لاعبين (الهدف ${WINNING_SCORE} نقطة)*\n@${getPhoneNumber(m.sender)} ينتظر لاعبين آخرين.\nاكتب: \`.دومينو انضم\` (المطلوب ${playerCount-1})`,
            mentions: [m.sender]
        });
        return;
    }
    
    if (command === 'دومينو' && text === 'انضم') {
        const game = global.dominoGames[chatId];
        if (!game || game.status !== 'waiting' || game.mode !== 'multi') return m.reply("❌ لا توجد لعبة متعددة مفتوحة.");
        if (game.players.includes(m.sender)) return m.reply("❌ أنت بالفعل في اللعبة.");
        if (game.players.length >= game.playerCount) return m.reply(`❌ اللعبة مكتملة (${game.playerCount} لاعبين).`);
        game.players.push(m.sender);
        game.scores[m.sender] = 0;
        await conn.sendMessage(chatId, {
            text: `✅ @${getPhoneNumber(m.sender)} انضم. (${game.players.length}/${game.playerCount})`,
            mentions: [m.sender]
        });
        if (game.players.length === game.playerCount) {
            game.status = 'playing';
            const tilesPerPlayer = TILES_PER_PLAYER[game.playerCount];
            let shuffled = shuffleArray([...ALL_TILES]);
            for (let i = 0; i < game.players.length; i++) {
                game.hands[game.players[i]] = shuffled.slice(i * tilesPerPlayer, (i+1) * tilesPerPlayer);
            }
            game.boneyard = shuffled.slice(game.players.length * tilesPerPlayer);
            let bestValue = -1;
            let bestIndex = 0;
            for (let i = 0; i < game.players.length; i++) {
                for (let tile of game.hands[game.players[i]]) {
                    if (tile.a === tile.b && tile.a > bestValue) {
                        bestValue = tile.a;
                        bestIndex = i;
                    }
                }
            }
            game.turnIndex = bestIndex;
            for (let player of game.players) {
                const handStr = game.hands[player].map(t => getDominoSymbol(t.a, t.b)).join('  ');
                await conn.sendMessage(player, { text: `🎴 *قطعك في الجولة الأولى (${game.hands[player].length} قطعة):*\n${handStr}` });
            }
            await conn.sendMessage(chatId, {
                text: `🎮 *بدأت المباراة!*\nاللاعبون: ${game.players.map(p => `@${getPhoneNumber(p)}`).join(', ')}\n\n@${getPhoneNumber(game.players[game.turnIndex])} يبدأ الجولة الأولى! سيتم إرسال الأزرار لك في الخاص.`,
                mentions: game.players
            });
            const firstPlayer = game.players[game.turnIndex];
            await sendChoiceButtons(conn, firstPlayer, chatId, game.hands[firstPlayer], game);
            game.turnTimeout = setTimeout(() => {
                if (global.dominoGames[chatId] && global.dominoGames[chatId].status === 'playing') {
                    conn.sendMessage(chatId, { text: `⌛ انتهى وقت @${getPhoneNumber(firstPlayer)}. يتم تمرير الدور.`, mentions: [firstPlayer] });
                    game.turnIndex = (game.turnIndex + 1) % game.players.length;
                    const nextPlayer = game.players[game.turnIndex];
                    sendChoiceButtons(conn, nextPlayer, chatId, game.hands[nextPlayer], game);
                }
            }, 60000);
        }
        return;
    }
    
    m.reply(`🎮 *دومينو (نقاط تراكمية حتى ${WINNING_SCORE})*\n.دومينو - اختيار الوضع\n.دومينو انضم - الانضمام\n.دومينو حذف - حذف المباراة`);
};

// ----------------------------------- معالج الأزرار (مبسط) -----------------------------------
handler.before = async (m, { conn }) => {
    const text = m.text;
    if (!text) return false;
    
    if (text.startsWith('.domino_first|')) {
        const parts = text.split('|');
        if (parts.length < 4) return false;
        const chatId = parts[1];
        const playerJid = parts[2];
        const idx = parseInt(parts[3]);
        const senderPhone = getPhoneNumber(m.sender);
        const targetPhone = getPhoneNumber(playerJid);
        if (senderPhone !== targetPhone) {
            await m.reply("❌ هذا الزر ليس لك!");
            return true;
        }
        const game = global.dominoGames[chatId];
        if (!game || game.status !== 'playing' || game.roundEnded) {
            await m.reply("❌ لا توجد لعبة نشطة.");
            return true;
        }
        const hand = game.hands[m.sender];
        if (idx < 0 || idx >= hand.length) {
            await m.reply("❌ قطعة غير صالحة.");
            return true;
        }
        const tile = hand[idx];
        hand.splice(idx, 1);
        game.board = [tile];
        await conn.sendMessage(chatId, {
            text: `🎲 @${senderPhone} وضع القطعة الأولى: ${getDominoSymbol(tile.a, tile.b)}.\nاللوحة:\n${formatBoard(game.board)}`,
            mentions: [m.sender]
        });
        if (hand.length === 0) {
            await endRound(conn, chatId, game, m.sender);
            return true;
        }
        game.turnIndex = (game.turnIndex + 1) % game.players.length;
        const nextPlayer = game.players[game.turnIndex];
        if (game.turnTimeout) clearTimeout(game.turnTimeout);
        game.turnTimeout = setTimeout(() => {
            if (global.dominoGames[chatId] && global.dominoGames[chatId].status === 'playing') {
                conn.sendMessage(chatId, { text: `⌛ انتهى وقت @${getPhoneNumber(nextPlayer)}. يتم تمرير الدور.`, mentions: [nextPlayer] });
                game.turnIndex = (game.turnIndex + 1) % game.players.length;
                const nextNext = game.players[game.turnIndex];
                sendChoiceButtons(conn, nextNext, chatId, game.hands[nextNext], game);
            }
        }, 60000);
        if (nextPlayer === 'BOT') {
            await botMove(conn, chatId, game);
        } else {
            await sendChoiceButtons(conn, nextPlayer, chatId, game.hands[nextPlayer], game);
        }
        return true;
    }
    if (text.startsWith('.domino_move|')) {
        const parts = text.split('|');
        if (parts.length < 5) return false;
        const chatId = parts[1];
        const playerJid = parts[2];
        const idx = parseInt(parts[3]);
        const side = parts[4];
        const senderPhone = getPhoneNumber(m.sender);
        const targetPhone = getPhoneNumber(playerJid);
        if (senderPhone !== targetPhone) {
            await m.reply("❌ هذا الزر ليس لك!");
            return true;
        }
        const game = global.dominoGames[chatId];
        if (!game || game.status !== 'playing' || game.roundEnded) {
            await m.reply("❌ لا توجد لعبة نشطة.");
            return true;
        }
        const hand = game.hands[m.sender];
        if (idx < 0 || idx >= hand.length) {
            await m.reply("❌ قطعة غير صالحة.");
            return true;
        }
        let tile = hand[idx];
        const board = game.board;
        const leftVal = board[0].a;
        const rightVal = board[board.length-1].b;
        if (side === 'left') {
            if (tile.a !== leftVal && tile.b === leftVal) tile = { a: tile.b, b: tile.a };
            if (tile.a !== leftVal) {
                await m.reply("❌ لا يمكن وضع هذه القطعة على اليسار.");
                return true;
            }
            hand.splice(idx, 1);
            game.board.unshift(tile);
        } else if (side === 'right') {
            if (tile.a !== rightVal && tile.b === rightVal) tile = { a: tile.b, b: tile.a };
            if (tile.a !== rightVal) {
                await m.reply("❌ لا يمكن وضع هذه القطعة على اليمين.");
                return true;
            }
            hand.splice(idx, 1);
            game.board.push(tile);
        } else {
            await m.reply("❌ اتجاه غير صالح.");
            return true;
        }
        await conn.sendMessage(chatId, {
            text: `🎲 @${senderPhone} وضع ${getDominoSymbol(tile.a, tile.b)} على ال${side === 'left' ? 'يسار' : 'يمين'}.\nاللوحة:\n${formatBoard(game.board)}`,
            mentions: [m.sender]
        });
        if (hand.length === 0) {
            await endRound(conn, chatId, game, m.sender);
            return true;
        }
        game.turnIndex = (game.turnIndex + 1) % game.players.length;
        const nextPlayer = game.players[game.turnIndex];
        if (game.turnTimeout) clearTimeout(game.turnTimeout);
        game.turnTimeout = setTimeout(() => {
            if (global.dominoGames[chatId] && global.dominoGames[chatId].status === 'playing') {
                conn.sendMessage(chatId, { text: `⌛ انتهى وقت @${getPhoneNumber(nextPlayer)}. يتم تمرير الدور.`, mentions: [nextPlayer] });
                game.turnIndex = (game.turnIndex + 1) % game.players.length;
                const nextNext = game.players[game.turnIndex];
                sendChoiceButtons(conn, nextNext, chatId, game.hands[nextNext], game);
            }
        }, 60000);
        if (nextPlayer === 'BOT') {
            await botMove(conn, chatId, game);
        } else {
            await sendChoiceButtons(conn, nextPlayer, chatId, game.hands[nextPlayer], game);
        }
        return true;
    }
    
    if (text.startsWith('.domino_draw|')) {
        const parts = text.split('|');
        if (parts.length < 3) return false;
        const chatId = parts[1];
        const playerJid = parts[2];
        const senderPhone = getPhoneNumber(m.sender);
        const targetPhone = getPhoneNumber(playerJid);
        if (senderPhone !== targetPhone) {
            await m.reply("❌ هذا الزر ليس لك!");
            return true;
        }
        const game = global.dominoGames[chatId];
        if (!game || game.status !== 'playing' || game.roundEnded) {
            await m.reply("❌ لا توجد لعبة نشطة.");
            return true;
        }
        if (game.boneyard.length === 0) {
            await m.reply("❌ لا توجد قطع للسحب!");
            return true;
        }
        const drawn = game.boneyard.pop();
        game.hands[m.sender].push(drawn);
        await m.reply(`🃏 سحبت قطعة: ${getDominoSymbol(drawn.a, drawn.b)}`);
        await sendChoiceButtons(conn, m.sender, chatId, game.hands[m.sender], game);
        return true;
    }
    
    return false;
};

handler.category = 'games';
handler.usage = ['دومينو'];
handler.command = ['دومينو'];
handler.owner = true;

export default handler;
const TIMEOUT_JOIN = 300;       // 5 دقائق
const TIMEOUT_CHOICE = 120;     // دقيقتان
const CHOICES = ['حجر', 'ورقة', 'مقص'];
const CHOICE_EMOJI = { 'حجر': '🪨', 'ورقة': '📄', 'مقص': '✂️' };

if (!global.rpsGames) global.rpsGames = {};

function getWinner(choice1, choice2) {
    if (choice1 === choice2) return 'tie';
    if (
        (choice1 === 'حجر' && choice2 === 'مقص') ||
        (choice1 === 'ورقة' && choice2 === 'حجر') ||
        (choice1 === 'مقص' && choice2 === 'ورقة')
    ) {
        return 'player1';
    }
    return 'player2';
}

async function awardWinner(conn, chatId, winnerJid, explanation) {
    if (global.db?.users[winnerJid]) {
        global.db.users[winnerJid].xp = (global.db.users[winnerJid].xp || 0) + 50;
        global.db.users[winnerJid].cookies = (global.db.users[winnerJid].cookies || 0) + 5;
    }
    await conn.sendMessage(chatId, {
        text: `🏆 *الفائز:* @${winnerJid.split('@')[0]}\n🎉 حصل على +50 XP و 🍪 +5 كوكيز.\n📝 ${explanation}`,
        mentions: [winnerJid]
    });
}

async function sendChoiceButtons(conn, targetJid, chatId, contextMessage, callbackIdPrefix) {
    const sections = [{
        title: "🎮 اختر خيارك",
        rows: CHOICES.map(choice => ({
            title: choice,
            description: `${CHOICE_EMOJI[choice]} اختر ${choice}`,
            id: `${callbackIdPrefix} ${chatId}|${choice}`
        }))
    }];
    await conn.sendButtonNormal(targetJid, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: contextMessage,
        buttons: [{
            name: "single_select",
            params: {
                title: "✋ اختر",
                sections: sections
            }
        }],
        mentions: [targetJid]
    }, global.reply_status);
}

// ---------- وضع ضد الروبوت ----------
async function playWithBot(m, conn, chatId, player) {
    const botChoice = CHOICES[Math.floor(Math.random() * CHOICES.length)];
    await sendChoiceButtons(conn, player, chatId, "🤖 *لعبة حجر ورقة مقص (ضد الروبوت)*\nاختر خيارك (لديك دقيقتان):", ".ps_bot_choice");
    
    global.rpsGames[chatId] = {
        mode: 'bot',
        player: player,
        botChoice: botChoice,
        createdAt: Date.now(),
        timeout: setTimeout(() => {
            if (global.rpsGames[chatId]?.mode === 'bot') {
                delete global.rpsGames[chatId];
                conn.sendMessage(chatId, { text: "⌛ انتهى الوقت! لم تختر خلال دقيقتين. ابدأ جولة جديدة بـ `.ps`." });
            }
        }, TIMEOUT_CHOICE * 1000)
    };
}

async function handleBotChoice(m, conn, chatId, player, choice) {
    const game = global.rpsGames[chatId];
    if (!game || game.mode !== 'bot') return false;
    if (game.player !== player) {
        await m.reply("❌ هذه اللعبة ليست لك!");
        return true;
    }
    clearTimeout(game.timeout);
    delete global.rpsGames[chatId];

    const botChoice = game.botChoice;
    const result = getWinner(choice, botChoice);
    let text = `🎮 *نتيجة اللعبة*\n\n👤 خيارك: ${CHOICE_EMOJI[choice]} ${choice}\n🤖 خيار الروبوت: ${CHOICE_EMOJI[botChoice]} ${botChoice}\n\n`;
    if (result === 'tie') {
        text += "🤝 *تعادل!*";
        if (global.db?.users[player]) {
            global.db.users[player].xp = (global.db.users[player].xp || 0) + 10;
            global.db.users[player].cookies = (global.db.users[player].cookies || 0) + 1;
        }
        text += "\n📝 حصلت على +10 XP و 🍪 +1 كوكيز كتعويض.";
    } else if (result === 'player1') {
        text += "🎉 *فزت!*";
        await awardWinner(conn, chatId, player, "فزت على الروبوت!");
    } else {
        text += "💔 *خسرت!*";
    }
    await conn.sendMessage(chatId, { text, mentions: [player] });
    return true;
}

// ---------- وضع لاعب ضد لاعب ----------
async function createPvPGame(m, conn, chatId, player1) {
    if (global.rpsGames[chatId]) {
        if (global.rpsGames[chatId].timeout) clearTimeout(global.rpsGames[chatId].timeout);
        delete global.rpsGames[chatId];
    }
    global.rpsGames[chatId] = {
        mode: 'pvp',
        player1: player1,
        player2: null,
        choice1: null,
        choice2: null,
        step: 'waiting_player2',
        createdAt: Date.now(),
        timeout: setTimeout(() => {
            if (global.rpsGames[chatId]?.mode === 'pvp' && global.rpsGames[chatId].step === 'waiting_player2') {
                delete global.rpsGames[chatId];
                conn.sendMessage(chatId, { text: "⌛ انتهى وقت انتظار الخصم (5 دقائق). ابدأ جولة جديدة بـ `.ps`." });
            }
        }, TIMEOUT_JOIN * 1000)
    };
    await conn.sendMessage(chatId, {
        text: `🎮 *لعبة حجر ورقة مقص (لاعب ضد لاعب)*\n@${player1.split('@')[0]} ينتظر خصماً.\n\nللدخول، اكتب:\n\`.ps2\`\n(الخصم لديه 5 دقائق للانضمام)`,
        mentions: [player1]
    });
}

async function joinPvPGame(m, conn, chatId, player2) {
    const game = global.rpsGames[chatId];
    if (!game || game.mode !== 'pvp') {
        await m.reply("❌ لا توجد لعبة PVP نشطة للانضمام. ابدأ لعبة بـ `.ps لاعب`.");
        return false;
    }
    if (game.player2 !== null) {
        await m.reply("❌ اللعبة ممتلئة بالفعل!");
        return false;
    }
    if (game.player1 === player2) {
        await m.reply("❌ لا يمكنك لعب ضد نفسك!");
        return false;
    }
    game.player2 = player2;
    game.step = 'waiting_player1_choice';
    clearTimeout(game.timeout);
    game.timeout = setTimeout(() => {
        if (global.rpsGames[chatId]?.mode === 'pvp' && global.rpsGames[chatId].step === 'waiting_player1_choice') {
            delete global.rpsGames[chatId];
            conn.sendMessage(chatId, { text: "⌛ انتهى الوقت! لم يختر اللاعب الأول (دقيقتان). ابدأ جولة جديدة." });
        }
    }, TIMEOUT_CHOICE * 1000);

    await conn.sendMessage(chatId, {
        text: `🎮 *بدء اللعبة!*\n@${game.player1.split('@')[0]} (اللاعب 1) و @${game.player2.split('@')[0]} (اللاعب 2).\n\nسيتم إرسال الأزرار للاعب الأول ليختار خياره (في الخاص). لديه دقيقتان.`,
        mentions: [game.player1, game.player2]
    });

    await sendChoiceButtons(conn, game.player1, chatId, "🎮 *دورك يا لاعب 1!* اختر خيارك (لديك دقيقتان):", ".ps_pvp_choice1");
    return true;
}

async function handlePvPChoice1(m, conn, chatId, sender, choice) {
    const game = global.rpsGames[chatId];
    if (!game || game.mode !== 'pvp') return false;
    if (game.step !== 'waiting_player1_choice') return false;
    if (sender !== game.player1) {
        await m.reply("❌ ليس دورك!");
        return true;
    }
    if (game.choice1 !== null) {
        await m.reply("❌ لقد اخترت بالفعل!");
        return true;
    }
    game.choice1 = choice;
    game.step = 'waiting_player2_choice';
    clearTimeout(game.timeout);
    game.timeout = setTimeout(() => {
        if (global.rpsGames[chatId]?.mode === 'pvp' && global.rpsGames[chatId].step === 'waiting_player2_choice') {
            delete global.rpsGames[chatId];
            conn.sendMessage(chatId, { text: "⌛ انتهى الوقت! لم يختر اللاعب الثاني (دقيقتان). ابدأ جولة جديدة." });
        }
    }, TIMEOUT_CHOICE * 1000);

    await m.reply("✅ تم تسجيل اختيارك. انتظر دور الخصم...");
    await conn.sendMessage(chatId, { text: `🎮 اللاعب الأول (@${game.player1.split('@')[0]}) قام باختياره ✅`, mentions: [game.player1] });
    await sendChoiceButtons(conn, game.player2, chatId, "🎮 *دورك يا لاعب 2!* اختر خيارك (لديك دقيقتان):", ".ps_pvp_choice2");
    return true;
}

async function handlePvPChoice2(m, conn, chatId, sender, choice) {
    const game = global.rpsGames[chatId];
    if (!game || game.mode !== 'pvp') return false;
    if (game.step !== 'waiting_player2_choice') return false;
    if (sender !== game.player2) {
        await m.reply("❌ ليس دورك!");
        return true;
    }
    if (game.choice2 !== null) {
        await m.reply("❌ لقد اخترت بالفعل!");
        return true;
    }
    game.choice2 = choice;
    clearTimeout(game.timeout);
    
    await m.reply("✅ تم تسجيل اختيارك. سيتم إعلان النتيجة قريباً.");
    await conn.sendMessage(chatId, { text: `🎮 اللاعب الثاني (@${game.player2.split('@')[0]}) قام باختياره ✅`, mentions: [game.player2] });
    
    const result = getWinner(game.choice1, game.choice2);
    let text = `🎮 *نتيجة لعبة حجر ورقة مقص*\n\n@${game.player1.split('@')[0]} اختار: ${CHOICE_EMOJI[game.choice1]} ${game.choice1}\n@${game.player2.split('@')[0]} اختار: ${CHOICE_EMOJI[game.choice2]} ${game.choice2}\n\n`;
    if (result === 'tie') {
        text += "🤝 *تعادل!*";
        if (global.db?.users[game.player1]) {
            global.db.users[game.player1].xp = (global.db.users[game.player1].xp || 0) + 10;
            global.db.users[game.player1].cookies = (global.db.users[game.player1].cookies || 0) + 1;
        }
        if (global.db?.users[game.player2]) {
            global.db.users[game.player2].xp = (global.db.users[game.player2].xp || 0) + 10;
            global.db.users[game.player2].cookies = (global.db.users[game.player2].cookies || 0) + 1;
        }
        text += "\n📝 كل لاعب حصل على +10 XP و 🍪 +1 كوكيز.";
    } else if (result === 'player1') {
        text += `🎉 *الفائز: @${game.player1.split('@')[0]}*`;
        await awardWinner(conn, chatId, game.player1, "فاز على الخصم!");
    } else {
        text += `🎉 *الفائز: @${game.player2.split('@')[0]}*`;
        await awardWinner(conn, chatId, game.player2, "فاز على الخصم!");
    }
    await conn.sendMessage(chatId, { text, mentions: [game.player1, game.player2] });
    delete global.rpsGames[chatId];
    return true;
}

// ---------- الأمر الرئيسي ----------
const handler = async (m, { conn, command, text }) => {
    const chatId = m.chat;
    const args = text.trim().toLowerCase();

    // أمر الانضمام الجديد: .ps2
    if (command === 'ps2') {
        const game = global.rpsGames[chatId];
        if (game && game.mode === 'pvp' && game.player2 === null) {
            await joinPvPGame(m, conn, chatId, m.sender);
        } else {
            await m.reply("❌ لا توجد لعبة PVP نشطة للانضمام. ابدأ لعبة بـ `.ps لاعب`.");
        }
        return;
    }

    // قبول أمر .ps فقط للباقي
    if (command !== 'ps') return;

    if (global.rpsGames[chatId]) {
        return m.reply("❌ توجد لعبة نشطة حالياً! انتظر حتى تنتهي.");
    }

    if (!args) {
        const sections = [{
            title: "🎮 اختر وضع اللعب",
            rows: [
                { title: "ضد الروبوت", description: "العب ضد الذكاء الاصطناعي", id: ".ps روبوت" },
                { title: "لاعب ضد لاعب", description: "تحدى صديقاً", id: ".ps لاعب" }
            ]
        }];
        await conn.sendButtonNormal(chatId, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: "🪨📄✂️ *لعبة حجر ورقة مقص*\nاختر الوضع المناسب:",
            buttons: [{
                name: "single_select",
                params: {
                    title: "⚙️ اختر الوضع",
                    sections: sections
                }
            }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }

    if (args === 'روبوت' || args === 'bot') {
        await playWithBot(m, conn, chatId, m.sender);
    } else if (args === 'لاعب' || args === 'pvp') {
        await createPvPGame(m, conn, chatId, m.sender);
    } else {
        m.reply(`🎮 *لعبة حجر ورقة مقص*\n\nالاستخدام:\n- \`.ps\` لعرض قائمة الأوضاع\n- \`.ps روبوت\` للعب ضد البوت\n- \`.ps لاعب\` لبدء لعبة ضد لاعب آخر\n- \`.ps2\` للانضمام كلاعب ثان`);
    }
};

// معالج الأزرار
handler.before = async (m, { conn }) => {
    if (!m.text) return false;
    const text = m.text.trim();
    if (text.startsWith('.ps_bot_choice')) {
        const parts = text.split(' ');
        if (parts.length < 2) return false;
        const payload = parts[1];
        const [chatId, choice] = payload.split('|');
        if (!chatId || !choice) return false;
        await handleBotChoice(m, conn, chatId, m.sender, choice);
        return true;
    }
    if (text.startsWith('.ps_pvp_choice1')) {
        const parts = text.split(' ');
        if (parts.length < 2) return false;
        const payload = parts[1];
        const [chatId, choice] = payload.split('|');
        if (!chatId || !choice) return false;
        await handlePvPChoice1(m, conn, chatId, m.sender, choice);
        return true;
    }
    if (text.startsWith('.ps_pvp_choice2')) {
        const parts = text.split(' ');
        if (parts.length < 2) return false;
        const payload = parts[1];
        const [chatId, choice] = payload.split('|');
        if (!chatId || !choice) return false;
        await handlePvPChoice2(m, conn, chatId, m.sender, choice);
        return true;
    }
    return false;
};

handler.usage = ["ps", "ps2"];
handler.category = "games";
handler.command = ["ps", "ps2"];

export default handler;
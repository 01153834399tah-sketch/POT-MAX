// menu2.js - معدل لاستدعاء الصورة عشوائياً في كل مرة
const CATEGORIES = [
    [1, 'التـحـمـيـل', 'download', '📂'],
    [2, 'الـمـجـمـوعـات', 'group', '🐞'],
    [3, 'الـمـلـصـقـات', 'sticker', '🌄'],
    [4, 'الـمـطـوريـن', 'owner', '🇩🇪'],
    [5, 'امـثـلـه', 'example', '✳️'],
    [6, 'الـادوات', 'tools', '🚀'],
    [7, 'الـبـحـث', 'search', '🌐'],
    [8, 'الادمــن', 'admin', '👨🏻‍⚖️'],
    [9, 'الالــعـاب', 'games', '🎮'],
    [10, 'الچيف', 'gif', '✴️'],
    [11, 'الـبــنـك', 'bank', '💰'],
    [12, 'الـذكـاء الاصـطـنـاعـي', 'ai', '🤖'],
    [13, 'الـبـوتـات الـفـرعـي', 'sub', '♥️'],
    [14, 'مـعـلومـات الـبـوت', 'info', '🗃️'],
    [15, 'الـالــقــاب', 'nicknames', '🫯'],
    [16, 'الـلـوجـوهــات', 'logos', '🎡'],
    [17, 'تـغـيـر الاصـوات', 'voices', '📢'],
    [18, 'الدين', 'religion', '🕌'],
    [19, 'أخــرى', 'other', '🌹']
];

const getCat = n => CATEGORIES.find(c => c[0] === n);

// ✅ دالة لاختيار صورة عشوائية في كل مرة
const getRandomImage = (bot) => {
    const images = bot?.config?.info?.images || [];
    if (!images.length) return 'https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png';
    return images[Math.floor(Math.random() * images.length)];
};

async function handler(m, { conn, bot, command, args }) {
    const selected = parseInt(args[0]);
    const now = new Date();
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    const uptimeFormatted = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    const date = now.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
    const time = now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    if (!selected && !args[0]) {
        const sections = [{
            title: "🌳 ~ الاقـسـام ~ 🪾",
            rows: CATEGORIES.map(c => ({
                title: `${c[0]} ~ ${c[1]} ${c[3]}`,
                description: `اضغط لعرض أوامر قسم ${c[1]}`,
                id: `.${command} ${c[0]}`
            }))
        }];

        const menuText = `
رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا الَّذِينَ سَبَقُونَا بِالْإِيمَانِ
وَلَا تَجْعَلْ فِي قُلُوبِنَا غِلًّا لِّلَّذِينَ آمَنُوا رَبَّنَا إِنَّكَ رَءُوفٌ رَّحِيمٌ
╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ ⌯🍂︙ اهـلا → *[ @${m.sender.split("@")[0]} ]*
┃ ⌯🚀︙ الـتشـغـيـل → ${uptimeFormatted}
┃ ⌯👾︙ الـتـاريـخ → ${date} - ${time}
╰─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╯
> *_اختار قسم من القائمة عشان يبعتلك اوامر القسم_*`;
        
        // ✅ اختيار صورة عشوائية جديدة في كل مرة
        const randomImg = getRandomImage(bot);
        
        await conn.sendButtonNormal(m.chat, {
            media: { url: randomImg },
            mediaType: 'image',
            caption: menuText,
            buttons: [{
                name: "single_select",
                params: {
                    title: "🍂✨",
                    sections: sections
                }
            }],
            mentions: [m.sender],
            newsletter: {
                name: 'Pomni AI ~ Channel 🕷️',
                jid: '120363427163691139@newsletter'
            }
        }, global.reply_status);
        return;
    }

    const cat = getCat(selected);
    if (!cat) {
        await conn.sendMessage(m.chat, { text: '*❌ اختار رقم صحيح من 1 لـ 19*' });
        return;
    }

    const cmds = await bot.getAllCommands();
    const categoryCmds = cmds.filter(c => c.category === cat[2]);
    if (!categoryCmds.length) {
        await conn.sendMessage(m.chat, { text: '*❌ القسم فاضي*' });
        return;
    }

    const cmdsList = categoryCmds.map(c => {
        let cmdText = '';
        if (c.usage && Array.isArray(c.usage) && c.usage.length) {
            cmdText = `${cat[3]} /${c.usage.join(`\n${cat[3]} /`)}`;
        } else if (c.usage && typeof c.usage === 'string') {
            cmdText = `${cat[3]} /${c.usage}`;
        } else if (c.command && Array.isArray(c.command)) {
            cmdText = `${cat[3]} /${c.command.join(`\n${cat[3]} /`)}`;
        } else {
            cmdText = `${cat[3]} /${c.command || 'لا يوجد أمر'}`;
        }
        return cmdText;
    }).join('\n');

    const commandsText = `
╭─┈─┈─┈─⟞${cat[3]}⟝─┈─┈─┈─╮
┃ *⌯︙ قـسـم ${cat[1]} ${cat[3]}*
╰─┈─┈─┈─⟞${cat[3]}⟝─┈─┈─┈─╯

${cmdsList}

╭─┈─┈─┈─⟞${cat[3]}⟝─┈─┈─┈─╮
┃ *⌯︙Pomni AI ~ ${bot?.config?.info?.nameBot || 'POMNI-AI'}*
╰─┈─┈─┈─⟞${cat[3]}⟝─┈─┈─┈─╯
> *رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا*`;

    // ✅ اختيار صورة عشوائية جديدة في كل مرة أيضاً
    const randomImg2 = getRandomImage(bot);

    await conn.sendButtonNormal(m.chat, {
        media: { url: randomImg2 },
        mediaType: 'image',
        caption: commandsText.trim(),
        buttons: [
            { name: "quick_reply", params: { display_text: "🔙 رجوع للقائمة", id: ".المهام" } },
            { name: "cta_url", params: { display_text: "📢 قناة البوت", url: "https://whatsapp.com/channel/0029VbDFMWi60eBbXu18xG2E" } }
        ],
        mentions: [m.sender],
        newsletter: {
            name: 'Pomni AI ~ Channel 🕷️',
            jid: '120363427163691139@newsletter'
        }
    }, global.reply_status);
}

handler.command = ['المهام', 'اوامر', 'الاوامر', 'menu'];
export default handler;
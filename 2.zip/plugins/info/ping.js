const handler = async (m, { conn, bot }) => {
  // ✅ اختيار صورة عشوائية من مصفوفة الصور
  const images = bot?.config?.info?.images || [];
  const randomImg = images.length ? images[Math.floor(Math.random() * images.length)] : 'https://i.pinimg.com/736x/73/56/32/735632c6fa8e665c249abbc8a340b77d.jpg';

  const start = process.hrtime.bigint();
  await conn.sendMessage(m.chat, { text: "🏓 msg test" });
  const end = process.hrtime.bigint();
  const ping = Number(end - start) / 1e6;
  
  await conn.sendMessage(m.chat, {
    image: { url: randomImg },
    caption: `⚡ سرعة البوت: ${ping.toFixed(2)}ms`
  });
};

handler.command = ["بنج", "ping"];
handler.category = "info";
handler.usage = ["بنج"];
export default handler;
import os from 'os';

const handler = async (m, { conn, bot }) => {
  // ✅ اختيار صورة عشوائية من مصفوفة الصور
  const images = bot?.config?.info?.images || [];
  const randomImg = images.length ? images[Math.floor(Math.random() * images.length)] : 'https://i.pinimg.com/736x/73/56/32/735632c6fa8e665c249abbc8a340b77d.jpg';

  const txt = `
  ⊱⋅ ────────────────── ⋅⊰
🪾╎ الـمسـتـخـدم: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)}MB
🌳╎ الـمتـبــقـي: ${(os.freemem() / 1024 / 1024).toFixed(1)}MB
  ⊱⋅ ────────────────── ⋅⊰
`;

  await conn.sendMessage(m.chat, {
    image: { url: randomImg },
    caption: txt,
    mentions: [m.sender]
  });
};

handler.command = ["الرام", "ram"];
handler.category = "info";
handler.usage = ["الرام", "ram"];
export default handler;
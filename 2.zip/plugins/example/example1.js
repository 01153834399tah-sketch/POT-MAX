/* 
by: VA ~ VENOM
*/

const example = async (m, { conn }) => {

await conn.sendButtonNormal(m.chat, {
  media: { url: 'https://example.com/promo.jpg' },
  mediaType: 'image',
  caption: '*🔥 Special Offer*\n\n50% OFF\nLimited time',
  buttons: [],
  mentions: ['201234567890@s.whatsapp.net', '201111111111@s.whatsapp.net'],
  newsletter: {
    name: 'Pomni AI ~ Channel 🕷️',
    jid: '120363427163691139@newsletter'
  }
}, m)

};

example.usage = ["تست1"]


/* ↓ قسم الأمر ↓ */
example.category = "example"


/* ↓ استخدم الأوامر ↓ */
example.command = ["تست1"] 


/* ↓ بتعمل ايقاف ل الأمر ↓ */
example.disabled = false

/* ↓ استخدام الأمر بعد ثانيه من الاستخدام لمنع الاسبام ↓ */
example.cooldown = 1000;

/* ↓ استخدام الأمر ب بدايه أو لا ↓ */
example.usePrefix = false;

export default example;
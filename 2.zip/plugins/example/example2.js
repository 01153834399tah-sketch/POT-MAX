const example = async (m, { conn }) => {

await conn.sendButtonNormal(m.chat, {
  media: { url: "https://i.pinimg.com/736x/f3/5d/2e/f35d2ed376e03aa254e7f34b4b94992e.jpg" },
  mediaType: 'image',
  caption: "Hello! This is the message text",
  buttons: [
    { name: "quick_reply", params: { display_text: "👍 Quick Reply", id: "quick1" } },
    { name: "quick_reply", params: { display_text: "👎 Another Reply", id: "quick2" } },
    { name: "cta_url", params: { display_text: "🔗 Google Link", url: "https://google.com" } },
    { name: "cta_call", params: { display_text: "📞 Call Support", phone_number: "201234567890" } },
    { name: "cta_copy", params: { display_text: "📋 Copy Code", copy_code: "ABC123XYZ" } },
    { 
      name: "single_select", 
      params: { 
        title: "📋 Choose Option",
        sections: [{
          title: "Menu",
          rows: [
            { title: "Option 1", description: "Description 1", id: "opt1" },
            { title: "Option 2", description: "Description 2", id: "opt2" }
          ]
        }]
      }
    },
    { name: "call_permission_request", params: { display_text: "📞 Request Call", phone_number: "201234567890", duration: 60 } }
  ],
  mentions: [m.sender],
  newsletter: {
    name: 'Pomni AI ~ Channel 🕷️',
    jid: '120363427163691139@newsletter'
  },
  interactiveConfig: {
    buttons_limits: 10,
    list_title: "Available Options",
    button_title: "Click Here",
    canonical_url: "https://example.com"
  }
}, m);

};
example.usage = ["تست2"]
example.category = "example";
example.command = ["تست2"]
export default example;
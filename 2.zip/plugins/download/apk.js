// plugins/download/apk1.js
// تحميل تطبيقات APK (باستخدام Aptoide API مباشرة)

import fetch from 'node-fetch';

const channelRD = 'https://chat.whatsapp.com/HsAfjrdXiCrHqfCC8GRRqE';
const sukiIcon = 'https://files.catbox.moe/f92wmw.jpg';

let handler = async (m, { conn, usedPrefix, command, text }) => {
    try {
        const name = conn.getName ? conn.getName(m.sender) || 'صديقي' : 'صديقي';

        // ✅ استخدام بادئة ثابتة لتجنب undefined
        const prefix = usedPrefix || '.';

        if (!text) {
            return conn.sendMessage(m.chat, {
                text: `📱 مرحبا ${name}\n\n🔍 أرسل اسم التطبيق الذي تريد تحميله.\n\n📌 الاستخدام:\n${prefix}${command} <اسم التطبيق>\n\n📝 مثال:\n${prefix}${command} WhatsApp`,
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        title: 'تحميل تطبيقات APK',
                        body: `مرحبا ${name}`,
                        thumbnailUrl: sukiIcon,
                        sourceUrl: channelRD,
                        mediaType: 1
                    }
                }
            }, { quoted: m });
        }

        await m.react('🔍');

        // البحث في Aptoide مباشرة
        const searchRes = await fetch(`http://ws75.aptoide.com/api/7/apps/search?query=${encodeURIComponent(text)}&limit=1`);
        const searchData = await searchRes.json();
        const app = searchData.datalist?.list?.[0];

        if (!app) {
            return conn.sendMessage(m.chat, {
                text: `❌ لم يتم العثور على تطبيق باسم: ${text}`,
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        title: 'تحميل تطبيقات APK',
                        body: `مرحبا ${name}`,
                        thumbnailUrl: sukiIcon,
                        sourceUrl: channelRD,
                        mediaType: 1
                    }
                }
            }, { quoted: m });
        }

        const appName = app.name;
        const appPackage = app.package;
        const appIcon = app.icon;
        const downloadUrl = app.file?.path;

        if (!downloadUrl) {
            return conn.sendMessage(m.chat, {
                text: `⚠️ لا يمكن الحصول على رابط التحميل لـ ${appName}`,
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        title: 'تحميل تطبيقات APK',
                        body: `مرحبا ${name}`,
                        thumbnailUrl: sukiIcon,
                        sourceUrl: channelRD,
                        mediaType: 1
                    }
                }
            }, { quoted: m });
        }

        const caption = `📦 ${appName}\n📋 الحزمة: ${appPackage}\n⏳ جاري التحميل...`;

        if (appIcon) {
            await conn.sendMessage(m.chat, { image: { url: appIcon }, caption });
        } else {
            await conn.sendMessage(m.chat, { text: caption });
        }

        await conn.sendMessage(m.chat, {
            document: { url: downloadUrl },
            mimetype: 'application/vnd.android.package-archive',
            fileName: `${appName}.apk`
        }, { quoted: m });

        await m.react('✅');

    } catch (error) {
        console.error('❌ خطأ في تحميل APK:', error);
        conn.sendMessage(m.chat, {
            text: `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`,
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    title: 'تحميل تطبيقات APK',
                    body: 'حدث خطأ',
                    thumbnailUrl: sukiIcon,
                    sourceUrl: channelRD,
                    mediaType: 1
                }
            }
        }, { quoted: m });
        await m.react('❌');
    }
};

handler.command = ['apk1', 'apk2'];
handler.category = 'downloads';
handler.usage = ['apk1'];

export default handler;
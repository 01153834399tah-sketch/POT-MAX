// كود تحميل وبحث يوتيوب - مع فحص الحجم قبل التحميل
// https://whatsapp.com/channel/0029Vb7Nq294Y9le1aAcTE0D
import axios from 'axios'
import fs from 'fs/promises'
import { createWriteStream } from 'fs'
import os from 'os'
import path from 'path'
import crypto from 'crypto'
import { spawn } from 'child_process'
import { pipeline } from 'stream/promises'

const API_BASE = 'https://engez.a7a.online/api/v1'
const YT_SEARCH = `${API_BASE}/search/youtube`
const YT_DOWNLOAD_V2 = `${API_BASE}/download/youtubev2`
const YT_DOWNLOAD_NEW = `${API_BASE}/download/ytdl`
const YT_DOWNLOAD_OLD = `${API_BASE}/download/youtube`

const SEP = '|'
const DOWNLOAD_TIMEOUT_MS = 120 * 1000

// ========== حد الحجم الأقصى (200 ميجابايت) ==========
const MAX_FILE_SIZE_BYTES = 200 * 1024 * 1024; // 200 MB

const VIDEO_QUALITIES = ['144', '240', '360', '480', '720', '1080', '1440', '2160']
const AUDIO_QUALITIES = ['128', '320']

function normalizeDownloadUrl(value) {
    if (typeof value !== 'string') return null
    const trimmed = value.trim()
    if (!trimmed) return null
    return /^https?:\/\//i.test(trimmed) ? trimmed : null
}

function normalizePayload(payload) {
    return {
        title: payload?.title || null,
        thumbnail: payload?.thumbnail || null,
        download_url: normalizeDownloadUrl(payload?.download_url || payload?.downloadUrl),
        type: payload?.type === 'audio' || payload?.type === 'mp3' ? 'audio' : 'mp4',
        requested_quality: payload?.requested_quality || payload?.quality || null,
        file_size_bytes: payload?.file_size_bytes || payload?.fileSizeBytes || null,
        source_used: payload?.source_used || payload?.source || 'unknown',
        is_fallback: Boolean(payload?.is_fallback)
    }
}

// ============ بحث ============

async function searchYouTube(query) {
    try {
        const params = new URLSearchParams({ q: query })
        const response = await axios.get(`${YT_SEARCH}?${params.toString()}`, {
            timeout: 30000
        })

        if (!response.data?.success) {
            throw new Error(response.data?.error || 'فشل البحث')
        }

        return response.data.results || []
    } catch (error) {
        throw new Error(error?.response?.data?.error || error.message || 'فشل الاتصال')
    }
}

// ============ المصدر الأول (V2) - تحميل سريع ============

async function fetchFromV2(url, type) {
    const params = new URLSearchParams({ url, type })

    const { data } = await axios.get(`${YT_DOWNLOAD_V2}?${params.toString()}`, {
        timeout: DOWNLOAD_TIMEOUT_MS
    })

    if (!data?.success || !data.response) {
        throw new Error(data?.error || 'تعذر التحميل السريع')
    }

    const r = data.response
    const payload = normalizePayload({
        title: r.title,
        thumbnail: r.thumbnail,
        download_url: r.download_url || r.downloadUrl,
        type: r.type,
        requested_quality: r.requested_quality || r.quality,
        file_size_bytes: r.file_size_bytes || r.fileSizeBytes,
        source_used: r.source || 'youtubev2'
    })

    if (!payload.download_url) {
        throw new Error('API لم ترجع رابط تحميل صالح')
    }

    return payload
}

// ============ المصدر الاحتياطي (ytdl -> youtube) ============

function buildNewApiUrl(url, type, quality) {
    const params = new URLSearchParams({ url })
    if (type) params.set('type', type)
    if (quality) params.set('quality', quality)
    return `${YT_DOWNLOAD_NEW}?${params.toString()}`
}

function buildOldApiUrl(url, type, quality) {
    const params = new URLSearchParams({ url })
    if (type) params.set('type', type)
    if (quality) params.set('quality', quality)
    return `${YT_DOWNLOAD_OLD}?${params.toString()}`
}

async function fetchFromNewApi(url, type, quality) {
    const { data } = await axios.get(buildNewApiUrl(url, type, quality), {
        timeout: DOWNLOAD_TIMEOUT_MS
    })

    if (!data?.success || !data.response) {
        throw new Error(data?.error || 'تعذر تحميل هذا الاختيار من المصدر الرئيسي')
    }

    const r = data.response
    const payload = normalizePayload({
        title: r.title,
        thumbnail: r.thumbnail,
        download_url: r.download_url || r.downloadUrl,
        type: r.type,
        requested_quality: r.requested_quality || r.quality || quality,
        file_size_bytes: r.file_size_bytes || r.fileSizeBytes,
        source_used: r.source || 'ytdl'
    })

    if (!payload.download_url) {
        throw new Error('المصدر الرئيسي لم يرجع رابط تحميل صالح')
    }

    return payload
}

async function fetchFromOldApi(url, type, quality) {
    const { data } = await axios.get(buildOldApiUrl(url, type, quality), {
        timeout: DOWNLOAD_TIMEOUT_MS
    })

    if (!data?.success) {
        throw new Error(data?.error || 'تعذر تحميل هذا الاختيار من المصدر الاحتياطي')
    }

    const d = data.data || data.response || {}
    const payload = normalizePayload({
        title: d.title,
        thumbnail: d.thumbnail,
        download_url: d.download_url || d.downloadUrl,
        type: d.type,
        requested_quality: d.requested_quality || d.quality || quality,
        file_size_bytes: d.file_size_bytes || d.fileSizeBytes,
        source_used: d.source || 'youtube',
        is_fallback: true
    })

    if (!payload.download_url) {
        throw new Error('المصدر الاحتياطي لم يرجع رابط تحميل صالح')
    }

    return payload
}

async function fetchFromFallbackChain(url, type, quality) {
    try {
        return await fetchFromNewApi(url, type, quality)
    } catch (e) {
        console.error('ytdl فشل، بجرب youtube:', e?.message || e)
        return await fetchFromOldApi(url, type, quality)
    }
}

// ============ فحص الحجم قبل التحميل ============

async function getFileSizeFromUrl(fileUrl) {
    try {
        const response = await axios.head(fileUrl, {
            timeout: 10000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36'
            }
        })
        const contentLength = response.headers['content-length']
        if (contentLength) {
            return parseInt(contentLength, 10)
        }
        return null
    } catch (error) {
        console.warn('فشل جلب حجم الملف عبر HEAD، سيتم التحميل ثم الفحص:', error.message)
        return null
    }
}

// ============ تجهيز وإرسال الميديا (مع فحص مسبق) ============

async function downloadToFile(fileUrl, filePath) {
    const safeUrl = normalizeDownloadUrl(fileUrl)
    if (!safeUrl) {
        throw new Error('ERR_INVALID_URL')
    }

    const response = await axios.get(safeUrl, {
        responseType: 'stream',
        timeout: DOWNLOAD_TIMEOUT_MS,
        maxRedirects: 5,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            Accept: '*/*',
            'Accept-Language': 'en-US,en;q=0.9'
        }
    })

    await pipeline(response.data, createWriteStream(filePath))
}

function runFfmpeg(args) {
    return new Promise((resolve, reject) => {
        const ff = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] })
        let err = ''

        ff.stderr.on('data', (chunk) => {
            err += chunk.toString()
        })

        ff.on('error', reject)

        ff.on('close', (code) => {
            if (code === 0) return resolve()
            reject(new Error(`ffmpeg exited with code ${code}\n${err}`))
        })
    })
}

async function repairVideoWithFfmpeg(inputPath, outputPath) {
    try {
        await runFfmpeg([
            '-y', '-i', inputPath,
            '-fflags', '+genpts',
            '-movflags', '+faststart',
            '-map', '0:v:0?',
            '-map', '0:a:0?',
            '-c:v', 'libx264',
            '-preset', 'veryfast',
            '-crf', '23',
            '-c:a', 'aac',
            '-b:a', '128k',
            '-pix_fmt', 'yuv420p',
            outputPath
        ])
        return outputPath
    } catch (e) {
        console.error('repairVideoWithFfmpeg re-encode فشل:', e?.message || e)
        await runFfmpeg([
            '-y', '-i', inputPath,
            '-c', 'copy',
            '-movflags', '+faststart',
            outputPath
        ])
        return outputPath
    }
}

async function convertAudioWithFfmpeg(inputPath, outputPath) {
    try {
        await runFfmpeg([
            '-y', '-i', inputPath,
            '-vn',
            '-c:a', 'libmp3lame',
            '-b:a', '192k',
            outputPath
        ])
        return outputPath
    } catch (e) {
        console.error('convertAudioWithFfmpeg فشل:', e?.message || e)
        await runFfmpeg([
            '-y', '-i', inputPath,
            '-vn',
            '-c:a', 'aac',
            '-b:a', '128k',
            outputPath
        ])
        return outputPath
    }
}

// دالة تحضير الملف مع الفحص المسبق
async function prepareMediaFile(payload) {
    const safePayload = normalizePayload(payload)
    if (!safePayload.download_url) {
        throw new Error('API لم ترجع رابط تحميل صالح')
    }

    // ===== فحص الحجم قبل التحميل =====
    const fileSize = await getFileSizeFromUrl(safePayload.download_url)
    if (fileSize !== null && fileSize > MAX_FILE_SIZE_BYTES) {
        const sizeMB = (fileSize / (1024 * 1024)).toFixed(2)
        throw new Error(`حجم الملف كبير جداً (${sizeMB} ميجابايت). الحد الأقصى 200 ميجابايت. يرجى اختيار جودة أقل.`)
    }

    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ytdl-'))
    const id = crypto.randomBytes(6).toString('hex')

    const srcPath = path.join(tmpDir, `source-${id}.bin`)
    const videoPath = path.join(tmpDir, `video-${id}.mp4`)
    const audioPath = path.join(tmpDir, `audio-${id}.mp3`)

    // تحميل الملف
    await downloadToFile(safePayload.download_url, srcPath)

    // فحص إضافي بعد التحميل (احتياطي)
    const stats = await fs.stat(srcPath)
    if (stats.size > MAX_FILE_SIZE_BYTES) {
        await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {})
        throw new Error(`حجم الملف كبير جداً (${(stats.size / (1024 * 1024)).toFixed(2)} ميجابايت). الحد الأقصى 200 ميجابايت.`)
    }

    const isVideo = safePayload.type === 'mp4'

    if (isVideo) {
        try {
            await repairVideoWithFfmpeg(srcPath, videoPath)
            const videoStats = await fs.stat(videoPath)
            if (videoStats.size > MAX_FILE_SIZE_BYTES) {
                throw new Error(`حجم الفيديو بعد المعالجة كبير جداً (${(videoStats.size / (1024 * 1024)).toFixed(2)} ميجابايت).`)
            }
            return { filePath: videoPath, tmpDir, mimetype: 'video/mp4' }
        } catch (e) {
            console.error('video ffmpeg فشل، هبعت الملف الأصلي:', e?.message || e)
            throw e
        }
    }

    // معالجة الصوت
    try {
        await convertAudioWithFfmpeg(srcPath, audioPath)
        const audioStats = await fs.stat(audioPath)
        if (audioStats.size > MAX_FILE_SIZE_BYTES) {
            throw new Error(`حجم الصوت بعد المعالجة كبير جداً (${(audioStats.size / (1024 * 1024)).toFixed(2)} ميجابايت).`)
        }
        return { filePath: audioPath, tmpDir, mimetype: 'audio/mpeg' }
    } catch (e) {
        console.error('audio ffmpeg فشل، هبعت الملف الأصلي:', e?.message || e)
        throw e
    }
}

async function sendDownloadedMedia(conn, chat, payload, quoted) {
    const safePayload = normalizePayload(payload)
    const isVideo = safePayload.type === 'mp4'
    const fallbackNote = safePayload.is_fallback ? '\nملحوظة: تم استخدام مصدر بديل' : ''
    const title = safePayload.title || 'بدون عنوان'

    let prepared
    try {
        prepared = await prepareMediaFile(safePayload)
        const buffer = await fs.readFile(prepared.filePath)

        if (isVideo) {
            await conn.sendMessage(chat, {
                video: buffer,
                mimetype: 'video/mp4',
                caption: `تم التحميل بنجاح\nالعنوان: ${title}\nالجودة: ${safePayload.requested_quality || 'auto'}\nالمصدر: ${safePayload.source_used || 'unknown'}${fallbackNote}`
            }, { quoted })
        } else {
            await conn.sendMessage(chat, {
                audio: buffer,
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted })

            await conn.sendMessage(chat, {
                text: `تم التحميل بنجاح\nالعنوان: ${title}\nالجودة: ${safePayload.requested_quality || 'auto'}\nالمصدر: ${safePayload.source_used || 'unknown'}${fallbackNote}`
            }, { quoted })
        }
    } catch (e) {
        console.error('sendDownloadedMedia error:', e)
        if (e.message && e.message.includes('حجم الملف كبير جداً')) {
            await conn.sendMessage(chat, {
                text: `❌ ${e.message}\n\nيرجى اختيار جودة أقل أو استخدام رابط آخر.`
            }, { quoted })
        } else {
            const status = e?.response?.status
            const statusText = e?.response?.statusText
            const reason = status
                ? `الخادم رفض الطلب (${status}${statusText ? ' - ' + statusText : ''})`
                : (e?.code || e?.message || 'سبب غير معروف')

            await conn.sendMessage(chat, {
                text: `فشل تحميل الملف.\n\nالسبب: ${reason}\n\nحاول تختار جودة تانية أو ابعت الرابط من جديد.`
            }, { quoted })
        }
    } finally {
        if (prepared?.tmpDir) {
            await fs.rm(prepared.tmpDir, { recursive: true, force: true }).catch(() => {})
        }
    }
}

// ============ الأزرار: صوت سريع / فيديو سريع / جودات احتياطية ============

async function sendQuickChoiceButtons(conn, chat, quoted, usedPrefix, command, videoId, title) {
    const titleLine = title ? `\nالعنوان: ${title}` : ''
    const caption = `اختر طريقة التحميل:${titleLine}`

    const buttons = [
        {
            name: "quick_reply",
            params: {
                display_text: "🎵 صوت سريع",
                id: `${usedPrefix}${command} ${videoId}${SEP}quick${SEP}audio`
            }
        },
        {
            name: "quick_reply",
            params: {
                display_text: "🎬 فيديو سريع",
                id: `${usedPrefix}${command} ${videoId}${SEP}quick${SEP}video`
            }
        },
        {
            name: "quick_reply",
            params: {
                display_text: "⚙️ جودات احتياطية",
                id: `${usedPrefix}${command} ${videoId}${SEP}fallback`
            }
        }
    ]

    await conn.sendButtonNormal(chat, {
        caption: caption,
        buttons: buttons,
        mentions: [quoted?.sender ? quoted.sender.split('@')[0] + '@s.whatsapp.net' : undefined].filter(Boolean),
        footer: 'صوت/فيديو سريع بيجيب أسرع جودة متاحة، وجودات احتياطية بتديك تحكم كامل'
    }, quoted)
}

// ============ قايمة الجودات الطويلة ============

function buildQualityRows(usedPrefix, command, videoId) {
    const videoRows = VIDEO_QUALITIES.map((q) => ({
        title: `${q}p`,
        description: `تحميل فيديو بجودة ${q}p`,
        id: `${usedPrefix}${command} ${videoId}${SEP}video${SEP}${q}`
    }))

    const audioRows = AUDIO_QUALITIES.map((q) => ({
        title: `${q}kbps`,
        description: `تحميل صوت بجودة ${q}kbps`,
        id: `${usedPrefix}${command} ${videoId}${SEP}audio${SEP}${q}`
    }))

    return { videoRows, audioRows }
}

async function sendQualityList(conn, chat, quoted, usedPrefix, command, videoId, title) {
    const { videoRows, audioRows } = buildQualityRows(usedPrefix, command, videoId)
    const titleLine = title ? `\nالعنوان: ${title}` : ''
    const caption = `اختر الجودة (مصدر احتياطي):${titleLine}`

    const sections = [
        {
            title: '🎬 جودات الفيديو',
            rows: videoRows
        },
        {
            title: '🎵 جودات الصوت',
            rows: audioRows
        }
    ]

    const buttons = [
        {
            name: "single_select",
            params: {
                title: "⚙️ جودات احتياطية",
                sections: sections
            }
        }
    ]

    await conn.sendButtonNormal(chat, {
        caption: caption,
        buttons: buttons,
        mentions: [quoted?.sender ? quoted.sender.split('@')[0] + '@s.whatsapp.net' : undefined].filter(Boolean),
        footer: 'اختر الجودة من القائمة'
    }, quoted)
}

// ============ الهاندلر ============

const handler = async (m, { conn, args, usedPrefix, command }) => {
    const rawInput = args.join(' ').trim()

    if (!rawInput) {
        return conn.sendMessage(m.chat, {
            text: `🎬 تحميل من يوتيوب\n\n📌 الأوامر:\n• ${usedPrefix}${command} <رابط>\n• ${usedPrefix}${command} <بحث>\n\nمثال:\n${usedPrefix}${command} https://youtube.com/watch?v=xxx\n${usedPrefix}${command} anime edit`
        }, { quoted: m })
    }

    const isUrl = /(?:youtube\.com|youtu\.be|m\.youtube\.com)/i.test(rawInput)
    const parts = rawInput.split(SEP)

    const isQuickChoice = parts.length === 3 && parts[1] === 'quick'
    const isQualityChoice = parts.length === 3 && (parts[1] === 'video' || parts[1] === 'audio')
    const isFallbackRequest = parts.length === 2 && parts[1] === 'fallback'
    const isSearchResultSelection = parts.length === 2 && parts[1] === 'select'

    if (isQuickChoice) {
        const [videoId, , type] = parts
        await conn.sendMessage(m.chat, { text: '⏳ جاري التحميل السريع...' }, { quoted: m })

        try {
            const payload = await fetchFromV2(`https://youtube.com/watch?v=${videoId}`, type)
            await sendDownloadedMedia(conn, m.chat, payload, m)
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ ${e.message}\n\nجرب "جودات احتياطية" بدل كده` }, { quoted: m })
        }
        return
    }

    if (isQualityChoice) {
        const [videoId, type, quality] = parts
        await conn.sendMessage(m.chat, { text: '⏳ جاري التحميل...' }, { quoted: m })

        try {
            const payload = await fetchFromFallbackChain(`https://youtube.com/watch?v=${videoId}`, type, quality)
            await sendDownloadedMedia(conn, m.chat, payload, m)
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ ${e.message}` }, { quoted: m })
        }
        return
    }

    if (isFallbackRequest) {
        const [videoId] = parts
        try {
            const title = await axios.get(`https://www.youtube.com/oembed?url=https://youtube.com/watch?v=${videoId}&format=json`)
                .then(r => r.data?.title || null)
                .catch(() => null)

            await sendQualityList(conn, m.chat, m, usedPrefix, command, videoId, title)
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ ${e.message}` }, { quoted: m })
        }
        return
    }

    if (isSearchResultSelection) {
        const [videoId] = parts
        try {
            const title = await axios.get(`https://www.youtube.com/oembed?url=https://youtube.com/watch?v=${videoId}&format=json`)
                .then(r => r.data?.title || null)
                .catch(() => null)

            await sendQuickChoiceButtons(conn, m.chat, m, usedPrefix, command, videoId, title)
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ ${e.message}` }, { quoted: m })
        }
        return
    }

    if (isUrl) {
        const url = rawInput
        await conn.sendMessage(m.chat, { text: '⏳ جاري جلب المعلومات...' }, { quoted: m })

        try {
            const videoId = url.match(/(?:v=|\/)([0-9A-Za-z_-]{11})(?:[&?]|$)/)?.[1]
            if (!videoId) throw new Error('رابط غير صحيح')

            const title = await axios.get(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`)
                .then(r => r.data?.title || null)
                .catch(() => null)

            await sendQuickChoiceButtons(conn, m.chat, m, usedPrefix, command, videoId, title)
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ ${e.message}` }, { quoted: m })
        }
        return
    }

    // بحث
    await conn.sendMessage(m.chat, { text: `🔍 جاري البحث عن: ${rawInput}` }, { quoted: m })

    try {
        const results = await searchYouTube(rawInput)

        if (results.length === 0) {
            return conn.sendMessage(m.chat, { text: '❌ لا توجد نتائج' }, { quoted: m })
        }

        const sections = [{
            title: '🎬 النتائج',
            rows: results.slice(0, 10).map((video) => ({
                title: (video.title || 'بدون عنوان').substring(0, 40),
                description: `👤 ${video.author || 'غير معروف'} | 👁️ ${video.views || '-'} | ⏱️ ${video.duration || '-'}`,
                id: `${usedPrefix}${command} ${video.id}${SEP}select`
            }))
        }]

        const caption = `🔍 *نتائج البحث عن:* ${rawInput}\n📊 *عدد النتائج:* ${results.length}\n\n👇 اختر الفيديو للتحميل:`
        const buttons = [
            {
                name: "single_select",
                params: {
                    title: "📋 اختر فيديو",
                    sections: sections
                }
            }
        ]

        await conn.sendButtonNormal(m.chat, {
            caption: caption,
            buttons: buttons,
            mentions: [m.sender],
            footer: '🎬 YouTube Downloader'
        }, m)

    } catch (e) {
        await conn.sendMessage(m.chat, { text: `❌ ${e.message}` }, { quoted: m })
    }
}

handler.command = /^(يوتيوب|ytdl|يوت|بحث-يوتيوب)$/i
handler.help = ['يوتيوب <رابط/بحث>']
handler.tags = ['downloader']
handler.category = 'download'

export default handler
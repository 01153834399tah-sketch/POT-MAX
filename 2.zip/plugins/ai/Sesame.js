import axios from 'axios';

const handler = async (m, { conn, text }) => {
    if (!text) return m.reply("💬 ~ اكتب رسالة لسمسمي ~");

    try {
        // استخدام API من المستودع نفسه (engez-api)
        const res = await axios.get(`https://api.engez.xyz/api/simsimi?text=${encodeURIComponent(text)}`);
        const data = res.data;

        // محاولة استخراج الرد من هيكل API
        const reply = data?.result || data?.message || data?.response || data?.reply || "آسف، ما فهمت 😅";
        await m.reply(reply);
    } catch (err) {
        console.error("❌ خطأ في سمسمي:", err);
        m.reply("❌ حدث خطأ في سمسمي، حاول مرة أخرى.");
    }
};

handler.command = ["سمسمي", "simsimi"];
handler.category = "ai"; // ✅ تم التعديل: قسم الذكاء الاصطناعي
handler.usage = ["سمسمي <نص>"];

export default handler;
// plugins/ai/OpenAi.js
// الأمر: .اوبن (باستخدام أحدث نماذج OpenRouter)

import axios from 'axios';

// 🔑 مفتاح OpenRouter (مجاني - سجل في openrouter.ai/keys)
// ضعه في ملف .env أو اكتبه مباشرة هنا (غير آمن لكن للاختبار)
const OPENROUTER_API_KEY = ''; // اتركه فارغاً لاستخدام النموذج المجاني بدون مفتاح (محدود)
// أو استخدم مفتاحك: const OPENROUTER_API_KEY = 'sk-...';

const handler = async (m, { conn, text, bot }) => {
    if (!text) return m.reply("💙 ~ حط نص جنب الأمر ~ ❤️");

    await m.react('⏳');
    await conn.sendPresenceUpdate('composing', m.chat).catch(() => {});

    try {
        // 🔥 المحاولة 1: استخدام OpenRouter (نماذج 2025)
        const models = [
            'google/gemini-2.0-flash-exp:free',   // الأسرع والأحدث
            'deepseek/deepseek-chat',              // ذكاء قوي
            'microsoft/phi-3.5-mini-128k-instruct' // خفيف وسريع
        ];

        let reply = null;
        let usedModel = '';

        for (const model of models) {
            try {
                const response = await axios.post(
                    'https://openrouter.ai/api/v1/chat/completions',
                    {
                        model: model,
                        messages: [
                            { role: 'system', content: 'أنت مساعد ذكي ومفيد. أجب باللغة العربية.' },
                            { role: 'user', content: text }
                        ],
                        max_tokens: 1000,
                        temperature: 0.7
                    },
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': OPENROUTER_API_KEY ? `Bearer ${OPENROUTER_API_KEY}` : '',
                            'HTTP-Referer': 'https://wa.me/',
                            'X-Title': 'Pomni AI Bot'
                        },
                        timeout: 30000
                    }
                );

                if (response.data?.choices?.[0]?.message?.content) {
                    reply = response.data.choices[0].message.content;
                    usedModel = model;
                    break;
                }
            } catch (e) {
                console.log(`⚠️ فشل النموذج ${model}:`, e.message);
            }
        }

        if (reply) {
            // إرسال الرد مع ذكر النموذج المستخدم
            const finalReply = `🧠 *النموذج:* ${usedModel}\n\n${reply}`;
            if (finalReply.length > 60000) {
                const parts = finalReply.match(/[\s\S]{1,60000}/g) || [finalReply];
                for (const part of parts) await conn.sendMessage(m.chat, { text: part });
            } else {
                await m.reply(finalReply);
            }
            await m.react('✅');
            return;
        }

        // 🔹 المحاولة 2: استخدام المصدر القديم (pollinations.ai) كخيار أخير
        await m.reply('🔄 جاري استخدام المصدر البديل...');
        const fallbackUrl = `https://text.pollinations.ai/${encodeURIComponent(text)}?model=openai`;
        const fallbackRes = await axios.get(fallbackUrl, { timeout: 30000 });
        const fallbackReply = fallbackRes.data;

        if (fallbackReply && fallbackReply.length > 10) {
            if (fallbackReply.length > 60000) {
                const parts = fallbackReply.match(/[\s\S]{1,60000}/g) || [fallbackReply];
                for (const part of parts) await conn.sendMessage(m.chat, { text: part });
            } else {
                await m.reply(fallbackReply);
            }
            await m.react('✅');
        } else {
            throw new Error('جميع المصادر فشلت');
        }

    } catch (error) {
        console.error('❌ خطأ:', error.message);
        await m.reply('❌ حدث خطأ أثناء معالجة الطلب. حاول مرة أخرى لاحقًا.');
        await m.react('❌');
    }
};

handler.usage = ["اوبن"];
handler.category = "ai";
handler.command = ["اوبن", "openai", "ai"];

export default handler;
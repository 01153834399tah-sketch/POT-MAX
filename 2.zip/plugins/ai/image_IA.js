// plugins/ai/generate_image.js
// الأمر: .توليد وصف الصورة

import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TEMP_DIR = path.join(__dirname, '../../downloads/temp');

if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

const handler = async (m, { conn, text }) => {
    if (!text) {
        return m.reply(`🎨 *توليد صورة بالذكاء الاصطناعي*\n\n📌 *الاستخدام:*\n.توليد وصف الصورة\n\n📝 *مثال:*\n.توليد قطعة بيتزا عليها جبنة ذائبة وخلفية مطعم إيطالي`);
    }

    await m.react('🎨');
    await m.reply(`⏳ جاري توليد الصورة... قد يستغرق بضع ثوانٍ.`);

    try {
        // 🔥 استخدام Pollinations.ai (مجاني، بدون مفتاح)
        const prompt = encodeURIComponent(text);
        const imageUrl = `https://image.pollinations.ai/prompt/${prompt}?width=1024&height=1024&nologo=true`;

        // تحميل الصورة كـ Stream
        const response = await axios({
            method: 'GET',
            url: imageUrl,
            responseType: 'stream',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        // حفظ الصورة مؤقتاً
        const fileName = `generated_${Date.now()}.jpg`;
        const filePath = path.join(TEMP_DIR, fileName);
        const writer = fs.createWriteStream(filePath);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        // إرسال الصورة للمستخدم
        await conn.sendMessage(m.chat, {
            image: fs.readFileSync(filePath),
            caption: `🖼️ *تم توليد الصورة بنجاح!*\n📝 *الوصف:* ${text}\n🔗 *المصدر:* Pollinations.ai`
        });

        // حذف الملف المؤقت
        fs.unlinkSync(filePath);

        await m.react('✅');

    } catch (error) {
        console.error('❌ خطأ في توليد الصورة:', error.message);
        await m.reply(`❌ حدث خطأ أثناء توليد الصورة: ${error.message}\n💡 حاول مرة أخرى أو استخدم وصفاً مختلفاً.`);
        await m.react('❌');
    }
};

handler.command = ['توليد', 'generate', 'img'];
handler.category = 'ai';
handler.usage = ['توليد'];

export default handler;
import fs from 'fs';
import axios from 'axios';
import FormData from 'form-data';
import { uploadToQuax } from "../../system/utils.js";

const handler = async (m, { conn, command }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!mime) throw '*❲ ❤️ ❳ ~ اعمل ريبلاي علي الصوره او الفيديو أو الصوت ~ ❲ 💙 ❳ *';
    
    const media = await q.download();
    const link = await uploadToQuax(media);
    
    await conn.sendButtonNormal(m.chat, {
        media: { url: link },
        mediaType: 'image',
        caption: "🗃️ ~ Successful *(qu.ax)*\n- ```" + link + "```",
        buttons: [
            { name: "cta_copy", params: { display_text: "Copy Link", copy_code: link } },
            { name: "cta_url", params: { display_text: "📢 قناة البوت", url: "https://whatsapp.com/channel/0029VbDFMWi60eBbXu18xG2E" } }
        ],
        mentions: [m.sender],
        newsletter: {
            name: 'Pomni AI ~ Channel 🕷️',
            jid: '120363427163691139@newsletter'
        },
        interactiveConfig: {
            buttons_limits: 10,
            list_title: "Pomni AI ~ Channel 🕷️",
            button_title: "Click Here",
            canonical_url: "https://vxv-profile.vercel.app"
        }
    }, m);
};

handler.usage = ["لرابط"];
handler.category = "tools";
handler.command = ['لرابط', 'image2url'];

export default handler;
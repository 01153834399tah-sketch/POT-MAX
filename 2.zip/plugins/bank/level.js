// plugins/bank/level.js
// نظام المستويات والألقاب

export default async function before(m, { conn }) {
    if (!global.db?.users[m.sender]) return false;
    
    const user = global.db.users[m.sender];
    let xp = user.xp || 0;
    let level = user.level || 0;
    let nameLevel = user.nameLevel || '🎪 مشاهد';
    
    // ✅ الألقاب الأصلية للمستويات 0-20 (كما كانت)
    const originalLevels = [
        { min: 0, max: 99, name: '🎪 مشاهد' },
        { min: 100, max: 249, name: '🎭 متدرب سيرك' },
        { min: 250, max: 499, name: '🤡 مهرج صغير' },
        { min: 500, max: 799, name: '🎪 لاعب أكروبات' },
        { min: 800, max: 1199, name: '🎭 ساحر مبتدئ' },
        { min: 1200, max: 1699, name: '🤹 لاعب نار' },
        { min: 1700, max: 2299, name: '🎪 مروض أسود' },
        { min: 2300, max: 2999, name: '🎭 ساحر الظل' },
        { min: 3000, max: 3799, name: '🤡 مهرج الأكاذيب' },
        { min: 3800, max: 4699, name: '🎪 نجم السيرك' },
        { min: 4700, max: 5699, name: '🎭 وهمي' },
        { min: 5700, max: 6799, name: '🤹 سيد الألعاب' },
        { min: 6800, max: 7999, name: '🎪 مدير الحلبة' },
        { min: 8000, max: 9299, name: '🎭 أسطورة السيرك' },
        { min: 9300, max: 10699, name: '🤡 كابوس المهرج' },
        { min: 10700, max: 12199, name: '🎪 ساحر الأوهام' },
        { min: 12200, max: 13799, name: '🎭 مخرج العجائب' },
        { min: 13800, max: 15499, name: '🤹 سيد الخواتم' },
        { min: 15500, max: 17499, name: '🎪 إمبراطور السيرك' },
        { min: 17500, max: 19999, name: '🎭 حارس البوابة' },
        { min: 20000, max: Infinity, name: '🌀 الرقمي الأوحد' }
    ];

    // ✅ قائمة الألقاب الجديدة لكل 20 مستوى (بدءاً من المستوى 21)
    const newTitles = [
        '🌌 سيد الظلام',
        '⚡ صاعقة السماء',
        '🔥 نار الأبد',
        '❄️ جليد الأزلي',
        '🌊 حارس المحيط',
        '🌪️ إعصار القدر',
        '🪐 إله الكواكب',
        '☀️ شمس النهار',
        '🌙 قمر الليل',
        '✨ نجم الجبار',
        '💫 سديم الأوهام',
        '🌀 دوامة الزمن',
        '🕊️ روح السلام',
        '🐉 تنين النار',
        '🦅 نسر الجبال',
        '🐺 ذئب القمر',
        '🦁 ملك الغابة',
        '🐘 فيل الحرب',
        '🐍 أفعى الجحيم',
        '🐳 حوت الأعماق',
        '🦈 قرش المحيطات',
        '🦄 وحيد القرن',
        '🐉 تنين الظل',
        '🦅 صقر السماء',
        '🐺 ذئب الظلام',
        '🦁 أسد النور',
        '🐘 فيل العظمة',
        '🐍 ثعبان الخلود',
        '🐳 حوت الزمن',
        '🦈 قرش المصير'
    ];

    // 🔧 بناء قائمة المستويات الكاملة
    const levels = [...originalLevels];

    // إذا كان المستوى الحالي أكبر من 20، نضيف مستويات جديدة حسب الحاجة
    // نحدد عدد المستويات المطلوبة (مثلاً حتى 10000، أو بناءً على XP)
    const MAX_LEVEL = 10000;
    let currentMin = 20000;
    let currentLevelIndex = 21; // أول مستوى جديد هو 21

    // حلقة لإضافة مستويات جديدة حتى MAX_LEVEL
    for (let i = 0; i < Math.ceil((MAX_LEVEL - 20) / 20); i++) {
        const blockStart = 20 + i * 20 + 1;
        const blockEnd = Math.min(blockStart + 19, MAX_LEVEL);
        // نحدد XP للبداية والنهاية
        // نستخدم زيادة متصاعدة: كل مستوى يزيد بـ 1000 XP
        const xpStart = currentMin + 1000;
        const xpEnd = xpStart + (blockEnd - blockStart) * 1000 + 999;
        // اختيار الاسم من القائمة (إذا انتهت نستخدم اسم عام)
        const title = newTitles[i] || `🏅 مستوى ${blockStart}-${blockEnd}`;
        levels.push({
            min: xpStart,
            max: xpEnd,
            name: title
        });
        currentMin = xpEnd + 1;
        currentLevelIndex = blockEnd + 1;
    }

    // الآن نبحث عن المستوى المناسب
    let newLevel = level;
    let newNameLevel = nameLevel;
    let levelUp = false;
    let oldLevel = level;

    for (let i = 0; i < levels.length; i++) {
        const lvl = levels[i];
        if (xp >= lvl.min && xp <= lvl.max) {
            if (i !== level) {
                newLevel = i;
                newNameLevel = lvl.name;
                levelUp = true;
                oldLevel = level;
            }
            break;
        }
    }

    if (levelUp) {
        user.level = newLevel;
        user.nameLevel = newNameLevel;

        const msg = `╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ *🎭 تـرقـيـة فـي الـسـيـرك 🎪*
╰─┈─┈─┈─⟞🎭⟝─┈─┈─┈─╯

┃ @${m.sender.split('@')[0]}
┃ المستوى السابق: *${oldLevel}*
┃ المستوى الجديد: *${newLevel}*

┃ 🏷️ *لقبك الجديد:*
┃ ✦ ${newNameLevel} ✦

╭─┈─┈─┈─⟞🎭⟝─┈─┈─┈─╮
┃ *العرض لسه مخلصش يا بطل* 🎪
╰─┈─┈─┈─⟞🤡⟝─┈─┈─┈─╯`;

        await conn.sendMessage(m.chat, {
            text: msg,
            mentions: [m.sender]
        }, { quoted: reply_status });
    }

    return false;
}

export const usage = [];
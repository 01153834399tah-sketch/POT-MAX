// plugins/bank/His_profile.js
// الأمر: .بروفايله - عرض بروفايل مستخدم آخر

const handler = async (m, { conn, command, text, bot }) => {
    try {
        // 🎯 تحديد المستخدم المستهدف
        let targetUser = m.mentionedJid?.[0] || m.quoted?.sender;
        
        if (!targetUser) {
            return m.reply(`📌 *الاستخدام:*\n.بروفايله @مستخدم\nأو\n.بروفايله (رداً على رسالة المستخدم)`);
        }
        
        // 🚫 منع عرض البروفايل لنفس المستخدم
        if (targetUser === m.sender) {
            return m.reply(`📌 استخدم .بروفايل لعرض بروفايلك الشخصي.`);
        }

        // ✅ تحويل lid → jid إن أمكن (للحصول على الرقم الصحيح والمفتاح في قاعدة البيانات)
        let targetJid = targetUser;
        if (targetUser.includes('@lid') && typeof m.lid2jid === 'function') {
            const converted = await m.lid2jid(targetUser);
            if (converted) targetJid = converted;
        }

        // 📊 جلب بيانات المستخدم باستخدام targetJid (وليس targetUser)
        // لأن قاعدة البيانات تخزن البيانات بصيغة @s.whatsapp.net
        const user = global.db?.users?.[targetJid] || {};
        const xp = user.xp || 0;
        const level = user.level || 0;
        const nameLevel = user.nameLevel || '🎪 مـشـاهـد';
        const cookies = user.cookies || 0;
        const warnings = user.warnings || 0;
        const banned = user.banned || false;
        const premium = user.premium || false;
        const name = user.name || 'غير مسجل';
        const age = user.age || 'غير مسجل';
        
        // 👤 معلومات المستخدم (الاسم المعروض)
        let pushName = targetJid.split('@')[0]; // افتراضي (الرقم)
        try {
            // محاولة 1: باستخدام targetJid
            let contactName = await conn.getName(targetJid);
            if (contactName && contactName !== targetJid.split('@')[0]) {
                pushName = contactName;
            } else {
                // محاولة 2: باستخدام targetUser الأصلي
                contactName = await conn.getName(targetUser);
                if (contactName && contactName !== targetUser.split('@')[0]) {
                    pushName = contactName;
                }
            }
        } catch (_) {}

        // ✅ استخراج رقم الهاتف من JID
        const phoneNumber = targetJid.split('@')[0];
        
        // 📈 حساب المستوى التالي ونسبة التقدم
        const nextLevelXp = (() => {
            const levels = [100, 250, 500, 800, 1200, 1700, 2300, 3000, 3800, 4700, 5700, 6800, 8000, 9300, 10700, 12200, 13800, 15500, 17500, 20000];
            return levels[level] || levels[levels.length - 1];
        })();
        
        const xpProgress = Math.min(100, Math.floor((xp / nextLevelXp) * 100));
        const status = banned ? '🚫 مـحـظـور' : (premium ? '👑 بـريـمـيـوم' : '🟢 عـادي');
        
        // 🖼️ صورة البروفايل
        let profilePic = 'https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png';
        try {
            const pic = await conn.profilePictureUrl(targetUser, 'image');
            if (pic) profilePic = pic;
        } catch (_) {}

        // 📝 بناء رسالة البروفايل
        const msg = `╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ *🎭 بـروفـايـل ${pushName} 🎪*
╰─┈─┈─┈─⟞🎭⟝─┈─┈─┈─╯

┃ 📱 *الـرقـم:* ${phoneNumber}
┃ 🏷️ *الاسـم:* ${pushName}
┃ 📝 *الاسـم الـمـسـجـل:* ${name}
┃ 📅 *الـعـمـر:* ${age}
┃ 🎭 *الـلـقـب:* ${nameLevel}
┃ 📊 *الـمـسـتـوى:* ${level}
┃ ⭐ *الـنـقـاط:* ${xp} / ${nextLevelXp}
┃ 📈 *الـتـقـدم:* [${'⬜'.repeat(Math.floor(xpProgress / 10))}${'⬛'.repeat(10 - Math.floor(xpProgress / 10))}] ${xpProgress}%
┃ 🍪 *الـكـوكـيـز:* ${cookies}
┃ ⚠️ *الـتـحـذيـرات:* ${warnings}
┃ 🏷️ *الـحـالـة:* ${status}

╭─┈─┈─┈─⟞🎭⟝─┈─┈─┈─╮
┃ *هذا بروفايل ${pushName}* 🎪
╰─┈─┈─┈─⟞🤡⟝─┈─┈─┈─╯`;

        // 📤 إرسال البروفايل
        await conn.sendMessage(m.chat, {
            image: { url: profilePic },
            caption: msg,
            mentions: [targetUser]
        }, { quoted: m });

    } catch (error) {
        console.error('❌ خطأ في أمر بروفايله:', error);
        m.reply(`❌ حدث خطأ أثناء جلب البروفايل: ${error.message || 'خطأ غير معروف'}`);
    }
};

handler.usage = ["بروفايله"];
handler.category = "bank";
handler.command = ["بروفايله", "profileof"];

export default handler;
const handler = async (m, { conn, command, text }) => {
    if (!global.db?.users[m.sender]) {
        global.db.users[m.sender] = {};
    }
    
    const user = global.db.users[m.sender];
    
    if (command === "تسجيل") {
        if (!text) {
            return m.reply(`*📝 طريقة التسجيل:*\n\nتسجيل الاسم العمر\n\nمثال:\nتسجيل احمد 20`);
        }
        
        const parts = text.trim().split(/\s+/);
        if (parts.length < 2) {
            return m.reply(`*❌ خطأ:* يجب كتابة الاسم ثم العمر مفصولين بمسافة\n\nمثال:\nتسجيل احمد 20`);
        }
        
        const age = parseInt(parts[parts.length - 1]);
        const name = parts.slice(0, -1).join(' ');
        
        if (!name) {
            return m.reply(`*❌ خطأ:* يجب كتابة الاسم أولاً`);
        }
        
        if (isNaN(age) || age < 1 || age > 30) {
            return m.reply(`*❌ خطأ:* العمر يجب أن يكون رقماً بين 1 و 30`);
        }
        
        user.name = name;
        user.age = age;
        
        const profilePic = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png');
        
        const msg = `╭─┈─┈─┈─⟞📝⟝─┈─┈─┈─╮
┃ *✅ تـم الـتـسـجـيـل بـنـجـاح*
╰─┈─┈─┈─⟞✨⟝─┈─┈─┈─╯

┃ @${m.sender.split('@')[0]}
┃ 🏷️ *الاسـم:* ${name}
┃ 📅 *الـعـمـر:* ${age} سنة

╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ *أهـلاً وسـهـلاً فـي الـسـيـرك* 🎭
╰─┈─┈─┈─⟞🤡⟝─┈─┈─┈─╯`;

        await conn.sendMessage(m.chat, {
            image: { url: profilePic },
            caption: msg,
            mentions: [m.sender]
        }, { quoted: reply_status });
    }
    
    else if (command === "حذف_تسجيلي") {
        if (!user.name && !user.age) {
            return m.reply(`*❌ ليس لديك تسجيل لحذفه*\n\nاكتب .تسجيل اسم العمر للتسجيل`);
        }
        
        delete user.name;
        delete user.age;
        
        const profilePic = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png');
        
        const msg = `╭─┈─┈─┈─⟞🗑️⟝─┈─┈─┈─╮
┃ *✅ تـم حـذف الـتـسـجـيـل*
╰─┈─┈─┈─⟞✨⟝─┈─┈─┈─╯

┃ @${m.sender.split('@')[0]}
┃ 🏷️ تم حذف بياناتك بنجاح

╭─┈─┈─┈─⟞🎪⟝─┈─┈─┈─╮
┃ *يـمـكـنـك الـتـسـجـيـل مـرة أخـرى* 📝
╰─┈─┈─┈─⟞🤡⟝─┈─┈─┈─╯`;

        await conn.sendMessage(m.chat, {
            image: { url: profilePic },
            caption: msg,
            mentions: [m.sender]
        }, { quoted: reply_status });
    }
};

handler.usage = ["تسجيل", "حذف_تسجيلي"];
handler.category = "bank";
handler.command = ["تسجيل", "حذف_تسجيلي"];

export default handler;
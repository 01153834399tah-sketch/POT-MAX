// plugins/bank/super_level.js
// الأمر: .تطور_خارق (للمطورين فقط)

const handler = async (m, { conn, bot }) => {
    // 1️⃣ التحقق من أن المستخدم مطور رئيسي
    const isOwner = bot.config?.owners?.some(o => o.jid === m.sender || o.lid === m.sender);
    if (!isOwner) return m.reply("❌ هذا الأمر للمطورين الرئيسيين فقط.");

    // 2️⃣ التأكد من وجود قاعدة البيانات
    if (!global.db) global.db = {};
    if (!global.db.users) global.db.users = {};
    if (!global.db.users[m.sender]) {
        global.db.users[m.sender] = { xp: 0, level: 0 };
    }

    const user = global.db.users[m.sender];
    
    // 3️⃣ تسجيل المستوى القديم والجديد
    const oldLevel = user.level || 0;
    const newLevel = oldLevel + 9999;
    
    // 4️⃣ تطبيق التطوير الخارق
    user.level = newLevel;
    // إضافة XP ضخم لضمان عدم الرجوع للمستوى العادي (لو حدث خطأ ما)
    user.xp = (user.xp || 0) + 99999999;

    // 5️⃣ رسالة التأكيد
    const msg = `
╭─┈─┈─┈─⟞⭐⟝─┈─┈─┈─╮
┃ *🚀 تـطـور خـارق نـاجـح!*
╰─┈─┈─┈─⟞⭐⟝─┈─┈─┈─╯

┃ 🔼 المستوى القديم: *${oldLevel}*
┃ 🔽 المستوى الجديد: *${newLevel}*
┃ ✨ XP الحالي: *${user.xp}*

┃ 🦸 *أصبحت خارقاً! استخدم .بروفايل لرؤية مستواك.*
╰─┈─┈─┈─⟞🚀⟝─┈─┈─┈─╯`;

    await m.reply(msg);
};

handler.command = ['تطور_خارق'];
handler.category = 'bank';
handler.usage = ['تطور_خارق'];
handler.owner = true; // للمطورين فقط

export default handler;
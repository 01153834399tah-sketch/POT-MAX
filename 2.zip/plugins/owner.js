let handler = async (m, { conn, bot }) => {
  let watermark = 'VA';
  
  const num = bot.config.owners[0].jid.split("@")[0];
  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:${watermark}
TEL;type=CELL;waid=${num}:+${num}
END:VCARD`;

  let img = 'https://i.pinimg.com/originals/e2/21/20/e221203f319df949ee65585a657501a2.jpg';
  
  // ✅ الصورة مع النص في نفس الرسالة (بدون externalAdReply)
  await conn.sendButtonNormal(m.chat, {
    media: { url: img },
    mediaType: 'image',
    caption: `𝑇𝛨𝛯 𝛩𝑊𝛮𝛯𝑅\n${watermark}`,
    buttons: [
      { name: "cta_url", params: { display_text: "🔗 قناة البوت", url: "https://whatsapp.com/channel/0029VbDFMWi60eBbXu18xG2E" } }
    ],
    mentions: [m.sender]
  });
  
  // بطاقة الاتصال (رسالة منفصلة، لأن واتساب لا يسمح بدمجها مع صورة)
  await conn.sendMessage(m.chat, {
    contacts: { displayName: watermark, contacts: [{ vcard }] }
  });
};

handler.command = /^(owner|مطور|المطور)$/i;

export default handler;
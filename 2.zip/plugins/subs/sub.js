// plugins/subs/sub.js - أمر التنصيب (يدعم صور عشوائية)
if (!global.lastSubInstallTime) {
    global.lastSubInstallTime = 0;
}

const run = async (m, { args, conn, bot }) => {
    if (!m.isGroup) {
        return m.reply("❌ *أمر التنصيب يعمل فقط في المجموعات.*");
    }

    const sub = global.subBots;
    if (sub) {
        const connectedBots = sub.list().filter(b => b.connected);
        if (connectedBots.length >= 16) {
            return m.reply(`❌ لقد تم الوصول إلى الحد الأقصى لعدد البوتات المتصلة (16).\n📊 عدد البوتات المتصلة حالياً: ${connectedBots.length}\n💡 استخدم .غير متصل لحذف البوتات غير المتصلة.`);
        }
    }

    const now = Date.now();
    const timeSinceLastInstall = now - global.lastSubInstallTime;
    const cooldownMs = 60000;

    if (timeSinceLastInstall < cooldownMs) {
        const remainingSeconds = Math.ceil((cooldownMs - timeSinceLastInstall) / 1000);
        const minutes = Math.floor(remainingSeconds / 60);
        const seconds = remainingSeconds % 60;
        let timeMsg = '';
        if (minutes > 0) {
            timeMsg = `${minutes} دقيقة و ${seconds} ثانية`;
        } else {
            timeMsg = `${seconds} ثانية`;
        }
        return m.reply(`⏳ *المهلة الزمنية للتنصيب لم تنته بعد!*\n⏱️ انتظر ${timeMsg} قبل محاولة التنصيب مرة أخرى.`);
    }

    if (global.db.noSub) return m.reply("المطور قافل التنصيب");
    
    try {
        const num = m.sender.split("@")[0].replace(/[+\s-]/g, '');
        if (!/^\d+$/.test(num)) return m.reply("⚠️ رقم الهاتف غير صالح");
        if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح");

        const init = await m.reply(`⏳ جاري تنصيب بوت للرقم *${num}*...`);
        const state = { uid: null, pairDone: false, resolved: false, pending: null };

        // ✅ استخدام مصفوفة الصور من bot
        const images = bot?.config?.info?.images || [];
        const randomImage = images.length ? images[Math.floor(Math.random() * images.length)] : 'https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg';

        const cleanup = () => {
            sub.off('pair', handlers.pair);
            sub.off('ready', handlers.ready);
            sub.off('error', handlers.error);
        };

        const handlers = {
            pair: (id, code) => {
                if (state.pairDone) return;
                if (!state.uid) { 
                    state.pending = { id, code }; 
                    return; 
                }
                if (id !== state.uid) return;
                state.pairDone = true;
                Func.pair(conn, code, num, m, init, randomImage); // ✅ تمرير الصورة العشوائية
            },
            ready: (id) => {
                if (id !== state.uid || state.resolved) return;
                state.resolved = true;
                const img = images.length ? images[Math.floor(Math.random() * images.length)] : 'https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg';
                Func.ready(conn, num, m, img);
                cleanup();
            },
            error: (id, err) => {
                if (id !== state.uid || state.resolved) return;
                state.resolved = true;
                Func.error(conn, num, err, m);
                cleanup();
            },
        };

        sub.on('pair', handlers.pair);
        sub.on('ready', handlers.ready);
        sub.on('error', handlers.error);

        state.uid = await sub.add(num);

        if (state.pending?.id === state.uid && !state.pairDone) {
            state.pairDone = true;
            Func.pair(conn, state.pending.code, num, m, init, randomImage);
        }

        setTimeout(() => {
            if (state.resolved) return;
            state.resolved = true;
            Func.timeout(conn, m, state.pairDone);
            cleanup();
        }, 120000);

        global.lastSubInstallTime = Date.now();

    } catch (error) {
        await m.reply(error.message);
    }
};

run.command = ["تنصيب"];
run.noSub = true;
run.usage = ["تنصيب"];
run.category = "sub";
export default run;

const Func = {
    pair: async (conn, code, num, m, reply_status, randomImage) => {
        await conn.sendButtonNormal(m.chat, {
            media: { url: randomImage }, // ✅ صورة عشوائية
            mediaType: 'image',
            caption: `🔐⤿ نـظـام الـبـوتـات الـفـرعـيـه 𑁍
⊱⋅ ──────────── ⋅⊰
📱 — الرقم: ${num}
🔑 — الكود: ${code}
⊱⋅ ──────────── ⋅⊰
> *_افتح واتساب > الأجهزة المرتبطة > ربط جهاز برقم الهاتف > أدخل الكود_*`,
            buttons: [
                { name: "cta_copy", params: { display_text: "⟨🎪| 𝐂𝐨𝐩𝐲 𝐂𝐨𝐝𝐞 |🎪⟩", copy_code: code } },
                { name: "cta_url", params: { display_text: "⟨🫒| 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 𝐏𝐨𝐦𝐧𝐢 |🫒⟩", url: "https://whatsapp.com/channel/0029VbDFMWi60eBbXu18xG2E" } },
            ],
            mentions: [m.sender],
            newsletter: {
                name: 'Pomni AI ~ Channel 🕷️',
                jid: '120363427163691139@newsletter'
            },
            interactiveConfig: {
                buttons_limits: 10,
                list_title: "@𝑺𝒚𝒔𝒕𝒆𝒎_𝑺𝒖𝒃𝑩𝒐𝒕𝒔_𝑽𝑰𝑰",
                button_title: "Click Here",
                canonical_url: `https://code.com/${code}`
            }
        }, global.reply_status);
    },

    ready: async (conn, num, m, img) => {
        await m.react("✅");
        await conn.sendMessage(m.chat, {
            image: { url: img },
            caption: `✅ — *تـم الاتـصـال بـنـجـاح*\n\n📱 الرقم: ${num}\n> *البوت جاهز للاستخدام الآن*`
        });
    },

    error: async (conn, num, err, m) => {
        await m.reply(`❌ *فشل الاقتران!*\n\n📱 الرقم: ${num}\n⚠️ الخطأ: ${err?.message || 'غير معروف'}`);
    },

    timeout: async (conn, m, pairDone) => {
        await m.reply(pairDone
            ? `⏰ تم إرسال الكود لكن لم يتم تأكيد الاتصال.\nتأكد من إدخال الكود في واتساب.`
            : `⏰ لم يتم استلام كود الاقتران خلال 120 ثانية.\nالرجاء المحاولة مرة أخرى.`
        );
    }
};
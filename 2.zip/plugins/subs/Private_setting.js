// plugins/subs/private_mode.js
// الأمر: .خاص_فرعي [تشغيل|تعطيل]
// يعمل مع أي مستخدم، ويؤثر على البوت الفرعي بالكامل (يمنع الرد على الجميع في الخاص)

const handler = async (m, { conn, command, text, bot }) => {
    // التأكد من أن البوت هو بوت فرعي (وليس الرئيسي)
    if (!bot.isSubBot) {
        return m.reply("❌ هذا الأمر يعمل فقط على البوتات الفرعية.");
    }

    // التأكد من أن الدردشة خاصة (وليست مجموعة)
    if (m.isGroup) {
        return m.reply("❌ هذا الأمر يعمل فقط في المحادثات الخاصة.");
    }

    // الحصول على معرف البوت الفرعي الحالي
    const uid = bot.id;
    if (!uid) return m.reply("❌ لا يمكن تحديد البوت الفرعي.");

    // تهيئة قاعدة البيانات
    if (!global.db) global.db = {};
    if (!global.db.subBots) global.db.subBots = {};
    if (!global.db.subBots[uid]) global.db.subBots[uid] = {};

    const action = text?.trim().toLowerCase();

    // عرض الحالة الحالية
    if (!action) {
        const isDisabled = global.db.subBots[uid].privateDisabled || false;
        const status = isDisabled ? '🟢 **مفعل** (لا يرد على أي شخص في الخاص)' : '🔴 **معطل** (يرد على الجميع في الخاص)';
        return m.reply(`🔔 *حالة الخاص الفرعي*\n\n📊 الحالة: ${status}\n\n📌 الأوامر:\n.خاص_فرعي تشغيل   → تفعيل منع الرد على الجميع في الخاص\n.خاص_فرعي تعطيل   → إلغاء منع الرد`);
    }

    if (action === 'تشغيل') {
        global.db.subBots[uid].privateDisabled = true;
        return m.reply(`✅ *تم تفعيل وضع الصمت في الخاص.*\n🔒 البوت لن يرد على أي شخص في الخاص.`);
    } else if (action === 'تعطيل') {
        global.db.subBots[uid].privateDisabled = false;
        return m.reply(`❌ *تم إلغاء وضع الصمت في الخاص.*\n🔓 البوت سيرد على الجميع في الخاص.`);
    } else {
        return m.reply(`❌ وسيط غير معروف. استخدم:\n.خاص_فرعي تشغيل\n.خاص_فرعي تعطيل`);
    }
};

handler.command = ['خاص_فرعي'];
handler.category = 'sub';

export default handler;
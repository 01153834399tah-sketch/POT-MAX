// plugins/admin/zarf.js
// الأمر: .زرف (تطهير المجموعة) - يعمل مع المطورين والمشرفين

const handler = async (m, { conn, text, bot }) => {
    // ✅ التحقق من الصلاحيات (مطور أو مشرف)
    if (!m.isGroup) return m.reply("❌ هذا الأمر يعمل فقط في المجموعات.");
    if (!m.isOwner && !m.isAdmin) {
        return m.reply("❌ هذا الأمر للمشرفين والمطورين فقط.");
    }

    // جلب بيانات المجموعة
    const groupMetadata = await conn.groupMetadata(m.chat).catch(() => null);
    if (!groupMetadata) return m.reply("❌ لا يمكن جلب بيانات المجموعة.");

    // ❌ لا نتحقق من صلاحية البوت كمشرف (نترك الأمر لواتساب)

    const action = text?.trim().toLowerCase();

    // عرض التعليمات
    if (!action) {
        return m.reply(`
🧹 *أمر تطهير المجموعة*

📌 *للتأكيد:* اكتب
.زرف تفعيل

📌 *للإلغاء:* اكتب
.زرف الغاء

⚠️ *تحذير:* سيتم طرد جميع الأعضاء العاديين (عدا المطورين والأدمن والبوت).
        `);
    }

    // تنفيذ التطهير
    if (action === 'تفعيل') {
        const owners = bot.config?.owners?.map(o => o.jid) || [];
        const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
        const botJid = conn.user.id;

        // استثناء المطورين والأدمن والبوت
        const excluded = new Set([...owners, ...admins, botJid]);

        // إضافة جميع صيغ المطورين للحماية
        groupMetadata.participants.forEach(p => {
            const pId = p.id;
            if (owners.some(o => o === pId || o.replace(/@s\.whatsapp\.net$/, '') === pId.replace(/@s\.whatsapp\.net$/, ''))) {
                excluded.add(pId);
            }
            if (p.admin) excluded.add(pId);
            if (pId === botJid || pId.replace(/@s\.whatsapp\.net$/, '') === botJid.replace(/@s\.whatsapp\.net$/, '')) {
                excluded.add(pId);
            }
        });

        const toKick = groupMetadata.participants
            .map(p => p.id)
            .filter(id => !excluded.has(id));

        if (toKick.length === 0) {
            return m.reply("✅ لا يوجد أعضاء لطردهم (كلهم محميون).");
        }

        let kicked = 0;
        let errors = 0;

        for (let i = 0; i < toKick.length; i += 20) {
            const batch = toKick.slice(i, i + 20);
            try {
                await conn.groupParticipantsUpdate(m.chat, batch, 'remove');
                kicked += batch.length;
            } catch (e) {
                errors++;
                console.error('خطأ في الطرد:', e.message);
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        return m.reply(`🧹 *تم تطهير المجموعة!*\n\n👥 المطرودين: ${kicked}\n⚠️ الأخطاء: ${errors}`);
    }

    if (action === 'الغاء') {
        return m.reply("❌ تم إلغاء عملية التطهير.");
    }

    return m.reply("❌ وسيط غير معروف. استخدم: .زرف تفعيل  أو  .زرف الغاء");
};

// ✅ الخصائص الأساسية
handler.command = ['زرف', 'تطهير'];
handler.category = 'admin';
handler.usage = ['زرف'];
handler.admin = true;      // يطلب أن يكون المستخدم مشرفاً (لكننا نتحقق يدوياً أيضاً)
handler.botAdmin = true;   // يطلب أن يكون البوت مشرفاً (سيترك لواتساب)

export default handler;
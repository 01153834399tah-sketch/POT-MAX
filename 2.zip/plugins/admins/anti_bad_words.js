// plugins/admin/anti_bad_words.js
// نظام منع الكلمات السيئة (السب والشتم) + إضافة كلمات مخصصة

// ========== الكلمات الأساسية ==========
const BAD_WORDS_BASE = [
    'ابن الكلب', 'ابن القحبة', 'احا', 'اختك', 'امك', 'بضان', 'بعبص', 'تلحس', 'جحش', 'حمار',
    'حثالة', 'خول', 'داعر', 'دين امك', 'زبالة', 'زفت', 'سخيف', 'سفلة', 'شرموطة', 'صعر',
    'ضرس', 'طز', 'عاهر', 'عاهرة', 'عيب', 'غبي', 'فاسد', 'قحبة', 'كلب', 
    'كس امك', 'كس أمك',
    'كس اختك', 'لعين', 'معرص', 'مخصي', 'مزبلة', 'مصاص', 'مصران', 'مقرف', 'ملعون', 'منحوس',
    'منيك', 'ناكح', 'نذل', 'هراء', 'وسخ', 'يا كلب', 'يا خول', 'يا عرص',
    'كسم', 'نيك', 'ود حرام', 'ود لزينة',
    // إنجليزي
    'fuck', 'shit', 'bitch', 'asshole', 'bastard', 'dick', 'pussy', 'cunt', 'whore',
    'slut', 'motherfucker', 'damn', 'hell', 'crap', 'stupid', 'idiot', 'moron',
    'retard', 'dumb', 'loser', 'sucker', 'wanker', 'prick', 'cock', 'balls'
];

// ========== تخزين مؤقت للتحذيرات ==========
const warnings = new Map();

// ========== دوال مساعدة ==========
function getCustomWords(chatId) {
    return global.db?.groups?.[chatId]?.customBadWords || [];
}

function getAllBadWords(chatId) {
    const custom = getCustomWords(chatId);
    // إزالة التكرارات
    const all = [...BAD_WORDS_BASE, ...custom];
    return [...new Set(all)];
}

function getSetting(chatId) {
    return global.db?.groups?.[chatId]?.antiBadWords || false;
}

function containsBadWord(text, chatId) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const allWords = getAllBadWords(chatId);
    for (const word of allWords) {
        if (lower.includes(word)) return true;
        // تجاهل المسافات
        if (lower.includes(word.replace(/\s/g, ''))) return true;
    }
    return false;
}

// ========== معالج الكلمات السيئة ==========
async function antiBadWords(m, conn) {
    if (!m.isGroup) return false;
    if (m.isOwner || m.isAdmin) return false;
    if (!getSetting(m.chat)) return false;
    if (!m.text) return false;
    if (!containsBadWord(m.text, m.chat)) return false;

    const key = `${m.chat}_${m.sender}`;
    const MAX = 5;
    const RESET = 15000;
    const now = Date.now();

    if (!warnings.has(key)) warnings.set(key, { count: 0, last: now });
    const data = warnings.get(key);
    if (now - data.last > RESET) data.count = 0;
    data.count++;
    data.last = now;
    warnings.set(key, data);

    try {
        await conn.sendMessage(m.chat, { delete: m.key });
        let msg = `⚠️ *تحذير ${data.count}/${MAX}!*\n@${m.sender.split('@')[0]} ممنوع الكلمات السيئة.`;
        if (data.count < MAX) msg += `\n📌 تبقى ${MAX - data.count} تحذير قبل الطرد.`;
        await conn.sendMessage(m.chat, { text: msg, mentions: [m.sender] });

        if (data.count >= MAX) {
            await conn.sendMessage(m.chat, {
                text: `🚫 @${m.sender.split('@')[0]} تم طردك بسبب الكلمات السيئة.`,
                mentions: [m.sender]
            });
            await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            warnings.delete(key);
        }
        return true;
    } catch (_) { return false; }
}

// ========== عرض القائمة ==========
function buildMenu(chatId) {
    const status = getSetting(chatId) ? '🟢 مفعل' : '🔴 معطل';
    const custom = getCustomWords(chatId);
    const customList = custom.length ? custom.map(w => `• ${w}`).join('\n') : 'لا توجد كلمات مضافة';

    return `
🛡️ *نظام منع الكلمات السيئة*

📊 الحالة: ${status}

📝 *الكلمات المضافة (خاصة بالمجموعة):*
${customList}

📌 *الأوامر:*
.السب تشغيل      → تفعيل النظام
.السب ايقاف      → تعطيل النظام
.السب اضافه كلمة → إضافة كلمة جديدة
.السب حذف كلمة   → حذف كلمة موجودة
    `.trim();
}

// ========== الأمر الرئيسي ==========
const handler = async (m, { conn, text, bot }) => {
    if (!m.isGroup) return m.reply("❌ هذا الأمر للمجموعات فقط.");
    if (!m.isOwner && !m.isAdmin) return m.reply("❌ هذا الأمر للمشرفين والمطورين فقط.");

    // تهيئة إعدادات المجموعة
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    const g = global.db.groups[m.chat];
    if (!g.customBadWords) g.customBadWords = [];

    // إذا لم يكتب نص → عرض القائمة
    if (!text) {
        return m.reply(buildMenu(m.chat));
    }

    const parts = text.trim().split(/\s+/);
    const action = parts[0]?.toLowerCase();
    const word = parts.slice(1).join(' ');

    // ====== تشغيل ======
    if (action === 'تشغيل') {
        g.antiBadWords = true;
        return m.reply("✅ *تم تشغيل منع السب.*\n🛡️ سيتم حذف الكلمات السيئة وتحذير المخالفين (طرد بعد 5 تحذيرات).");
    }

    // ====== إيقاف ======
    if (action === 'ايقاف') {
        g.antiBadWords = false;
        return m.reply("❌ *تم إيقاف منع السب.*");
    }

    // ====== إضافة كلمة ======
    if (action === 'اضافه') {
        if (!word) return m.reply("❌ *اكتب الكلمة التي تريد إضافتها.*\nمثال: .السب اضافه كلمة سيئة");
        const lowerWord = word.toLowerCase().trim();
        if (BAD_WORDS_BASE.includes(lowerWord)) {
            return m.reply(`⚠️ *"${word}"* موجودة بالفعل في القائمة الأساسية.`);
        }
        if (g.customBadWords.includes(lowerWord)) {
            return m.reply(`⚠️ *"${word}"* موجودة بالفعل في قائمة الكلمات المضافة.`);
        }
        g.customBadWords.push(lowerWord);
        return m.reply(`✅ *تم إضافة كلمة:* "${word}"\n📌 سيتم حظرها من الآن فصاعداً.`);
    }

    // ====== حذف كلمة ======
    if (action === 'حذف') {
        if (!word) return m.reply("❌ *اكتب الكلمة التي تريد حذفها.*\nمثال: .السب حذف كلمة سيئة");
        const lowerWord = word.toLowerCase().trim();
        const index = g.customBadWords.indexOf(lowerWord);
        if (index === -1) {
            return m.reply(`⚠️ *"${word}"* غير موجودة في قائمة الكلمات المضافة.`);
        }
        g.customBadWords.splice(index, 1);
        return m.reply(`✅ *تم حذف كلمة:* "${word}"\n📌 لن يتم حظرها بعد الآن.`);
    }

    // ====== عرض قائمة الكلمات المضافة ======
    if (action === 'قائمة') {
        const custom = g.customBadWords;
        const list = custom.length ? custom.map(w => `• ${w}`).join('\n') : 'لا توجد كلمات مضافة';
        return m.reply(`📝 *الكلمات المضافة (خاصة بالمجموعة):*\n${list}`);
    }

    // ====== أي أمر غير معروف ======
    return m.reply(`
❌ *أمر غير معروف.*

📌 *الأوامر المتاحة:*
.السب تشغيل
.السب ايقاف
.السب اضافه كلمة
.السب حذف كلمة
.السب قائمة
    `.trim());
};

// ========== المعالج (before) ==========
handler.before = async (m, { conn }) => {
    if (await antiBadWords(m, conn)) return true;
    return false;
};

handler.command = ['السب'];
handler.category = 'admin';
handler.usage = ['السب'];

export default handler;
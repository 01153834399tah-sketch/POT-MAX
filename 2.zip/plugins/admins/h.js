const h = async (m, { text, bot, conn }) => {
    try {
        const { images } = bot.config.info;
        // اختيار صورة عشوائية بالطريقة الصحيحة
        const randomImage = Array.isArray(images) && images.length ? images[Math.floor(Math.random() * images.length)] : null;
        
        const customText = text || "ﷺ";
        
        if (!m.quoted) {
            // إرسال الصورة مع النص في رسالة واحدة (بدون externalAdReply)
            if (randomImage) {
                await conn.sendMessage(m.chat, {
                    image: { url: randomImage },
                    caption: customText
                });
            } else {
                await conn.sendMessage(m.chat, { text: customText });
            }
            return;
        }
        
        // إذا كان هناك رسالة مقتبسة
        const groupMetadata = await conn.groupMetadata(m.chat);
        const participants = groupMetadata.participants.map(v => v.id);
        const quotedText = m.quoted.text || "رسالة مقتبسة";
        
        const finalText = `📩 *رسالة مقتبسة:*\n${quotedText}\n\n${customText}`;
        
        if (randomImage) {
            await conn.sendMessage(m.chat, {
                image: { url: randomImage },
                caption: finalText,
                mentions: participants
            });
        } else {
            await conn.sendMessage(m.chat, {
                text: finalText,
                mentions: participants
            });
        }
    } catch (err) {
        await m.reply(err.message);
    }
};

h.usage = ["مخفي"];
h.category = "admin";
h.command = ['مخفي', 'h'];
h.group = true;
h.admin = true;
h.usePrefix = false;

export default h;
const handler = async (m, { conn }) => {
  // تحديد المستهدف: إما منشن أو رد أو المرسل نفسه
  let target = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;

  // إذا كان المستهدف هو نفسه المرسل، نستخدم رقمه
  // وإلا نحتاج للحصول على رقم الهاتف من الـ JID أو LID
  let phoneNumber;
  if (target === m.sender) {
    phoneNumber = m.sender.split('@')[0];
  } else {
    // محاولة الحصول على رقم الهاتف من معلومات المجموعة
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participant = groupMetadata.participants.find(p => p.id === target);
    if (participant) {
      phoneNumber = participant.phoneNumber || target.split('@')[0];
    } else {
      phoneNumber = target.split('@')[0];
    }
  }

  const warnings = global.db.groups?.[m.chat]?.warnings?.[phoneNumber] || 0;

  let message = '';
  if (target === m.sender) {
    message = `📊 @${phoneNumber} عندك ${warnings} إنذار${warnings !== 1 ? 'ات' : ''}`;
  } else {
    message = `📊 @${phoneNumber} عنده ${warnings} إنذار${warnings !== 1 ? 'ات' : ''}`;
  }

  await conn.sendMessage(m.chat, {
    text: message,
    mentions: [target]
  }, { quoted: global.reply_status });
};

handler.command = ["انذاراتي", "warns", "warnings", "الانذارات", "انذارات"];
handler.usage = ['الانذارات'];
handler.category = "admin";
handler.group = true; // يتطلب وجود المجموعة

export default handler;
// plugins/admins/control.js
let control = async (m, { command, text, conn, bot, participants }) => {
    try {
        const isBotOwner = (userId) => {
            if (!bot.config || !bot.config.owners) return false;
            return bot.config.owners.some(owner => 
                owner.jid === userId || owner.lid === userId
            );
        };

        const cleanPhoneNumber = (number) => {
            if (!number) return null;
            return number.replace(/[^0-9]/g, '');
        };

        const getUser = () => {
            if (m.quoted) return m.quoted.sender;
            if (m.mentionedJid && m.mentionedJid.length > 0) return m.mentionedJid[0];
            if (text) {
                const cleaned = cleanPhoneNumber(text);
                if (cleaned) return cleaned + "@s.whatsapp.net";
            }
            return null;
        };

        const addParticipant = async (jid) => {
            if (!jid) return m.reply("❌ رقم غير صالح");
            await conn.groupParticipantsUpdate(m.chat, [jid], 'add');
            return m.reply("*✅ تمت الإضافة*");
        };

        if (command === "ضيف") {
            if (!text) return m.reply("❌ فين الرقم؟");
            
            if (m.quoted) {
                return addParticipant(m.quoted.sender);
            }
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                return addParticipant(m.mentionedJid[0]);
            }
            
            const cleanedNumber = cleanPhoneNumber(text);
            if (!cleanedNumber) return m.reply("❌ رقم غير صالح");
            const targetJid = cleanedNumber + "@s.whatsapp.net";
            return addParticipant(targetJid);
        }
        
        if (command === "طرد") {
            let user = getUser();
            if (!user) return m.reply("❌ منشن أو رد على العضو");
            
            if (isBotOwner(user) || user === conn.user.id) {
                m.reply("بتهزر ؟");
                return await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            }
            
            await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
            return m.reply("✅ تم الطرد");
        }
        
        if (command === "رفع") {
            let user = getUser();
            if (!user) return m.reply("❌ منشن أو رد على العضو");
            await conn.groupParticipantsUpdate(m.chat, [user], 'promote');
            return m.reply("✅ تم الرفع");
        }
        
        if (command === "خفض") {
            let user = getUser();
            if (!user) return m.reply("❌ منشن أو رد على العضو");
            await conn.groupParticipantsUpdate(m.chat, [user], 'demote');
            return m.reply("✅ تم الخفض");
        }
        
    } catch (error) {
        await m.reply("❌ " + error.message);
    }
};

control.usage = ['ضيف', 'طرد', 'رفع', 'خفض'];
control.command = ['ضيف', 'طرد', 'رفع', 'خفض'];
control.admin = true;
// ❌ تم إزالة control.botAdmin
control.category = "admin";

export default control;
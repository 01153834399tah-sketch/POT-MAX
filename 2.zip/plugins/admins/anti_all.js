// plugins/admin/anti_all.js
// نظام متكامل لمكافحة الإزعاج (مع أزرار)

// ========== تخزين مؤقت ==========
const messageCounts = new Map();
const lastMessages = new Map();
const warnings = new Map();

// ========== دوال مساعدة ==========
function getSetting(chatId, feature) {
    if (!global.db?.groups?.[chatId]) return false;
    return global.db.groups[chatId][feature] || false;
}

function isExempt(m) {
    return m.isOwner || m.isAdmin;
}

// ========== 1️⃣ مضاد مشاركة الحالات ==========
async function antiStatus(m, conn) {
    if (!m.isGroup) return false;
    if (isExempt(m)) return false;
    if (!getSetting(m.chat, 'antiStatus')) return false;
    
    const isStatusShare = m.message?.protocolMessage?.type === 'REVOKE' ||
                          m.quoted?.message?.protocolMessage?.type === 'REVOKE' ||
                          m.message?.protocolMessage?.key?.id?.startsWith('BAE5') ||
                          m.quoted?.message?.protocolMessage?.key?.id?.startsWith('BAE5');
    
    if (isStatusShare) {
        try {
            await conn.sendMessage(m.chat, { delete: m.key });
            await conn.sendMessage(m.chat, {
                text: `🚫 *ممنوع مشاركة الحالات!*\n@${m.sender.split('@')[0]} يرجى عدم مشاركة حالات واتساب.`,
                mentions: [m.sender]
            });
            return true;
        } catch (_) {}
    }
    return false;
}

// ========== 2️⃣ مضاد سبام ==========
async function antiSpam(m, conn) {
    if (!m.isGroup) return false;
    if (isExempt(m)) return false;
    if (!getSetting(m.chat, 'antiSpam')) return false;
    
    const chatId = m.chat;
    const userId = m.sender;
    const now = Date.now();
    const key = `${chatId}_${userId}`;
    const MAX_MESSAGES = 5;
    const TIME_WINDOW = 3000;
    
    if (!messageCounts.has(key)) {
        messageCounts.set(key, []);
    }
    
    const timestamps = messageCounts.get(key);
    while (timestamps.length && timestamps[0] < now - TIME_WINDOW) {
        timestamps.shift();
    }
    
    timestamps.push(now);
    messageCounts.set(key, timestamps);
    
    if (timestamps.length > MAX_MESSAGES) {
        try {
            await conn.sendMessage(m.chat, { delete: m.key });
            await conn.sendMessage(m.chat, {
                text: `🚫 *تم حذف رسالة سبام!*\n@${m.sender.split('@')[0]} يرجى التوقف عن الإرسال السريع.`,
                mentions: [m.sender]
            });
            
            if (!global.db.users[userId]) global.db.users[userId] = {};
            const user = global.db.users[userId];
            user.spamWarnings = (user.spamWarnings || 0) + 1;
            
            if (user.spamWarnings >= 3) {
                await conn.sendMessage(m.chat, {
                    text: `🚫 @${m.sender.split('@')[0]} تم طردك بسبب الإزعاج المتكرر.`,
                    mentions: [m.sender]
                });
                await conn.groupParticipantsUpdate(m.chat, [userId], 'remove');
                user.spamWarnings = 0;
            }
            return true;
        } catch (_) {}
    }
    return false;
}

// ========== 3️⃣ مضاد تكرار ==========
async function antiRepeat(m, conn) {
    if (!m.isGroup) return false;
    if (isExempt(m)) return false;
    if (!m.text) return false;
    if (!getSetting(m.chat, 'antiRepeat')) return false;
    
    const chatId = m.chat;
    const userId = m.sender;
    const text = m.text.trim();
    const key = `${chatId}_${userId}`;
    const TIME_WINDOW = 10000;
    
    if (!lastMessages.has(key)) {
        lastMessages.set(key, { text, time: Date.now() });
        return false;
    }
    
    const last = lastMessages.get(key);
    const now = Date.now();
    
    if (text === last.text && (now - last.time) < TIME_WINDOW) {
        try {
            await conn.sendMessage(m.chat, { delete: m.key });
            await conn.sendMessage(m.chat, {
                text: `🚫 *تم حذف رسالة مكررة!*\n@${m.sender.split('@')[0]} يرجى عدم تكرار نفس الرسالة.`,
                mentions: [m.sender]
            });
            return true;
        } catch (_) {}
    }
    
    lastMessages.set(key, { text, time: now });
    return false;
}

// ========== 4️⃣ مضاد إزعاج ==========
async function antiNuisance(m, conn) {
    if (!m.isGroup) return false;
    if (isExempt(m)) return false;
    if (!m.text) return false;
    if (!getSetting(m.chat, 'antiNuisance')) return false;
    
    const chatId = m.chat;
    const userId = m.sender;
    const now = Date.now();
    const key = `${chatId}_${userId}`;
    const TIME_RESET = 60000;
    
    if (!warnings.has(key)) {
        warnings.set(key, { count: 0, firstWarning: now, lastWarning: now });
    }
    
    const data = warnings.get(key);
    if (now - data.lastWarning > TIME_RESET) {
        data.count = 0;
    }
    
    const isNuisance = m.text.length > 500 ||
                       /[A-Z]{5,}/.test(m.text) ||
                       /[!?]{3,}/.test(m.text);
    
    if (isNuisance) {
        data.count++;
        data.lastWarning = now;
        warnings.set(key, data);
        
        try {
            await conn.sendMessage(m.chat, { delete: m.key });
            await conn.sendMessage(m.chat, {
                text: `⚠️ *تحذير ${data.count}/3!*\n@${m.sender.split('@')[0]} يرجى الالتزام بآداب المجموعة.`,
                mentions: [m.sender]
            });
            
            if (data.count >= 3) {
                await conn.sendMessage(m.chat, {
                    text: `🚫 @${m.sender.split('@')[0]} تم طردك بسبب الإزعاج المتكرر.`,
                    mentions: [m.sender]
                });
                await conn.groupParticipantsUpdate(m.chat, [userId], 'remove');
                warnings.delete(key);
            }
            return true;
        } catch (_) {}
    }
    return false;
}

// ========== عرض القائمة مع أزرار ==========
async function sendMenu(m, conn) {
    const chatId = m.chat;
    const features = [
        { key: 'antiStatus', name: 'مضاد_حالات', desc: 'يمنع مشاركة الحالات', icon: '📱' },
        { key: 'antiSpam', name: 'مضاد_سبام', desc: 'يمنع السبام (5 رسائل/3 ثوانٍ)', icon: '🔄' },
        { key: 'antiRepeat', name: 'مضاد_تكرار', desc: 'يمنع تكرار الرسائل', icon: '🔁' },
        { key: 'antiNuisance', name: 'مضاد_ازعاج', desc: 'يمنع الإزعاج (طويل، كبير، علامات)', icon: '🚫' }
    ];
    
    let caption = `
╭─┈─┈─┈─⟞🛡️⟝─┈─┈─┈─╮
┃ *نظام مكافحة الإزعاج*
╰─┈─┈─┈─⟞🛡️⟝─┈─┈─┈─╯
`;
    for (const f of features) {
        const status = getSetting(chatId, f.key) ? '🟢 مفعل' : '🔴 معطل';
        caption += `
┃ ${f.icon} *${f.name}*
┃ └─ ${f.desc}
┃ └─ الحالة: ${status}
`;
    }
    caption += `
╭─┈─┈─┈─⟞💡⟝─┈─┈─┈─╮
┃ *اضغط على الزر للتحكم*
╰─┈─┈─┈─⟞💡⟝─┈─┈─┈─╯`;

    // بناء الأزرار (كل ميزة لها زرين: تشغيل وإيقاف)
    const buttons = [];
    for (const f of features) {
        buttons.push({
            name: "quick_reply",
            params: {
                display_text: `✅ تشغيل ${f.name}`,
                id: `.تفعيل_مميز ${f.name} تشغيل`
            }
        });
        buttons.push({
            name: "quick_reply",
            params: {
                display_text: `❌ إيقاف ${f.name}`,
                id: `.تفعيل_مميز ${f.name} ايقاف`
            }
        });
    }

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: caption,
        buttons: buttons,
        mentions: [m.sender]
    }, global.reply_status);
}

// ========== الأوامر الرئيسية ==========
const handler = async (m, { conn, command, text, bot }) => {
    if (!m.isGroup) return m.reply("❌ هذا الأمر يعمل فقط في المجموعات.");
    
    const isOwner = bot.config?.owners?.some(o => o.jid === m.sender || o.lid === m.sender);
    const groupMetadata = await conn.groupMetadata(m.chat).catch(() => null);
    const isAdmin = groupMetadata?.participants?.some(p => p.id === m.sender && p.admin) || false;
    
    if (!isOwner && !isAdmin) return m.reply("❌ هذا الأمر للمشرفين والمطورين فقط.");
    
    // تهيئة إعدادات المجموعة
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    const g = global.db.groups[m.chat];
    
    // قائمة الميزات المدعومة
    const features = {
        'مضاد_حالات': 'antiStatus',
        'مضاد_سبام': 'antiSpam',
        'مضاد_تكرار': 'antiRepeat',
        'مضاد_ازعاج': 'antiNuisance'
    };
    
    // إذا لم يكتب وسيطاً → عرض القائمة بالأزرار
    if (!text) {
        return await sendMenu(m, conn);
    }
    
    // تحليل الوسائط: .تفعيل_مميز [الميزة] [تشغيل/ايقاف]
    const parts = text.trim().split(/\s+/);
    if (parts.length < 2) {
        return m.reply(`❌ استخدم: .تفعيل_مميز [الميزة] [تشغيل/ايقاف]\n\nالميزات المتاحة:\n- مضاد_حالات\n- مضاد_سبام\n- مضاد_تكرار\n- مضاد_ازعاج`);
    }
    
    const featureName = parts[0];
    const action = parts[1]?.toLowerCase();
    const featureKey = features[featureName];
    
    if (!featureKey) {
        return m.reply(`❌ ميزة غير معروفة. الميزات المتاحة:\n- مضاد_حالات\n- مضاد_سبام\n- مضاد_تكرار\n- مضاد_ازعاج`);
    }
    
    if (action === 'تشغيل') {
        g[featureKey] = true;
        return m.reply(`✅ *تم تشغيل ${featureName}* بنجاح.\n🛡️ سيتم تطبيقه على جميع الأعضاء (عدا المشرفين والمطورين).`);
    } else if (action === 'ايقاف') {
        g[featureKey] = false;
        return m.reply(`❌ *تم إيقاف ${featureName}* بنجاح.`);
    } else {
        const status = g[featureKey] ? '✅ مفعل' : '❌ معطل';
        return m.reply(`📊 *حالة ${featureName}:* ${status}\n\n📌 للتحكم:\n.تفعيل_مميز ${featureName} تشغيل\n.تفعيل_مميز ${featureName} ايقاف`);
    }
};

// ========== المعالج الرئيسي (before) ==========
handler.before = async (m, { conn }) => {
    if (await antiStatus(m, conn)) return true;
    if (await antiSpam(m, conn)) return true;
    if (await antiRepeat(m, conn)) return true;
    if (await antiNuisance(m, conn)) return true;
    return false;
};

handler.command = ['تفعيل_مميز'];
handler.category = 'admin';
handler.usage = ['تفعيل_مميز'];

export default handler;
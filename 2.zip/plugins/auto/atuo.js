// plugins/auto/atuo.js
export default async function before(m, { conn, bot }) {
    const g = global.db?.groups[m.chat];
    const u = global.db?.users[m.sender];
    
    if (u?.banned && !m.isOwner) return true;
    
    // ✅ استثناء أمر التنصيب من وضع الادمن فقط
    const isInstall = m.text && (m.text.startsWith('.تنصيب') || m.text.startsWith('/تنصيب'));
    
    // ✅ استثناء أمر الإبلاغ من وضع الادمن فقط
    const isReport = m.text && (m.text.startsWith('.ابلاغ') || m.text.startsWith('/ابلاغ') || m.text.startsWith('.report'));
    
    // ✅ استثناء الرسائل التي تحتوي على روابط (لتمريرها إلى anti-link)
    const isLink = m.text && /(https?:\/\/)?(chat\.whatsapp\.com|whatsapp\.com\/channel)\/[A-Za-z0-9]+/gi.test(m.text);
    
    // منع الرسائل في وضع الأدمن فقط، مع استثناء التنصيب والابلاغ والروابط
    if (g?.adminOnly && !m.isOwner && !m.isAdmin && !isInstall && !isReport && !isLink) return true;
    
    if (global.db?.dev && !m.isOwner && !m.isGroup) return true;
    
    if (global.db?.ownerOnly && !m.isOwner) return true;
    
    return false;
};
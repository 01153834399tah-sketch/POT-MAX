// plugins/auto/anti_channel_links.js
// نظام تلقائي لكشف زر "عرض القناة" وطرد المرسل (ما عدا البوتات الفرعية)

function getNumber(jid) {
    if (!jid) return '';
    return jid.split('@')[0].replace(/[^0-9]/g, '');
}

function isMySubBot(sender, sub) {
    if (!sub) return false;
    const bots = sub.list();
    return bots.some(b => b.id === sender || b.phone === getNumber(sender));
}

function hasChannelButton(m) {
    try {
        const msg = m.message;
        if (!msg) return false;

        const interactive = msg.interactiveMessage;
        if (interactive) {
            const nativeFlow = interactive.nativeFlowMessage;
            if (nativeFlow && nativeFlow.buttons) {
                for (const btn of nativeFlow.buttons) {
                    const btnText = btn.buttonParamsJson || '';
                    if (btnText.includes('عرض القناة') ||
                        btnText.includes('channel') ||
                        btnText.includes('whatsapp.com/channel')) {
                        return true;
                    }
                }
            }
            const body = interactive.body?.text || '';
            const footer = interactive.footer?.text || '';
            if (/عرض القناة|whatsapp\.com\/channel|chat\.whatsapp\.com/i.test(body + ' ' + footer)) {
                return true;
            }
        }

        const extText = msg.extendedTextMessage;
        if (extText && extText.text && /عرض القناة|whatsapp\.com\/channel|chat\.whatsapp\.com/i.test(extText.text)) {
            return true;
        }

        const text = m.text || m.quoted?.text || '';
        if (/عرض القناة|whatsapp\.com\/channel|chat\.whatsapp\.com/i.test(text)) {
            return true;
        }

        return false;
    } catch (_) {
        return false;
    }
}

// ========== الأمر الرئيسي (للتحكم فقط) ==========
const handler = async (m, { conn, text, bot }) => {
    if (!m.isGroup) return m.reply("❌ هذا الأمر يعمل فقط في المجموعات.");
    if (!m.isOwner && !m.isAdmin) {
        return m.reply("❌ هذا الأمر للمشرفين والمطورين فقط.");
    }

    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};

    const g = global.db.groups[m.chat];
    const action = text?.trim().toLowerCase();

    // ✅ الإعداد الافتراضي: مفعل (إذا لم يكن موجوداً)
    if (g.antiChannelLinks === undefined) {
        g.antiChannelLinks = true;
    }

    if (!action) {
        const status = g.antiChannelLinks ? '🟢 مفعل (تلقائي)' : '🔴 معطل';
        return m.reply(`🔘 *حماية زر "عرض القناة"*\n\n📊 الحالة: ${status}\n\n📌 الأوامر:\n.حماية_قنوات تعطيل   → إيقاف الحماية في هذه المجموعة\n.حماية_قنوات تفعيل   → تشغيل الحماية مرة أخرى`);
    }

    if (action === 'تفعيل') {
        g.antiChannelLinks = true;
        return m.reply(`✅ *تم تفعيل الحماية.*\n🛡️ سيتم حذف أي زر "عرض القناة" وطرد المرسل فوراً.`);
    }

    if (action === 'تعطيل') {
        g.antiChannelLinks = false;
        return m.reply(`❌ *تم تعطيل الحماية في هذه المجموعة.*`);
    }

    return m.reply(`❌ وسيط غير معروف. استخدم:\n.حماية_قنوات تفعيل\n.حماية_قنوات تعطيل`);
};

// ========== المعالج (before) - يعمل تلقائياً ==========
handler.before = async (m, { conn, bot }) => {
    if (!m.isGroup) return false;

    // ✅ الإعداد الافتراضي: مفعل (إذا لم يكن موجوداً)
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    if (global.db.groups[m.chat].antiChannelLinks === undefined) {
        global.db.groups[m.chat].antiChannelLinks = true;
    }

    const g = global.db.groups[m.chat];
    if (!g.antiChannelLinks) return false;

    if (m.isOwner || m.isAdmin) return false;

    const sub = global.subBots;
    if (sub && isMySubBot(m.sender, sub)) return false;

    if (!hasChannelButton(m)) return false;

    // حذف الرسالة
    try {
        await conn.sendMessage(m.chat, { delete: m.key });
    } catch (_) {}

    // طرد المرسل
    try {
        await conn.sendMessage(m.chat, {
            text: `🚫 *تم حذف زر "عرض القناة" وطرد المرسل!*\n@${getNumber(m.sender)} ممنوع مشاركة القنوات.`,
            mentions: [m.sender]
        });
        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
    } catch (_) {}

    return true;
};

handler.command = ['حماية_قنوات'];
handler.category = 'admin';
handler.usage = ['حماية_قنوات'];

export default handler;
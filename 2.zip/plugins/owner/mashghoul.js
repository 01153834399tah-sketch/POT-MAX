// plugins/owner/mashghoul.js
// الأمر: .مشغول

const handler = async (m, { conn, text, bot }) => {
    try {
        // التحقق من المطور
        const isOwner = bot.config?.owners?.some(owner => owner.jid === m.sender || owner.lid === m.sender);
        if (!isOwner) return await m.reply("❌ هذا الأمر للمطورين فقط.");

        // تهيئة قاعدة البيانات
        if (!global.db) global.db = {};
        if (typeof global.db.busyMode !== 'boolean') global.db.busyMode = false;

        const args = text.trim().split(' ');
        const action = args[0]?.toLowerCase();

        if (!action) {
            const status = global.db.busyMode ? '🟢 *مفعل*' : '🔴 *معطل*';
            return await m.reply(`
🔔 *وضع المشغول*

📊 الحالة: ${status}

📌 الأوامر:
   .مشغول تفعيل   → تفعيل وضع المشغول
   .مشغول تعطيل   → إلغاء وضع المشغول

📝 عند التفعيل، يرد البوت تلقائياً على أي رسالة خاصة بأن المطور مشغول.
`);
        }

        if (action === 'تفعيل') {
            global.db.busyMode = true;
            return await m.reply(`🔴 *تم تفعيل وضع المشغول.*\n\n📌 سيتم الرد تلقائياً على أي رسالة خاصة بأن المطور مشغول.`);
        } else if (action === 'تعطيل') {
            global.db.busyMode = false;
            return await m.reply(`🟢 *تم إلغاء وضع المشغول.*\n\n✅ البوت يعمل بشكل طبيعي في الخاص.`);
        } else {
            return await m.reply(`❌ وسيط غير معروف. استخدم:\n.مشغول تفعيل\n.مشغول تعطيل`);
        }
    } catch (e) {
        console.error('خطأ في أمر مشغول:', e);
        return await m.reply(`❌ حدث خطأ: ${e.message}`);
    }
};

// ====== معالج الرد التلقائي في الخاص (بدون استخدام m.isGroup) ======
handler.before = async (m, { conn, bot }) => {
    try {
        // التحقق من أن الرسالة في الخاص (وليست مجموعة)
        // بديل آمن لـ m.isGroup
        const isGroup = m.chat.endsWith('@g.us');
        if (isGroup) return false;
        
        // إذا كان الوضع معطلاً
        if (!global.db?.busyMode) return false;

        // إذا كان المرسل مطوراً
        const isOwner = bot.config?.owners?.some(owner => owner.jid === m.sender || owner.lid === m.sender);
        if (isOwner) return false;

        // إذا كانت الرسالة أمراً
        const prefixes = bot.config?.prefix || ['.', '/', '!'];
        const isCommand = prefixes.some(p => m.text?.startsWith(p));
        if (isCommand) return false;

        // إرسال الرد التلقائي
        await conn.sendMessage(m.chat, {
            text: `🔴 *المطور مشغول حالياً*\n\n⏳ يرجى المحاولة لاحقاً.\n📩 سيتم الرد عليك عند توفر المطور.`
        });
        return true;
    } catch (e) {
        console.error('خطأ في رد المشغول:', e);
        return false;
    }
};

handler.command = ['مشغول'];
handler.category = 'owner';
export default handler;
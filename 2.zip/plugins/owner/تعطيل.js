// plugins/owner/تعطيل_بوت.js
// الأمر: .تعطيل_بوت

const handler = async (m, { conn, text, bot }) => {
    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    const bots = sub.list();
    if (!bots.length) return m.reply("📭 لا يوجد بوتات فرعية مثبتة.");

    // إذا كان هناك نص (اختيار بوت) -> نحذف فوراً
    if (text && text.trim()) {
        const botId = text.trim();
        const subBot = sub.get(botId);
        if (!subBot) return m.reply(`❌ لا يوجد بوت فرعي بهذا المعرف: ${botId}`);

        try {
            // محاولة إغلاق الاتصال إذا كان متصلاً
            if (subBot.connected && subBot.sock) {
                try {
                    await subBot.sock.end();
                } catch (e) {}
            }

            // حذف البوت من النظام
            const result = sub.delete(botId);
            if (result) {
                await m.reply(`✅ تم حذف البوت الفرعي *${subBot.phone || botId}* نهائياً.`);
            } else {
                await m.reply(`❌ فشل حذف البوت الفرعي.`);
            }
        } catch (err) {
            console.error(err);
            await m.reply(`❌ حدث خطأ أثناء حذف البوت: ${err.message || 'خطأ غير معروف'}`);
        }
        return;
    }

    // عرض قائمة البوتات للاختيار (بدون تأكيد)
    const sections = [{
        title: "🗑️ اختر البوت الفرعي للحذف الفوري",
        rows: bots.map(b => ({
            title: `📱 ${b.phone || "بوت فرعي"}`,
            description: `الحالة: ${b.connected ? '🟢 متصل' : '🔴 غير متصل'} | المعرف: ${b.id}`,
            id: `.تعطيل_بوت ${b.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: "🗑️ *اختر البوت الفرعي للحذف الفوري*\n⚠️ *تحذير:* سيتم حذف البوت نهائياً!",
        buttons: [{ name: "single_select", params: { title: "🗑️ اختر البوت", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
};

handler.command = ['تعطيل_بوت'];
handler.category = 'owner';
handler.owner = true;

export default handler;
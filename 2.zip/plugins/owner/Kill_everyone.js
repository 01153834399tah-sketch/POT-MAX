// plugins/owner/kick_all.js
// الأمر: .طرد_بروماكس

const handler = async (m, { conn, text, bot }) => {
    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    const bots = sub.list();
    if (!bots.length) return m.reply("📭 لا يوجد بوتات فرعية مثبتة.");

    // إذا كان هناك وسيط (اختيار بوت) -> نمرره للمعالج
    if (text && text.trim()) {
        // سيتم التعامل معه في handler.before
        return;
    }

    // عرض قائمة البوتات الفرعية
    const sections = [{
        title: "🌳 اختر البوت الفرعي",
        rows: bots.map(b => ({
            title: `📱 ${b.phone || "بوت فرعي"}`,
            description: `الحالة: ${b.connected ? '🟢 متصل' : '🔴 غير متصل'}`,
            id: `.طرد_بروماكس ${b.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: "🧹 *اختر البوت الفرعي لطرد جميع الأعضاء من مجموعة*",
        buttons: [{ name: "single_select", params: { title: "🎮 اختر البوت", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
};

// ====== الخطوة 1: اختيار البوت وعرض المجموعات ======
handler.before = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.طرد_بروماكس')) return false;
    const args = m.text.split(' ');
    if (args.length < 2) return false;
    const botId = args[1];
    if (botId.includes('|')) return false; // ليس اختيار مجموعة

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    // جلب مجموعات البوت الفرعي
    let groups;
    try {
        groups = await subBot.sock.groupFetchAllParticipating();
    } catch (err) {
        console.error(err);
        await m.reply(`❌ فشل في جلب مجموعات البوت.`);
        return true;
    }

    const groupList = Object.values(groups);
    if (!groupList.length) {
        await m.reply(`📭 البوت الفرعي ليس في أي مجموعة.`);
        return true;
    }

    const sections = [{
        title: "🌳 اختر المجموعة لطرد جميع الأعضاء",
        rows: groupList.map(g => ({
            title: `👥 ${g.subject}`,
            description: `المعرف: ${g.id.split('@')[0]}`,
            id: `.طرد_بروماكس ${botId}|${g.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: `🚫 *البوت: ${subBot.phone || botId}*\nاختر المجموعة لطرد جميع الأعضاء:`,
        buttons: [{ name: "single_select", params: { title: "📋 اختر المجموعة", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
    return true;
};

// ====== الخطوة 2: اختيار المجموعة وعرض تأكيد/إلغاء ======
handler.before2 = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.طرد_بروماكس')) return false;
    const parts = m.text.split(' ');
    if (parts.length < 2) return false;
    const payload = parts[1];
    if (!payload.includes('|')) return false;
    const [botId, groupId] = payload.split('|');
    if (!botId || !groupId) return false;

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    // التحقق من صلاحية المطور الرئيسي
    const isMainOwner = bot.config?.owners?.some(owner => owner.jid === m.sender || owner.lid === m.sender);
    if (!isMainOwner) {
        await m.reply(`❌ أنت لست مطورًا رئيسيًا.`);
        return true;
    }

    // تخزين البيانات مؤقتاً للتأكيد
    if (!global.kickAllTemp) global.kickAllTemp = {};
    const tempKey = `${m.sender}_kick_all_${Date.now()}`;
    global.kickAllTemp[tempKey] = { botId, groupId, timestamp: Date.now() };

    // عرض أزرار التأكيد والإلغاء
    const buttons = [
        { name: "quick_reply", params: { display_text: "✅ تأكيد طرد الجميع", id: `.طرد_بروماكس_تأكيد ${tempKey}` } },
        { name: "quick_reply", params: { display_text: "❌ إلغاء", id: `.طرد_بروماكس_الغاء` } }
    ];

    await conn.sendButtonNormal(m.chat, {
        text: `🧹 *تأكيد طرد جميع الأعضاء*\n\n👥 المجموعة: ${groupId.split('@')[0]}\n🤖 البوت: ${subBot.phone || botId}\n\n⚠️ *تحذير:* سيتم طرد جميع الأعضاء (عدا المطورين والأدمن والبوت).\n\nهل أنت متأكد؟`,
        buttons: buttons,
        mentions: [m.sender]
    }, global.reply_status);
    return true;
};

// ====== الخطوة 3: تنفيذ طرد الجميع ======
handler.before3 = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.طرد_بروماكس_تأكيد')) return false;
    const args = m.text.split(' ');
    if (args.length < 2) return false;
    const tempKey = args[1];
    if (!global.kickAllTemp || !global.kickAllTemp[tempKey]) {
        await m.reply("❌ لم يتم العثور على طلب. ربما انتهت صلاحيته.");
        return true;
    }

    const { botId, groupId } = global.kickAllTemp[tempKey];
    delete global.kickAllTemp[tempKey];

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    // جلب بيانات المجموعة
    let groupMetadata;
    try {
        groupMetadata = await subBot.sock.groupMetadata(groupId);
    } catch (err) {
        await m.reply(`❌ لا يمكن الوصول إلى معلومات المجموعة.`);
        return true;
    }

    const botJid = subBot.sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const isBotAdmin = groupMetadata.participants.some(p => p.id === botJid && p.admin);
    if (!isBotAdmin) {
        await m.reply(`❌ البوت الفرعي ليس مشرفاً في هذه المجموعة.`);
        return true;
    }

    // تحديد المستثنيين (المطورين، الأدمن، البوت)
    const owners = bot.config?.owners?.map(o => o.jid) || [];
    const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
    const excluded = new Set([...owners, ...admins, botJid]);

    // إضافة المطورين بصيغ مختلفة
    groupMetadata.participants.forEach(p => {
        if (owners.some(o => o === p.id || o.replace(/@s\.whatsapp\.net$/, '') === p.id.replace(/@s\.whatsapp\.net$/, ''))) {
            excluded.add(p.id);
        }
        if (p.admin) excluded.add(p.id);
        if (p.id === botJid || p.id.replace(/@s\.whatsapp\.net$/, '') === botJid.replace(/@s\.whatsapp\.net$/, '')) {
            excluded.add(p.id);
        }
    });

    const toKick = groupMetadata.participants
        .map(p => p.id)
        .filter(id => !excluded.has(id));

    if (toKick.length === 0) {
        await m.reply("✅ لا يوجد أعضاء عاديون لطردهم (كلهم محميون).");
        return true;
    }

    // طرد الأعضاء على دفعات
    const batchSize = 20;
    let kicked = 0;
    let errors = 0;
    for (let i = 0; i < toKick.length; i += batchSize) {
        const batch = toKick.slice(i, i + batchSize);
        try {
            await subBot.sock.groupParticipantsUpdate(groupId, batch, 'remove');
            kicked += batch.length;
        } catch (e) {
            errors++;
            console.error(`خطأ في طرد دفعة من ${groupId}:`, e.message);
        }
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    await m.reply(`🧹 *تم طرد جميع الأعضاء بنجاح!*\n\n👥 عدد المطرودين: ${kicked}\n⚠️ عدد الأخطاء: ${errors}\n🤖 البوت: ${subBot.phone || botId}`);
    return true;
};

// ====== معالج إلغاء الطرد ======
handler.before4 = async (m, { conn }) => {
    if (!m.text || !m.text.startsWith('.طرد_بروماكس_الغاء')) return false;
    await m.reply("❌ تم إلغاء عملية الطرد.");
    if (global.kickAllTemp) {
        for (const key in global.kickAllTemp) {
            if (key.startsWith(m.sender)) delete global.kickAllTemp[key];
        }
    }
    return true;
};

// دمج المعالجات
const before1 = handler.before;
const before2 = handler.before2;
const before3 = handler.before3;
const before4 = handler.before4;

handler.before = async function(m, { conn, bot }) {
    if (await before4?.(m, { conn, bot })) return true;
    if (await before3?.(m, { conn, bot })) return true;
    if (await before2?.(m, { conn, bot })) return true;
    if (await before1?.(m, { conn, bot })) return true;
    return false;
};

handler.command = ['طرد_بروماكس'];
handler.category = 'owner';
handler.owner = true;

export default handler;
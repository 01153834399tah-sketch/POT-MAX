// plugins/owner/disconnected.js
// الأمر: .غير متصل - حذف البوتات غير المتصلة (نسخة متقدمة)

const handler = async (m, { conn, bot }) => {
    const isOwner = bot.config?.owners?.some(o => o.jid === m.sender || o.lid === m.sender);
    if (!isOwner) return m.reply("❌ هذا الأمر للمطورين فقط.");

    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    // جلب قائمة البوتات
    const bots = sub.list();
    if (!bots || !bots.length) return m.reply("📭 لا يوجد بوتات فرعية مثبتة.");

    // تصفية البوتات غير المتصلة
    const disconnected = bots.filter(b => !b.connected);
    if (!disconnected.length) return m.reply("✅ جميع البوتات الفرعية متصلة.");

    let deleted = [];
    let failed = [];

    for (const bot of disconnected) {
        const botId = bot.id;
        const botPhone = bot.phone || botId;

        try {
            // محاولة إغلاق الاتصال إذا كان موجوداً
            if (bot.sock) {
                try { await bot.sock.end(); } catch (_) {}
            }

            // ✅ محاولة الحذف بطرق متعددة
            let result = false;

            // 1. محاولة remove أولاً
            if (typeof sub.remove === 'function') {
                try {
                    const removeResult = await sub.remove(botId);
                    if (removeResult) result = true;
                } catch (_) {}
            }

            // 2. إذا فشلت remove، حاول الحذف عبر الـ map الداخلي
            if (!result && sub.bots && sub.bots instanceof Map) {
                const deleted = sub.bots.delete(botId);
                if (deleted) result = true;
            }

            // 3. إذا فشلت، حاول الحذف عبر الـ cache
            if (!result && sub.cache && sub.cache instanceof Map) {
                const deleted = sub.cache.delete(botId);
                if (deleted) result = true;
            }

            // 4. إذا فشلت كل الطرق، جرب حذفها من القائمة مباشرة
            if (!result) {
                const index = bots.indexOf(bot);
                if (index > -1) {
                    bots.splice(index, 1);
                    result = true;
                }
            }

            if (result) {
                deleted.push(botPhone);
            } else {
                failed.push({ id: botPhone, reason: 'تعذر الحذف (جرب يدوياً)' });
            }
        } catch (e) {
            failed.push({ id: botPhone, reason: e.message || 'خطأ غير معروف' });
        }
    }

    // بناء التقرير
    let report = `🧹 *نتيجة حذف البوتات غير المتصلة*\n\n`;
    report += `📊 عدد غير المتصل: ${disconnected.length}\n`;
    report += `✅ تم حذف: ${deleted.length}\n`;
    if (failed.length) report += `❌ فشل حذف: ${failed.length}\n`;
    report += `\n`;

    if (deleted.length) {
        report += `✅ *المحذوفة:*\n${deleted.map(id => `• ${id}`).join('\n')}\n`;
    }
    if (failed.length) {
        report += `\n❌ *الفاشلة:*\n${failed.map(f => `• ${f.id} (${f.reason})`).join('\n')}\n`;
        report += `\n💡 **نصيحة:** استخدم أمر .تعطيل_بوت لحذف كل بوت على حدة.`;
    }

    return m.reply(report);
};

handler.command = ['غير متصل', 'حذف_غير_متصل'];
handler.category = 'owner';
handler.owner = true;

export default handler;
// plugins/owner/اخرجني.js
// الأمر: .اخرجني

const handler = async (m, { conn, command, text, bot }) => {
    // إذا كان هناك نص بعد الأمر، لا نعرض القائمة الرئيسية
    if (text && text.trim()) return;

    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    const bots = sub.list();
    if (!bots.length) return m.reply("📭 لا يوجد بوتات فرعية مثبتة.");

    const sections = [{
        title: "🌳 اختر البوت الفرعي",
        rows: bots.map(b => ({
            title: `📱 ${b.phone || "بوت فرعي"}`,
            description: `الحالة: ${b.connected ? '🟢 متصل' : '🔴 غير متصل'}`,
            id: `.اخرجني ${b.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: "🔻 *اختر البوت الفرعي لإخراجه من مجموعة*",
        buttons: [{ name: "single_select", params: { title: "🎮 اختر البوت", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
};

// المعالج الرئيسي لرسائل .اخرجني
handler.before = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.اخرجني')) return false;

    const args = m.text.split(' ');
    if (args.length < 2) return false;
    const payload = args[1];

    // حالة 1: اختيار بوت (لا يوجد |)
    if (!payload.includes('|')) {
        const botId = payload;
        const sub = global.subBots;
        if (!sub) {
            await m.reply("❌ نظام البوتات الفرعية غير متاح.");
            return true;
        }
        const subBot = sub.get(botId);
        if (!subBot || !subBot.connected) {
            await m.reply(`❌ البوت الفرعي غير متصل.`);
            return true;
        }

        // جلب مجموعات البوت الفرعي
        let groups;
        try {
            groups = await subBot.sock.groupFetchAllParticipating();
        } catch (err) {
            console.error(err);
            await m.reply(`❌ فشل في جلب مجموعات البوت.`);
            return true;
        }
        const groupList = Object.values(groups);
        if (!groupList.length) {
            await m.reply(`📭 البوت الفرعي ليس في أي مجموعة.`);
            return true;
        }

        const sections = [{
            title: "🌳 اختر المجموعة لإخراج البوت منها",
            rows: groupList.map(g => ({
                title: `👥 ${g.subject}`,
                description: `المعرف: ${g.id.split('@')[0]}`,
                id: `.اخرجني ${botId}|${g.id}`
            }))
        }];

        await conn.sendButtonNormal(m.chat, {
            media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
            mediaType: 'image',
            caption: `🚫 *البوت: ${subBot.phone || botId}*\nاختر المجموعة التي تريد إخراج البوت منها:`,
            buttons: [{ name: "single_select", params: { title: "📋 اختر المجموعة", sections: sections } }],
            mentions: [m.sender]
        }, global.reply_status);
        return true;
    }

    // حالة 2: اختيار مجموعة (يحتوي على |) -> نقوم بإخراج البوت فوراً
    if (payload.includes('|')) {
        const [botId, groupId] = payload.split('|');
        const sub = global.subBots;
        if (!sub) {
            await m.reply("❌ نظام البوتات الفرعية غير متاح.");
            return true;
        }
        const subBot = sub.get(botId);
        if (!subBot || !subBot.connected) {
            await m.reply(`❌ البوت الفرعي غير متصل.`);
            return true;
        }

        // التحقق من صلاحية المطور الرئيسي
        const isMainOwner = bot.config?.owners?.some(owner => owner.jid === m.sender || owner.lid === m.sender);
        if (!isMainOwner) {
            await m.reply(`❌ أنت لست مطورًا رئيسيًا.`);
            return true;
        }

        // تنفيذ إخراج البوت من المجموعة
        try {
            await subBot.sock.groupLeave(groupId);
            await m.reply(`✅ تم إخراج البوت الفرعي بنجاح من المجموعة:\n👥 ${groupId.split('@')[0]}\n🤖 البوت: ${subBot.phone || botId}`);
        } catch (err) {
            console.error(err);
            await m.reply(`❌ فشل إخراج البوت: ${err.message || 'خطأ غير معروف'}`);
        }
        return true;
    }

    return false;
};

handler.command = ['اخرجني'];
handler.category = 'owner';
handler.owner = true;

export default handler;
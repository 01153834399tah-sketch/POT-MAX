// plugins/owner/I'm_admin.js
// الأمر: .ارفعني (للمطورين فقط، ويعمل مع البوتات الفرعية)

const handler = async (m, { conn, text }) => {
    try {
        // محاولة رفع المستخدم مباشرة (بدون تحقق مسبق من صلاحية البوت)
        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote');
        m.reply("*تم رفعك ادمن يا مطوري 🌹⁦(⁠≧⁠▽⁠≦⁠)⁩*");
    } catch (error) {
        // عرض رسالة الخطأ الحقيقية من واتساب
        m.reply(`❌ فشل الرفع: ${error.message}`);
    }
};

handler.usage = ["ارفعني"];
handler.category = "owner";      // ✅ يظهر في قسم المطورين
handler.command = ["ارفعني"];
handler.owner = true;            // ✅ للمطورين فقط
// ❌ تم إزالة handler.botAdmin = true (التحقق يُترك لواتساب)

export default handler;
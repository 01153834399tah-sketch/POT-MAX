// plugins/owner/حظر_متقدم.js
// الأمر: .حظر_متقدم

const handler = async (m, { conn }) => {
    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    const bots = sub.list();
    if (!bots.length) return m.reply("📭 لا يوجد بوتات فرعية مثبتة.");

    const sections = [{
        title: "🌳 اختر البوت الفرعي",
        rows: bots.map(b => ({
            title: `📱 ${b.phone || "بوت فرعي"}`,
            description: `الحالة: ${b.connected ? '🟢 متصل' : '🔴 غير متصل'}`,
            id: `.حظر_متقدم ${b.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: "🚫 *اختر البوت الفرعي لحظر محادثة خاصة*:",
        buttons: [{ name: "single_select", params: { title: "🎮 اختر البوت", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
};

// الخطوة 1: اختيار البوت ثم عرض المحادثات الخاصة
handler.before = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.حظر_متقدم')) return false;
    const args = m.text.split(' ');
    if (args.length < 2) return false;
    const botId = args[1];
    if (botId.includes('|')) return false; // ليس اختيار شخص بعد

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    // جلب المحادثات الخاصة (الأفراد) من البوت الفرعي
    let privateChats = [];
    try {
        const chats = subBot.sock.chats;
        if (chats && typeof chats.forEach === 'function') {
            for (let [jid, chat] of chats.entries()) {
                if (!jid.includes('@g.us') && !jid.includes('broadcast') && jid !== subBot.sock.user.id) {
                    let name = jid.split('@')[0];
                    if (chat.name) name = chat.name;
                    else if (chat.profileName) name = chat.profileName;
                    privateChats.push({ jid, name, lastMessageTime: chat.lastMessageTime || 0 });
                }
            }
            privateChats.sort((a, b) => (b.lastMessageTime || 0) - (a.lastMessageTime || 0));
        } else {
            throw new Error('لا يمكن الوصول إلى قائمة المحادثات الخاصة.');
        }
    } catch (err) {
        console.error(err);
        await m.reply(`❌ فشل في جلب المحادثات الخاصة.\n${err.message || ''}`);
        return true;
    }

    if (!privateChats.length) {
        await m.reply(`📭 لا توجد محادثات خاصة لهذا البوت الفرعي.`);
        return true;
    }

    const sections = [{
        title: "👤 اختر الشخص لحظره",
        rows: privateChats.slice(0, 20).map(p => ({
            title: `👤 ${p.name || p.jid.split('@')[0]}`,
            description: `المعرف: ${p.jid.split('@')[0]}`,
            id: `.حظر_متقدم ${botId}|${p.jid}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: `🚫 *البوت: ${subBot.phone || botId}*\nاختر الشخص الذي تريد حظره:`,
        buttons: [{ name: "single_select", params: { title: "📋 اختر الشخص", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
    return true;
};

// الخطوة 2: اختيار الشخص ثم عرض تأكيد أو إلغاء
handler.before2 = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.حظر_متقدم')) return false;
    const parts = m.text.split(' ');
    if (parts.length < 2) return false;
    const payload = parts[1];
    if (!payload.includes('|')) return false;
    const [botId, contactJid] = payload.split('|');
    if (!botId || !contactJid) return false;

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    const isMainOwner = bot.config?.owners?.some(owner => owner.jid === m.sender || owner.lid === m.sender);
    if (!isMainOwner) {
        await m.reply(`❌ أنت لست مطورًا رئيسيًا.`);
        return true;
    }

    if (!global.blockTemp) global.blockTemp = {};
    const tempKey = `${m.sender}_block_adv`;
    global.blockTemp[tempKey] = { botId, contactJid, timestamp: Date.now() };

    const buttons = [
        { name: "quick_reply", params: { display_text: "✅ تأكيد الحظر المتقدم", id: `.حظر_متقدم_تأكيد ${tempKey}` } },
        { name: "quick_reply", params: { display_text: "❌ إلغاء", id: `.حظر_متقدم_الغاء` } }
    ];

    await conn.sendButtonNormal(m.chat, {
        text: `🚫 *تأكيد حظر المحادثة*\n👤 الشخص: ${contactJid.split('@')[0]}\n🤖 البوت: ${subBot.phone || botId}\n\nهل أنت متأكد من حظر هذا الشخص على البوت الفرعي؟`,
        buttons: buttons,
        mentions: [m.sender]
    }, global.reply_status);
    return true;
};

// معالج تأكيد الحظر
handler.before3 = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.حظر_متقدم_تأكيد')) return false;
    const args = m.text.split(' ');
    if (args.length < 2) return false;
    const tempKey = args[1];
    if (!global.blockTemp || !global.blockTemp[tempKey]) {
        await m.reply("❌ لم يتم العثور على طلب حظر. ربما انتهت صلاحيته.");
        return true;
    }

    const { botId, contactJid } = global.blockTemp[tempKey];
    delete global.blockTemp[tempKey];

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    try {
        await subBot.sock.updateBlockStatus(contactJid, 'block');
        await m.reply(`✅ تم حظر الشخص *${contactJid.split('@')[0]}* بنجاح على البوت الفرعي *${subBot.phone || botId}*.`);
    } catch (err) {
        console.error(err);
        await m.reply(`❌ فشل حظر الشخص: ${err.message || 'خطأ غير معروف'}`);
    }
    return true;
};

// معالج إلغاء الحظر
handler.before4 = async (m, { conn }) => {
    if (!m.text || !m.text.startsWith('.حظر_متقدم_الغاء')) return false;
    await m.reply("❌ تم إلغاء عملية الحظر المتقدم.");
    if (global.blockTemp) {
        for (const key in global.blockTemp) {
            if (key.endsWith('_block_adv')) delete global.blockTemp[key];
        }
    }
    return true;
};

// دمج المعالجات
const before1 = handler.before;
const before2 = handler.before2;
const before3 = handler.before3;
const before4 = handler.before4;

handler.before = async function(m, { conn, bot }) {
    if (await before4?.(m, { conn, bot })) return true;
    if (await before3?.(m, { conn, bot })) return true;
    if (await before2?.(m, { conn, bot })) return true;
    if (await before1?.(m, { conn, bot })) return true;
    return false;
};

handler.command = ['حظر_متقدم'];
handler.category = 'owner';
handler.owner = true;

export default handler;
// plugins/owner/delete_all_bots.js
// الأمر: .حذف_كل_البوتات - حذف جميع البوتات الفرعية دفعة واحدة

const handler = async (m, { conn, text, bot }) => {
    // 1️⃣ التحقق من أن المستخدم مطور رئيسي
    const isOwner = bot.config?.owners?.some(o => o.jid === m.sender || o.lid === m.sender);
    if (!isOwner) return m.reply("❌ هذا الأمر للمطورين الرئيسيين فقط.");

    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    const bots = sub.list();
    if (!bots.length) return m.reply("📭 لا يوجد بوتات فرعية لحذفها.");

    // عرض تأكيد قبل الحذف
    const action = text?.trim().toLowerCase();
    if (!action || action !== 'تأكيد') {
        return m.reply(`⚠️ *تحذير: حذف جميع البوتات الفرعية!*\n\n📊 عدد البوتات: ${bots.length}\n🟢 متصلة: ${bots.filter(b => b.connected).length}\n🔴 غير متصلة: ${bots.filter(b => !b.connected).length}\n\n❓ *هل أنت متأكد؟*\n.حذف_كل_البوتات تأكيد`);
    }

    // تنفيذ الحذف
    let deleted = 0;
    let failed = 0;
    const results = [];

    for (const bot of bots) {
        const botId = bot.id;
        const botPhone = bot.phone || botId;
        try {
            // إغلاق الاتصال إن وجد
            if (bot.sock) {
                try { await bot.sock.end(); } catch (_) {}
            }
            const result = sub.delete(botId);
            if (result) {
                deleted++;
                results.push(`✅ ${botPhone}`);
            } else {
                failed++;
                results.push(`❌ ${botPhone} (فشل)`);
            }
        } catch (e) {
            failed++;
            results.push(`❌ ${botPhone} (خطأ: ${e.message})`);
        }
        // تأخير بسيط بين كل حذف وآخر لتجنب الحظر
        await new Promise(resolve => setTimeout(resolve, 200));
    }

    // تقرير النتيجة
    const report = `
🧹 *تم حذف جميع البوتات الفرعية!*

📊 *الإجمالي:* ${bots.length}
✅ *تم الحذف:* ${deleted}
❌ *فشل الحذف:* ${failed}

📋 *التفاصيل:*
${results.join('\n')}
    `.trim();

    return m.reply(report);
};

handler.command = ['حذف_كل_البوتات'];
handler.category = 'owner';
handler.usage = ['حذف_كل_البوتات'];
handler.owner = true;

export default handler;
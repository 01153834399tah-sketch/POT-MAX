// plugins/owner/changebotname.js - ديناميكي (يقرأ الاسم الحالي من الملفات)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNERS = [
    '201279682276@s.whatsapp.net',
    '201279682665@s.whatsapp.net',
    '201033024135@s.whatsapp.net',
    '201050079089@s.whatsapp.net'
];

const INDEX_PATH = path.join(__dirname, '../../index.js');

// ✅ قراءة اسم البوت الحالي من index.js
function getCurrentBotName() {
    try {
        const content = fs.readFileSync(INDEX_PATH, 'utf8');
        const match = content.match(/nameBot\s*:\s*["']([^"']+)["']/);
        return match ? match[1] : null;
    } catch {
        return null;
    }
}

// ✅ قراءة اسم القناة الحالي من index.js
function getCurrentChannelName() {
    try {
        const content = fs.readFileSync(INDEX_PATH, 'utf8');
        const match = content.match(/nameChannel\s*:\s*["']([^"']+)["']/);
        return match ? match[1] : null;
    } catch {
        return null;
    }
}

// ✅ كتابة الاسم الجديد في index.js
function updateIndexFile(oldName, newName, type) {
    const content = fs.readFileSync(INDEX_PATH, 'utf8');
    let updated = content;
    if (type === 'bot') {
        updated = updated.replace(new RegExp(`nameBot\\s*:\\s*["']${oldName}["']`), `nameBot: "${newName}"`);
    } else {
        updated = updated.replace(new RegExp(`nameChannel\\s*:\\s*["']${oldName}["']`), `nameChannel: "${newName}"`);
    }
    fs.writeFileSync(INDEX_PATH, updated, 'utf8');
}

// دالة جلب الملفات النصية
function getAllFiles(dirPath, arrayOfFiles = []) {
    const files = fs.readdirSync(dirPath);
    for (const file of files) {
        const fullPath = path.join(dirPath, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            if (!['node_modules', '.git', 'tmp', 'auth_info_baileys', 'creds.json', '.npm'].includes(file)) {
                getAllFiles(fullPath, arrayOfFiles);
            }
        } else {
            const ext = path.extname(file);
            if (['.js', '.mjs', '.json', '.txt', '.md'].includes(ext)) {
                arrayOfFiles.push(fullPath);
            }
        }
    }
    return arrayOfFiles;
}

async function updateName(conn, m, OLD_NAME, NEW_NAME, type) {
    if (!OLD_NAME) {
        return conn.sendMessage(m.chat, { text: '❌ لم يتم العثور على الاسم الحالي في الملفات.' });
    }

    if (!NEW_NAME) {
        return conn.sendMessage(m.chat, { 
            text: `❌ يرجى كتابة الاسم الجديد.\n📌 مثال: \`.تغير_اسم1 ${type === 'bot' ? 'بوتي الجديد' : 'قناتي الجديدة'}\`` 
        });
    }

    if (NEW_NAME === OLD_NAME) {
        return conn.sendMessage(m.chat, { text: '⚠️ الاسم الجديد مطابق للقديم.' });
    }

    const waitMsg = await conn.sendMessage(m.chat, {
        text: `⏳ جاري تغيير ${type === 'bot' ? 'اسم البوت' : 'اسم القناة'} من:\n🔍 "${OLD_NAME}"\n🆕 إلى: "${NEW_NAME}"`
    });

    try {
        // 1. تحديث index.js أولاً
        updateIndexFile(OLD_NAME, NEW_NAME, type);

        // 2. تحديث باقي الملفات
        const rootPath = path.join(__dirname, '../..');
        const files = getAllFiles(rootPath);
        let updatedCount = 1; // index.js
        let errorFiles = [];

        for (const file of files) {
            if (file === INDEX_PATH) continue; // تم تحديثه بالفعل
            try {
                let content = fs.readFileSync(file, 'utf8');
                if (content.includes(OLD_NAME)) {
                    content = content.replaceAll(OLD_NAME, NEW_NAME);
                    fs.writeFileSync(file, content, 'utf8');
                    updatedCount++;
                }
            } catch (err) {
                errorFiles.push(path.basename(file));
            }
        }

        try { await conn.sendMessage(m.chat, { delete: waitMsg.key }); } catch {}

        let resultMsg = `✅ تم تغيير ${type === 'bot' ? 'اسم البوت' : 'اسم القناة'}\n📁 عدد الملفات المعدلة: ${updatedCount}\n🆕 الاسم الجديد: ${NEW_NAME}`;
        if (errorFiles.length > 0) resultMsg += `\n⚠️ فشل في: ${errorFiles.length} ملف`;
        if (updatedCount > 0) resultMsg += `\n\n🔄 *يرجى إعادة تشغيل البوت (Restart) لتطبيق التغيير بالكامل.*`;
        await conn.sendMessage(m.chat, { text: resultMsg });

    } catch (e) {
        await conn.sendMessage(m.chat, { text: `❌ خطأ: ${e.message}` });
    }
}

// ============================================================
//  الـ handler الرئيسي
// ============================================================
const handler = async (m, { conn, args, command }) => {
    if (!OWNERS.includes(m.sender)) {
        return conn.sendMessage(m.chat, {
            text: `❌ هذا الأمر للمطورين فقط.\n👤 المطورون: ${OWNERS.map(j => '@' + j.split('@')[0]).join(', ')}`,
            mentions: OWNERS
        });
    }

    const NEW_NAME = args.join(' ').trim();

    if (command === 'تغير_اسم1') {
        const OLD_NAME = getCurrentBotName();
        await updateName(conn, m, OLD_NAME, NEW_NAME, 'bot');
    } else if (command === 'تغير_اسم2') {
        const OLD_NAME = getCurrentChannelName();
        await updateName(conn, m, OLD_NAME, NEW_NAME, 'channel');
    } else {
        await conn.sendMessage(m.chat, { text: '❌ أمر غير معروف.' });
    }
};

handler.command = ['تغير_اسم1', 'تغير_اسم2'];
handler.category = 'owner';

export default handler;
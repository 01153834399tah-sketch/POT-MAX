// plugins/owner/ادخلني.js
// الأمر: .ادخلني

const handler = async (m, { conn, command, text, bot }) => {
    const sub = global.subBots;
    if (!sub) return m.reply("❌ نظام البوتات الفرعية غير متاح.");

    const bots = sub.list();
    if (!bots.length) return m.reply("📭 لا يوجد بوتات فرعية مثبتة.");

    const sections = [{
        title: "🌳 اختر البوت الفرعي",
        rows: bots.map(b => ({
            title: `📱 ${b.phone || "بوت فرعي"}`,
            description: `الحالة: ${b.connected ? '🟢 متصل' : '🔴 غير متصل'}`,
            id: `.ادخلني ${b.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: "🤖 *اختر البوت الفرعي*:",
        buttons: [{ name: "single_select", params: { title: "🎮 اختر البوت", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
};

// معالج اختيار البوت (الخطوة 1)
handler.before = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.ادخلني')) return false;
    const args = m.text.split(' ');
    if (args.length < 2) return false;
    const botId = args[1];
    if (botId.includes('|')) return false;

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    let groups;
    try {
        groups = await subBot.sock.groupFetchAllParticipating();
    } catch (err) {
        console.error(err);
        await m.reply(`❌ فشل في جلب مجموعات البوت.`);
        return true;
    }

    const groupList = Object.values(groups);
    if (!groupList.length) {
        await m.reply(`📭 البوت الفرعي ليس في أي مجموعة.`);
        return true;
    }

    const sections = [{
        title: "🌳 اختر المجموعة",
        rows: groupList.map(g => ({
            title: `👥 ${g.subject}`,
            description: `المعرف: ${g.id.split('@')[0]}`,
            id: `.ادخلني ${botId}|${g.id}`
        }))
    }];

    await conn.sendButtonNormal(m.chat, {
        media: { url: "https://i.pinimg.com/736x/20/c1/cd/20c1cd046c862caa5a42e07d00042357.jpg" },
        mediaType: 'image',
        caption: `🎉 *البوت: ${subBot.phone || botId}*\nاختر المجموعة:`,
        buttons: [{ name: "single_select", params: { title: "📋 اختر", sections: sections } }],
        mentions: [m.sender]
    }, global.reply_status);
    return true;
};

// معالج اختيار المجموعة (الخطوة 2) - ✅ بدون التحقق من صلاحية المشرف
handler.before2 = async (m, { conn, bot }) => {
    if (!m.text || !m.text.startsWith('.ادخلني')) return false;
    const parts = m.text.split(' ');
    if (parts.length < 2) return false;
    const payload = parts[1];
    if (!payload.includes('|')) return false;
    const [botId, groupId] = payload.split('|');
    if (!botId || !groupId) return false;

    const sub = global.subBots;
    if (!sub) {
        await m.reply("❌ نظام البوتات الفرعية غير متاح.");
        return true;
    }

    const subBot = sub.get(botId);
    if (!subBot || !subBot.connected) {
        await m.reply(`❌ البوت الفرعي غير متصل.`);
        return true;
    }

    // ✅ التحقق فقط من قائمة المطورين الرئيسيين (من index.js)
    const isMainOwner = bot.config?.owners?.some(owner => owner.jid === m.sender || owner.lid === m.sender);
    if (!isMainOwner) {
        await m.reply(`❌ أنت لست مطورًا رئيسيًا (غير مدرج في قائمة owners في index.js).`);
        return true;
    }

    // ✅ محاولة الإضافة مباشرة (بدون التحقق من صلاحية المشرف)
    try {
        await subBot.sock.groupParticipantsUpdate(groupId, [m.sender], 'add');
        await m.reply(`✅ تم إضافتك إلى المجموعة مباشرة.`);
        return true;
    } catch (err) {
        // إذا فشلت الإضافة المباشرة، جرب إنشاء رابط دعوة
        console.log(`⚠️ فشلت الإضافة المباشرة: ${err.message}`);
    }

    // محاولة إنشاء رابط دعوة
    let inviteLink = null;
    try {
        const inviteCode = await subBot.sock.groupInviteCode(groupId);
        inviteLink = `https://chat.whatsapp.com/${inviteCode}`;
    } catch (err) {}

    if (inviteLink) {
        await conn.sendMessage(m.sender, { text: `🎟️ *رابط دعوة للمجموعة*\n🔗 ${inviteLink}` });
        await m.reply(`✅ تم إرسال رابط الدعوة إليك في الخاص.`);
        return true;
    }

    // إذا فشل كل شيء
    await m.reply(`❌ لا يمكن إضافتك إلى المجموعة.\n- البوت ليس أدمن.\n- لا يمكن إنشاء رابط دعوة.\n- المجموعة لا تسمح بإضافة أعضاء جدد.`);
    return true;
};

// دمج المعالجين
const origBefore = handler.before;
handler.before = async function(m, { conn, bot }) {
    if (await handler.before2(m, { conn, bot })) return true;
    if (await origBefore?.(m, { conn, bot })) return true;
    return false;
};

handler.command = ['ادخلني'];
handler.owner = true;

export default handler;
// plugins/owner/update_checker.js
// الأمر: .تحديث_المكتبات - فحص التحديثات المتاحة للمكتبات

import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const execAsync = promisify(exec);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.join(__dirname, '../..');
const PACKAGE_PATH = path.join(ROOT_DIR, 'package.json');

const handler = async (m, { conn, text, bot }) => {
    // 1️⃣ التحقق من أن المستخدم مطور رئيسي
    const isOwner = bot.config?.owners?.some(o => o.jid === m.sender || o.lid === m.sender);
    if (!isOwner) return m.reply("❌ هذا الأمر للمطورين الرئيسيين فقط.");

    // 2️⃣ قراءة package.json
    if (!fs.existsSync(PACKAGE_PATH)) {
        return m.reply("❌ ملف package.json غير موجود.");
    }

    const packageData = JSON.parse(fs.readFileSync(PACKAGE_PATH, 'utf8'));
    const dependencies = packageData.dependencies || {};

    if (Object.keys(dependencies).length === 0) {
        return m.reply("📭 لا توجد مكتبات مثبتة في المشروع.");
    }

    // 3️⃣ تحليل الوسيط (إن وجد)
    const action = text?.trim().toLowerCase();

    // ✅ عرض التقرير بدون تحديث
    if (!action || action === 'فحص') {
        await m.reply("⏳ جاري فحص التحديثات... قد يستغرق بضع ثوانٍ.");

        let report = `📦 *تقرير تحديثات المكتبات*\n\n`;
        let hasUpdates = false;

        for (const [pkg, currentVersion] of Object.entries(dependencies)) {
            try {
                // الحصول على أحدث إصدار من npm
                const { stdout } = await execAsync(`npm view ${pkg} version --silent`);
                const latestVersion = stdout.trim();

                // تنظيف الإصدار الحالي (إزالة ^ و ~)
                const cleanCurrent = currentVersion.replace(/[\^~]/g, '');
                const isOutdated = cleanCurrent !== latestVersion;

                const status = isOutdated ? '🟡 تحديث متاح' : '🟢 محدث';
                if (isOutdated) hasUpdates = true;

                report += `📦 *${pkg}*\n`;
                report += `   └─ الحالي: \`${currentVersion}\`\n`;
                report += `   └─ الأحدث: \`${latestVersion}\`\n`;
                report += `   └─ الحالة: ${status}\n\n`;
            } catch (e) {
                report += `📦 *${pkg}*\n`;
                report += `   └─ ❌ فشل جلب الإصدار الأحدث: ${e.message || 'خطأ'}\n\n`;
            }
        }

        report += `\n📌 *للتحكم:*\n`;
        report += `.تحديث_المكتبات تحديث   → تحديث جميع المكتبات إلى أحدث إصدار\n`;
        report += `.تحديث_المكتبات تحديث اسم_المكتبة   → تحديث مكتبة محددة\n`;
        report += `.تحديث_المكتبات فحص   → فحص التحديثات (بدون تحديث)`;

        if (!hasUpdates) {
            report = `✅ *جميع المكتبات محدثة!*\n\n` + report;
        }

        return m.reply(report);
    }

    // ✅ تحديث جميع المكتبات
    if (action === 'تحديث') {
        const parts = text.trim().split(/\s+/);
        const targetPkg = parts.length > 1 ? parts[1] : null;

        if (targetPkg) {
            // تحديث مكتبة محددة
            if (!dependencies[targetPkg]) {
                return m.reply(`❌ المكتبة *${targetPkg}* غير موجودة في package.json.`);
            }

            await m.reply(`⏳ جاري تحديث *${targetPkg}*...`);

            try {
                const { stdout, stderr } = await execAsync(`npm install ${targetPkg}@latest --save`);
                if (stderr && !stderr.includes('up to date')) {
                    return m.reply(`❌ فشل تحديث ${targetPkg}:\n\`\`\`${stderr}\`\`\``);
                }
                return m.reply(`✅ *تم تحديث ${targetPkg}* إلى أحدث إصدار بنجاح!`);
            } catch (e) {
                return m.reply(`❌ فشل التحديث: ${e.message}`);
            }
        } else {
            // تحديث جميع المكتبات
            await m.reply(`⏳ جاري تحديث جميع المكتبات... قد يستغرق بضع دقائق.`);

            try {
                const { stdout, stderr } = await execAsync(`npm install --save`);
                if (stderr && !stderr.includes('up to date')) {
                    return m.reply(`❌ فشل التحديث:\n\`\`\`${stderr}\`\`\``);
                }
                return m.reply(`✅ *تم تحديث جميع المكتبات* إلى أحدث إصدار بنجاح!`);
            } catch (e) {
                return m.reply(`❌ فشل التحديث: ${e.message}`);
            }
        }
    }

    // ❌ وسيط غير معروف
    return m.reply(`❌ وسيط غير معروف. استخدم:\n.تحديث_المكتبات فحص   → فحص التحديثات\n.تحديث_المكتبات تحديث   → تحديث جميع المكتبات\n.تحديث_المكتبات تحديث اسم_المكتبة   → تحديث مكتبة محددة`);
};

handler.command = ['تحديث_المكتبات', 'update_checker', 'تحديث_المكتبة'];
handler.category = 'owner';
handler.usage = ['تحديث_المكتبات'];
handler.owner = true;

export default handler;
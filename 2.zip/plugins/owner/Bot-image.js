// plugins/owner/changeimages.js - تحديث مصفوفة الصور فقط (للتوزيع العشوائي)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const OWNERS = [
    '201279682276@s.whatsapp.net',
    '201279682665@s.whatsapp.net',
    '201033024135@s.whatsapp.net',
    '201050079089@s.whatsapp.net'
];

const INDEX_PATH = path.join(__dirname, '../../index.js');

// رفع صورة إلى Catbox
async function uploadToCatbox(buffer) {
    const { ext, mime } = await fileTypeFromBuffer(buffer);
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename: `image.${ext}`, contentType: mime });
    const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        timeout: 30000
    });
    if (!data || !data.includes('catbox.moe')) throw new Error('فشل رفع الصورة');
    return data.trim();
}

// تحديث مصفوفة الصور في index.js
function updateImagesArray(newUrls) {
    const content = fs.readFileSync(INDEX_PATH, 'utf8');
    const regex = /images\s*:\s*\[([\s\S]*?)\]/;
    const match = content.match(regex);
    if (!match) throw new Error('لم يتم العثور على مصفوفة images في index.js');
    const newArrayStr = JSON.stringify(newUrls);
    const updated = content.replace(regex, `images: ${newArrayStr}`);
    fs.writeFileSync(INDEX_PATH, updated, 'utf8');
}

// ============================================================
//  الـ handler الرئيسي
// ============================================================
const handler = async (m, { conn, args, command }) => {
    if (!OWNERS.includes(m.sender)) {
        return conn.sendMessage(m.chat, {
            text: `❌ هذا الأمر للمطورين فقط.\n👤 المطورون: ${OWNERS.map(j => '@' + j.split('@')[0]).join(', ')}`,
            mentions: OWNERS
        });
    }

    // ============================================================
    //  الأمر الأول: تغير_صوره1 (5-10 روابط)
    // ============================================================
    if (command === 'تغير_صوره1') {
        const urls = args.filter(a => a.match(/^https?:\/\/.+/));
        const count = urls.length;

        if (count < 5 || count > 10) {
            return conn.sendMessage(m.chat, {
                text: `❌ يرجى إدخال من **5 إلى 10** روابط صور.\n📌 مثال:\n\`.تغير_صوره1 https://a.jpg https://b.jpg https://c.jpg https://d.jpg https://e.jpg\``
            });
        }

        const waitMsg = await conn.sendMessage(m.chat, {
            text: `⏳ جاري تحديث مصفوفة الصور بـ ${count} روابط...`
        });

        try {
            // ✅ فقط تحديث المصفوفة (لا نستبدل الروابط القديمة)
            updateImagesArray(urls);

            await conn.sendMessage(m.chat, { delete: waitMsg.key }).catch(() => {});
            let list = urls.map((u, i) => `${i+1}- ${u}`).join('\n');
            await conn.sendMessage(m.chat, {
                text: `✅ تم تحديث مصفوفة الصور بـ ${count} روابط.\n🖼️ الروابط:\n${list}\n🔄 *يرجى إعادة تشغيل البوت (Restart) لتطبيق التغيير.*\n\n💡 *ملاحظة:* الصور ستظهر عشوائياً في كل أمر (بنج، تنصيب، معلومات، قائمة، ترحيب).`
            });
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ خطأ: ${e.message}` });
        }
        return;
    }

    // ============================================================
    //  الأمر الثاني: تغير_صوره2 (رفع صورة واحدة من الرد)
    // ============================================================
    if (command === 'تغير_صوره2') {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!/image/.test(mime)) {
            return conn.sendMessage(m.chat, {
                text: '❌ يرجى الرد على صورة.\n📌 مثال: (رد على صورة) `.تغير_صوره2`'
            });
        }

        await conn.sendMessage(m.chat, { text: '📤 جاري رفع الصورة...' });
        let imageUrl;
        try {
            const buffer = await quoted.download();
            if (!buffer || buffer.length === 0) throw new Error('فشل تحميل الصورة');
            imageUrl = await uploadToCatbox(buffer);
            await conn.sendMessage(m.chat, { text: `✅ تم الرفع\n🔗 ${imageUrl}` });
        } catch (e) {
            return conn.sendMessage(m.chat, { text: `❌ فشل رفع الصورة: ${e.message}` });
        }

        const waitMsg = await conn.sendMessage(m.chat, {
            text: `⏳ جاري تحديث مصفوفة الصور برابط واحد...`
        });

        try {
            // ✅ فقط تحديث المصفوفة برابط واحد
            updateImagesArray([imageUrl]);

            await conn.sendMessage(m.chat, { delete: waitMsg.key }).catch(() => {});
            await conn.sendMessage(m.chat, {
                text: `✅ تم تحديث مصفوفة الصور برابط واحد.\n🖼️ الرابط: ${imageUrl}\n🔄 *يرجى إعادة تشغيل البوت (Restart) لتطبيق التغيير.*\n\n💡 *ملاحظة:* الصور ستظهر عشوائياً في كل أمر (بنج، تنصيب، معلومات، قائمة، ترحيب).`
            });
        } catch (e) {
            await conn.sendMessage(m.chat, { text: `❌ خطأ: ${e.message}` });
        }
        return;
    }

    await conn.sendMessage(m.chat, { text: '❌ أمر غير معروف.' });
};

handler.command = ['تغير_صوره1', 'تغير_صوره2'];
handler.category = 'owner';

export default handler;
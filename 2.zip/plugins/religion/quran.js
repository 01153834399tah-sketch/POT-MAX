// plugins/religion/quran.js
// الأمر: .قران (نسخة مستقلة، لا تعتمد على almstba.com)

import axios from 'axios';
import fs from 'fs';
import path from 'path';

// ✅ قائمة أسماء السور (مدمجة)
const SURAH_NAMES = [
    'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس',
    'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر', 'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه',
    'الأنبياء', 'الحج', 'المؤمنون', 'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم',
    'لقمان', 'السجدة', 'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر', 'غافر',
    'فصلت', 'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد', 'الفتح', 'الحجرات', 'ق',
    'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن', 'الواقعة', 'الحديد', 'المجادلة', 'الحشر', 'الممتحنة',
    'الصف', 'الجمعة', 'المنافقون', 'التغابن', 'الطلاق', 'التحريم', 'الملك', 'القلم', 'الحاقة', 'المعارج',
    'نوح', 'الجن', 'المزمل', 'المدثر', 'القيامة', 'الإنسان', 'المرسلات', 'النبأ', 'النازعات', 'عبس',
    'التكوير', 'الانفطار', 'المطففين', 'الانشقاق', 'البروج', 'الطارق', 'الأعلى', 'الغاشية', 'الفجر', 'البلد',
    'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة', 'الزلزلة', 'العاديات',
    'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل', 'قريش', 'الماعون', 'الكوثر', 'الكافرون', 'النصر',
    'المسد', 'الإخلاص', 'الفلق', 'الناس'
];

// ✅ قائمة القراء (روابط مباشرة من mp3quran.net)
const RECITERS = [
    { name: 'أبو بكر الشاطري', url: (surah) => `https://server11.mp3quran.net/shatri/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'أحمد الحواشي', url: (surah) => `https://server11.mp3quran.net/hawashi/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'إدريس أبكر', url: (surah) => `https://server6.mp3quran.net/abkr/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'أحمد العجمي', url: (surah) => `https://server10.mp3quran.net/ajm/64/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'سعد الغامدي', url: (surah) => `https://server7.mp3quran.net/s_gmd/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'سعود الشريم', url: (surah) => `https://server7.mp3quran.net/shur/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'مشاري العفاسي', url: (surah) => `https://server8.mp3quran.net/afasy/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'عبدالرحمن السديس', url: (surah) => `https://server7.mp3quran.net/sds/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'محمد أيوب', url: (surah) => `https://server11.mp3quran.net/ayob/${String(surah).padStart(3, '0')}.mp3` },
    { name: 'عبدالباسط عبدالصمد', url: (surah) => `https://server11.mp3quran.net/abdulbasit/${String(surah).padStart(3, '0')}.mp3` }
];

// ✅ صورة ثابتة بدلاً من جلبها من مواقع قد تتعطل
const IMAGE_URL = 'https://i.postimg.cc/7LyrBXcM/unnamed.png';

// ========== تحميل وإرسال MP3 ==========
async function downloadAndSendMp3(conn, m, mp3Url, surahName, reciterName) {
    await m.react('⏳');
    try {
        const response = await axios({
            method: 'GET',
            url: mp3Url,
            responseType: 'stream',
            headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://mp3quran.net/' },
            timeout: 120000
        });
        const tempFilePath = path.join('/tmp', `${Date.now()}.mp3`);
        const writer = fs.createWriteStream(tempFilePath);
        response.data.pipe(writer);
        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
        const stats = fs.statSync(tempFilePath);
        if (stats.size > 100 * 1024 * 1024) {
            fs.unlinkSync(tempFilePath);
            await m.reply(`❌ الملف كبير جداً (${(stats.size/1024/1024).toFixed(2)} MB). الحد الأقصى 100 MB.`);
            await m.react('⚠️');
            return;
        }
        await conn.sendMessage(m.chat, {
            audio: fs.readFileSync(tempFilePath),
            mimetype: 'audio/mpeg',
            fileName: `سورة_${surahName}_${reciterName}.mp3`,
            caption: `📖 سورة ${surahName}\n🎙️ ${reciterName}\n📊 ${(stats.size/1024/1024).toFixed(2)} MB`
        }, { quoted: m });
        fs.unlinkSync(tempFilePath);
        await m.react('✅');
    } catch (error) {
        console.error('❌ خطأ في التحميل:', error.message);
        await m.react('❌');
        await m.reply(`❌ فشل التحميل: ${error.message}`);
    }
}

// ========== المعالج الرئيسي ==========
let handler = async (m, { conn, text, command }) => {
    // ✅ عرض السور مع التنقل بين الصفحات
    if (command === 'قران' || command === 'quran') {
        const pageSize = 12;
        let page = 1;
        if (text && text.startsWith('صفحة')) {
            const p = parseInt(text.replace('صفحة', '').trim());
            if (p > 0) page = p;
        }
        const totalPages = Math.ceil(SURAH_NAMES.length / pageSize);
        const start = (page - 1) * pageSize;
        const end = Math.min(start + pageSize, SURAH_NAMES.length);
        const currentSurahs = SURAH_NAMES.slice(start, end);

        const rows = currentSurahs.map((name, i) => ({
            title: `${start + i + 1}. سورة ${name}`,
            description: 'اختر هذه السورة',
            id: `.قران-سورة ${start + i + 1}`
        }));

        // ✅ أزرار التنقل (تم إصلاحها)
        if (page > 1) {
            rows.push({
                title: '⬅️ الصفحة السابقة',
                description: `الصفحة ${page - 1}`,
                id: `.قران صفحة ${page - 1}`
            });
        }
        if (page < totalPages) {
            rows.push({
                title: '➡️ الصفحة التالية',
                description: `الصفحة ${page + 1}`,
                id: `.قران صفحة ${page + 1}`
            });
        }

        const sections = [{
            title: `📖 سور القرآن (${start+1}-${end} من ${SURAH_NAMES.length})`,
            rows: rows
        }];

        await conn.sendButtonNormal(m.chat, {
            media: { url: IMAGE_URL },
            mediaType: 'image',
            caption: `🕋 *القرآن الكريم*\n📄 الصفحة ${page} من ${totalPages}`,
            buttons: [{ name: "single_select", params: { title: "📖 اختر السورة", sections: sections } }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }

    // ✅ اختيار سورة → عرض القراء
    if (command === 'قران-سورة') {
        const surahNumber = parseInt(text);
        if (isNaN(surahNumber) || surahNumber < 1 || surahNumber > 114) {
            await m.react('❌');
            return m.reply('❌ رقم سورة غير صحيح (1-114)');
        }
        const surahName = SURAH_NAMES[surahNumber - 1] || surahNumber;
        await m.react('⏳');

        const rows = RECITERS.map((r, i) => ({
            title: `${i + 1}. ${r.name}`,
            description: `تحميل MP3`,
            id: `.قران-تحميل ${i}|${surahNumber}|${surahName}|${encodeURIComponent(r.url(surahNumber))}|${encodeURIComponent(r.name)}`
        }));

        // ✅ زر العودة إلى قائمة السور
        rows.push({
            title: '🏠 العودة للسور',
            description: 'اختيار سورة أخرى',
            id: `.قران`
        });

        const sections = [{
            title: `🎙️ سورة ${surahName} - اختر القارئ`,
            rows: rows
        }];

        await conn.sendButtonNormal(m.chat, {
            media: { url: IMAGE_URL },
            mediaType: 'image',
            caption: `🎙️ *سورة ${surahName}*\nاختر القارئ:`,
            buttons: [{ name: "single_select", params: { title: "🎙️ اختر القارئ", sections: sections } }],
            mentions: [m.sender]
        }, global.reply_status);
        return;
    }

    // ✅ تحميل MP3
    if (command === 'قران-تحميل') {
        const parts = text.split('|');
        if (parts.length < 5) {
            await m.react('❌');
            return m.reply('❌ رابط غير صحيح');
        }
        const surahNumber = parseInt(parts[1]);
        const surahName = parts[2];
        const fileUrl = decodeURIComponent(parts[3]);
        const reciterName = decodeURIComponent(parts[4]);
        await downloadAndSendMp3(conn, m, fileUrl, surahName, reciterName);
        return;
    }
};

handler.command = ['قران', 'quran', 'قران-سورة', 'قران-تحميل'];
handler.category = 'religion';
handler.usage = ['قران'];
export default handler;
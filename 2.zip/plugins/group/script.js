let handler = async (m, {
    conn,
    bot
}) => {
const { images } = bot.config.info;
const img = images[Math.floor(Math.random() * images.length)];

// إرسال الصورة مع النص في رسالة واحدة
await conn.sendMessage(m.chat, {
    image: { url: img },
    caption: `
GitHub: _*https://github.com/deveni0/Pomni-AI/tree/main*_

Video: _*https://youtu.be/hA5aCpvesJE?si=pHAEsbDFTVXe2_sq*_

> *لا تنسي وضع نجمة لـ الريبو 🌟*
`,
    mentions: [m.sender]
}, { quoted: reply_status });
}
handler.usage = ["سكريبت"];
handler.category = "group";
handler.command = ["سكريبت", "سورس", "sc"];

export default handler;
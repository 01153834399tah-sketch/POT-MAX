// plugins/group/report.js
// الأمر: .ابلاغ - إرسال بلاغ إلى مشرفي المجموعة (مع تحويل LID)

const handler = async (m, { conn, text, bot }) => {
    try {
        if (!m.isGroup) return m.reply("❌ هذا الأمر يعمل فقط في المجموعات.");

        const target = m.quoted?.sender || m.mentionedJid?.[0];
        if (!target) {
            return m.reply(`📌 *طريقة الاستخدام:*\n.ابلاغ سبب البلاغ\n\n*مثال:*\n.ابلاغ استخدام بوت آخر\n(مع الرد على رسالة المخالف أو منشنه)`);
        }

        if (target === m.sender) {
            return m.reply("❌ لا يمكنك الإبلاغ عن نفسك.");
        }

        if (!text) {
            return m.reply(`📌 *اكتب سبب الإبلاغ.*\nمثال: .ابلاغ استخدام بوت آخر`);
        }

        // ✅ تحويل @lid إلى @s.whatsapp.net إن أمكن
        let targetJid = target;
        if (target.includes('@lid') && typeof m.lid2jid === 'function') {
            const converted = await m.lid2jid(target);
            if (converted) targetJid = converted;
        }

        // جلب بيانات المجموعة
        let groupMetadata;
        try {
            groupMetadata = await conn.groupMetadata(m.chat);
        } catch (_) {
            return m.reply("❌ لا يمكن جلب بيانات المجموعة.");
        }
        if (!groupMetadata) return m.reply("❌ لا يمكن جلب بيانات المجموعة.");

        const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
        if (admins.length === 0) {
            return m.reply("❌ لا يوجد مشرفين في هذه المجموعة.");
        }

        // المُبلِغ
        const reporterName = m.pushName || m.sender.split('@')[0];
        const reporterNumber = m.sender.split('@')[0];

        // المُبلَغ عنه (باستخدام targetJid المحول)
        let targetName = targetJid.split('@')[0]; // افتراضي (الرقم)
        try {
            const name = await conn.getName(targetJid);
            if (name && name !== targetJid.split('@')[0]) {
                targetName = name;
            }
        } catch (_) {}

        const targetNumber = targetJid.split('@')[0];

        // رابط المجموعة
        let groupLink = 'لا يوجد رابط';
        try {
            const inviteCode = await conn.groupInviteCode(m.chat);
            if (inviteCode) groupLink = `https://chat.whatsapp.com/${inviteCode}`;
        } catch (_) {}

        // بناء رسالة البلاغ
        const reportMessage = `
╭─┈─┈─┈─⟞🚨⟝─┈─┈─┈─╮
┃ *📢 بــلاغ جـديـد* 🚨
╰─┈─┈─┈─⟞🚨⟝─┈─┈─┈─╯

👤 *المُبلِغ:*
┃ └─ ${reporterName}
┃ └─ ${reporterNumber}

👤 *المُبلَغ عنه:*
┃ └─ ${targetName}
┃ └─ ${targetNumber}

📋 *سبب البلاغ:*
┃ └─ ${text}

📌 *المجموعة:*
┃ └─ ${groupMetadata.subject}
┃ └─ ${groupLink}

🕒 *التاريخ:* ${new Date().toLocaleString('ar-EG')}

💡 *الإجراء المطلوب:* اتخاذ القرار المناسب تجاه المخالف.
        `.trim();

        // إرسال البلاغ لكل مشرف
        let sentCount = 0;
        for (const admin of admins) {
            try {
                await conn.sendMessage(admin, { text: reportMessage });
                sentCount++;
            } catch (e) {
                console.error(`❌ فشل إرسال البلاغ إلى ${admin}:`, e.message);
            }
            await new Promise(resolve => setTimeout(resolve, 200));
        }

        if (sentCount > 0) {
            await m.reply(`✅ *تم إرسال بلاغك بنجاح!*\n📨 تم إشعار ${sentCount} من المشرفين.`);
            await m.react('📨');
        } else {
            await m.reply(`❌ *فشل إرسال البلاغ!*`);
            await m.react('❌');
        }

    } catch (error) {
        console.error('❌ خطأ في أمر ابلاغ:', error);
        m.reply(`❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`);
    }
};

handler.command = ['ابلاغ', 'report'];
handler.category = 'group';
handler.usage = ['ابلاغ'];

export default handler;
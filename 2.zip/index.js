import * as meowsab from 'meowsab';
const { Client } = meowsab;
import { group, access } from "./system/control.js";
import UltraDB from "./system/UltraDB.js";
import sub from './sub.js';

/* =========== Client ========== */
const client = new Client({
  phoneNumber: '249129664683',
  prefix: [".", "/", "!"],
  fromMe: false,
  owners: [
    { name: "emam", lid: "221307316789354@lid", jid: "201279682665@s.whatsapp.net" },
    { name: "مطور1", jid: "201279682276@s.whatsapp.net", lid: "76318012096632@lid" },
    { name: "VA", lid: "247579682029763@lid", jid: "201279682276@s.whatsapp.net" },
    { name: "Sukuna", jid: "201033024135@s.whatsapp.net", lid: "50414477168824@lid" },
    { name: "عمورتي", jid: "201050079089@s.whatsapp.net", lid: "51664513925368@lid" }
  ],
  settings: { noWelcome: false },
  commandsPath: './plugins'
});

client.onGroupEvent(group);
client.onCommandAccess(access);

/* =========== Database ========== */
if (!global.db) {
    global.db = new UltraDB();
}

/* =========== Config ========== */
const { config } = client;
config.info = {
  nameBot: "♡ 𝙋𝙊𝙈𝙉𝙄 🎪 〈",
  nameChannel: "Pomni AI",
  idChannel: "120363427163691139@newsletter",
  urls: {
    repo: "https://github.com/deveni0/Pomni-AI",
    api: "https://emam-api.web.id",
    channel: "https://whatsapp.com/channel/0029VbDFMWi60eBbXu18xG2E"
  },
  copyright: {
    pack: 'ڤـ ـ VA ـ ـا',
    author: 'Pomni AI'
  },
  images: [
    "https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png",
    "https://i.pinimg.com/originals/e2/21/20/e221203f319df949ee65585a657501a2.jpg",
    "https://i.pinimg.com/originals/bb/77/0f/bb770fad66a634a6b3bf93e9c00bf4e5.jpg"
  ]
};

/* =========== Start ========== */
client.start();

/* =========== Auto-Reconnect ========== */
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

setTimeout(() => {
    if (client.sock && client.sock.ev) {
        client.sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                console.log(`🔌 Connection closed with status: ${statusCode}`);
                if (statusCode === 401 || statusCode === 403) {
                    console.log('🔄 Session expired, removing creds.json...');
                    try {
                        const fs = await import('fs');
                        if (fs.existsSync('./creds.json')) {
                            fs.unlinkSync('./creds.json');
                            console.log('🗑️ Removed old creds.json');
                        }
                    } catch (e) {}
                    console.log('♻️ Restarting bot in 3 seconds...');
                    setTimeout(() => process.exit(0), 3000);
                } else if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                    reconnectAttempts++;
                    console.log(`🔄 Reconnect attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}...`);
                    setTimeout(() => {
                        client.start();
                    }, 5000 * reconnectAttempts);
                } else {
                    console.log('❌ Max reconnect attempts reached. Please restart manually.');
                }
            }
            if (connection === 'open') {
                console.log('✅ Connected successfully!');
                reconnectAttempts = 0;
            }
        });
    } else {
        console.warn('⚠️ client.sock not ready yet, retrying in 2 seconds...');
        setTimeout(() => {
            if (client.sock && client.sock.ev) {
                // إعادة المحاولة
            }
        }, 2000);
    }
}, 3000);

/* =========== Load SubBots ========== */
setTimeout(async () => {
    if (client.commandSystem) {
        await sub(client);
    }
}, 4000);

/* =========== Catch Errors ========== */
process.on('uncaughtException', (e) => {
    console.error('❌ Uncaught Exception:', e.message);
    if (e.message.includes('rate-overlimit')) {
        // تجاهل
    } else {
        console.log('⚠️ Critical error, restarting in 5 seconds...');
        setTimeout(() => process.exit(1), 5000);
    }
});

process.on('unhandledRejection', (err) => {
    console.error('❌ Unhandled Rejection:', err);
});

process.on('SIGINT', () => {
    console.log('👋 Shutting down gracefully...');
    process.exit(0);
});
// groupMonitor.js
export const monitoredGroupLink = "https://chat.whatsapp.com/LxrL2Aqch8YJBUfbM1FKEy";

export const canUseBot = (isInGroup) => {
    return isInGroup === true;
};
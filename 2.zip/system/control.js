// system/control.js - معدل لاستخدام صورة عشوائية للترحيب
import fs from "fs";
import path from "path";
import { monitoredGroupLink, canUseBot } from './groupMonitor.js';

async function isUserInGroupAlternative(sock, userId, groupLink) {
    try {
        const groupInfo = await sock.groupGetInviteInfo(groupLink).catch(() => null);
        if (!groupInfo) return false;
        const groupMetadata = await sock.groupMetadata(groupInfo.id).catch(() => null);
        if (!groupMetadata) return false;
        return groupMetadata.participants.some(p => p.id === userId);
    } catch (error) {
        return true;
    }
}

const group = async (ctx, event, eventType) => {
    try {
        if (eventType !== 'add') return null;

        const chatId = event.chat;

        if (!global.db.groups) global.db.groups = {};
        if (!global.db.groups[chatId]) global.db.groups[chatId] = { noWelcome: false };

        if (global.db.groups[chatId].noWelcome === true) return 9999;

        const newMembers = [];
        for (const p of event.participants) {
            let userId = p.id || p.phoneNumber || p;
            if (userId && !userId.includes('@')) userId = userId + '@s.whatsapp.net';
            newMembers.push(userId);
        }

        if (!newMembers.length) return null;

        const author = event.author || (event.who ? event.who : null);
        const usersTags = newMembers.map(u => '@' + u.split('@')[0]).join(' and ');
        const authorTag = author ? '@' + author.split('@')[0] : 'Unknown';

        let txt = `♡゙ مـنـور/ه ${usersTags}`;
        if (authorTag !== usersTags) txt += `\n𝐛𝐲 ${authorTag}`;

        // ✅ اختيار صورة عشوائية من مصفوفة الصور
        const images = global.client?.config?.info?.images || [];
        const randomImg = images.length ? images[Math.floor(Math.random() * images.length)] : "https://files.catbox.moe/hm9iq4.jpg";

        await ctx.sock.sendMessage(chatId, {
            image: { url: randomImg },
            caption: txt,
            contextInfo: {
                mentionedJid: author ? [author, ...newMembers] : newMembers
            }
        });

    } catch (e) {}
    return null;
};

const access = async (msg, checkType, time) => {
    const conn = await msg.client();
    
    const messages = {
        cooldown: `*♡⏳ استنى ${time || 'بعض كام ثانيه'} ثانية وكمل الأمر ⏳♡*`,
        owner: `*♡ 🇩🇪 الأمر ده لـ المطورين فقط 🇩🇪♡*`,
        group: `*♡💠 الأمر ده بيشتغل بس ف الجروبات 💠♡*`,
        admin: `*♡📯 الأمر ده لـ الادمن فقط 📯♡*`,
        private: `*♡🏷️ الأمر ده في الخاص فقط 🏷️♡*`,
        botAdmin: `*♡📌 لازم اكون ادمن عشان انقذ الأمر 📌♡*`,
        noSub: `*♡🫒 الأمر ده ف البوت الأساسي فقط 🫒♡*\n> جرب الأمر [ ${monitoredGroupLink} ]`,
        disabled: `*♡🗃️ الامر متوقف (تحت صيانة) 🗃️♡*`,
        error: `*♡❌ الأمر فيه خطأ، كلم المطورين ❌♡*`
    };
    
    if (!conn || !messages[checkType]) return;

    const isInstallCommand = msg.text?.startsWith('.تنصيب') || msg.text?.startsWith('/تنصيب');
    
    if (isInstallCommand) {
        return;
    }

    if (checkType === 'botAdmin') {
        return;
    }

    if (checkType === 'owner' && !(await conn.isOwner(msg.sender))) {
        await conn.sendMessage(msg.chat, {
            image: { url: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg" },
            caption: messages[checkType]
        });
        return;
    }

    if (checkType === 'group' && !msg.isGroup) {
        await conn.sendMessage(msg.chat, {
            image: { url: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg" },
            caption: messages[checkType]
        });
        return;
    }

    if (checkType === 'admin' && !msg.isAdmin) {
        if (isInstallCommand) {
            return;
        }
        await conn.sendMessage(msg.chat, {
            image: { url: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg" },
            caption: messages[checkType]
        });
        return;
    }

    if (checkType === 'private' && msg.isGroup) {
        await conn.sendMessage(msg.chat, {
            image: { url: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg" },
            caption: messages[checkType]
        });
        return;
    }

    if (checkType === 'cooldown') {
        await conn.sendMessage(msg.chat, {
            image: { url: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg" },
            caption: messages[checkType]
        });
        return;
    }

    await conn.sendMessage(msg.chat, {
        image: { url: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg" },
        caption: messages[checkType]
    });
};

export { group, access };